// Module
const fs = require('fs')

//Bot Settings
global.connect = true // True For Pairing // False For Qr
global.publicX = true // True For Public // False For Self
global.owner = ['6283841052581'] //Own Number
global.developer = "RexzOffc" //Dev Name
global.botname = "Vileastars Crasher" //Bot Name
global.version = "3.0.0" //Version Bot

//Sticker Setiings
global.packname = "Sticker By" //Pack Name 
global.author = "RexzOffc" // Author

//Social Media Settings
global.ytube = "https://youtube.com/@LumnzTyz"
global.ttok = "https://tiktok.com/@LumnzTyz"
global.igram = "https://instagram.com/@LumnzTyz¹⁴"
global.chtele = "https://t.me/LumnzTyz_myChanel"
global.tgram = "https://t.me/LumnzTyz"

//Bug Name Settings
global.bak = {
Ios: " ⿻ᬃ𝐋𝐮𝐦𝐧𝐳𝐓𝐲𝐳ܢ𝐎𝐯𝐞𝐫𝐅𝐥𝐨⃕𝐰⃟⃟⃟⿻ ",
Andro: "⩟⬦𪲁 𝐋͜͢𝐮𝐦𝐧͡𝐳͜͢𝐓𝐲𝐳 𝐗͜͢𝐒 -", 
Crash: " ̶C̶r̶a̶s̶h̶U̶l̶t̶i̶m̶a̶̶t̶e ̶",
Freeze: "𝐋𝐮𝐦𝐧𝐳𝐔𝐥𝐭𝐢𝐦𝐚𝐭𝐞",
Ui: "ℭ𝔯𝔴𝔰𝔥 𝔘𝔦 𝔖𝔶𝔰𝔱𝔢𝔪"
}

//System Bot Settings
global.prefa = ['','!','.',',','🐤','🗿'] // Prefix // Not Change

let file = require.resolve(__filename)
require('fs').watchFile(file, () => {
  require('fs').unwatchFile(file)
  console.log('\x1b[0;32m'+__filename+' \x1b[1;32mupdated!\x1b[0m')
  delete require.cache[file]
  require(file)
})