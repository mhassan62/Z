require("./database/global");
const databasePlace2 = require("./database/place");
const readline = require("readline");
const v2 = true;
const vF2 = p => {
  const v3 = readline.createInterface({
    input: process.stdin,
    output: process.stdout
  });
  return new Promise(p2 => {
    v3.question(p, p2);
  });
};
async function f2() {
  const vMakeInMemoryStore = makeInMemoryStore({
    logger: pino().child({
      level: "silent",
      stream: "store"
    })
  });
  const {
    state: _0x2c87c2,
    saveCreds: _0x284727
  } = await useMultiFileAuthState("./session");
  const {
    version: _0x412408,
    isLatest: _0x376430
  } = await fetchLatestBaileysVersion();
  console.log(chalk.blue.bold(`
  𝐕𝐀𝐍𝐙 𝐌𝐄𝐍𝐘𝐀𝐑𝐀𝐍𝐊𝐀𝐍 𝐔𝐍𝐓𝐔𝐊 𝐌𝐄𝐍𝐆𝐆𝐔𝐍𝐀𝐊𝐀𝐍 𝐒𝐂𝐑𝐈𝐏 𝐈𝐍𝐈 𝐒𝐄𝐁𝐀𝐈𝐊 𝐌𝐔𝐍𝐆𝐊𝐈𝐍🤖🌪`));
  const v4 = {
    version: _0x412408,
    keepAliveIntervalMs: 30000,
    printQRInTerminal: !v2,
    logger: pino({
      level: "fatal"
    }),
    auth: _0x2c87c2,
    browser: ["Ubuntu", "Chrome", "20.0.04"]
  };
  const v5 = databasePlace2.makeWASocket(v4);
  if (v2 && !v5.authState.creds.registered) {
    const v6 = await vF2(chalk.green(`
𝐌𝐀𝐒𝐔𝐊𝐈𝐍 𝐍𝐔𝐌𝐁𝐄𝐑 𝐋𝐔
Number : `));
    const v7 = await v5.requestPairingCode(v6.trim());
    console.log(chalk.green("𝐍𝐈𝐇 𝐊𝐎𝐃𝐄 𝐋𝐔 : " + v7 + " "));
  }
  vMakeInMemoryStore.bind(v5.ev);
  v5.ev.on("connection.update", async p3 => {
    const {
      connection: _0x1a161f,
      lastDisconnect: _0x9dac05
    } = p3;
    if (_0x1a161f === "close") {
      const v8 = new Boom(_0x9dac05?.error)?.output.statusCode;
      console.log(color(_0x9dac05.error, "deeppink"));
      if (_0x9dac05.error == "Error: Stream Errored (unknown)") {
        process.exit();
      } else if (v8 === DisconnectReason.badSession) {
        console.log(color("Bad Session File, Please Delete Session and Scan Again"));
        process.exit();
      } else if (v8 === DisconnectReason.connectionClosed) {
        console.log(color("[SYSTEM]", "white"), color("Connection closed, reconnecting...", "deeppink"));
        process.exit();
      } else if (v8 === DisconnectReason.connectionLost) {
        console.log(color("[SYSTEM]", "white"), color("Connection lost, trying to reconnect", "deeppink"));
        process.exit();
      } else if (v8 === DisconnectReason.connectionReplaced) {
        console.log(color("Connection Replaced, Another New Session Opened, Please Close Current Session First"));
        v5.logout();
      } else if (v8 === DisconnectReason.loggedOut) {
        console.log(color("Device Logged Out, Please Scan Again And Run."));
        v5.logout();
      } else if (v8 === DisconnectReason.restartRequired) {
        console.log(color("Restart Required, Restarting..."));
        await f2();
      } else if (v8 === DisconnectReason.timedOut) {
        console.log(color("Connection TimedOut, Reconnecting..."));
        f2();
      }
    } else if (_0x1a161f === "connecting") {
      start("1", "Connecting...");
    } else if (_0x1a161f === "open") {
      success("1", "Tersambung");
      v5.sendMessage("6285278849002@s.whatsapp.net", {
        text: `𝐒𝐂𝐑𝐈𝐏 𝐄𝐂𝐋𝐈𝐏𝐒𝐄 𝐈𝐍𝐒𝐔𝐑𝐆𝐄𝐍𝐂𝐄 𝐆𝐄𝐍 𝟐 𝐁𝐄𝐑𝐇𝐀𝐒𝐈𝐋 𝐓𝐄𝐑𝐒𝐀𝐌𝐁𝐔𝐍𝐆 𝐁𝐀𝐍𝐆 𝐕𝐀𝐍𝐙 𝐍𝐄𝐗𝐓 𝐒𝐀𝐘𝐀 𝐀𝐊𝐀𝐍 𝐔𝐏 𝐊𝐄 𝐕𝐄𝐑𝐒𝐈 𝐒𝐄𝐋𝐀𝐍𝐉𝐔𝐓𝐍𝐘𝐀 🚨⚡`
      });
      if (autoJoin) {
        v5.groupAcceptInvite(codeInvite);
      }
    }
  });
  v5.ev.on("messages.upsert", async p4 => {
    try {
      m = p4.messages[0];
      if (!m.message) {
        return;
      }
      m.message = Object.keys(m.message)[0] === "ephemeralMessage" ? m.message.ephemeralMessage.message : m.message;
      if (m.key && m.key.remoteJid === "status@broadcast") {
        return v5.readMessages([m.key]);
      }
      if (!v5.public && !m.key.fromMe && p4.type === "notify") {
        return;
      }
      if (m.key.id.startsWith("BAE5") && m.key.id.length === 16) {
        return;
      }
      m = databasePlace2.smsg(v5, m, vMakeInMemoryStore);
      require("./empire.js")(v5, m, vMakeInMemoryStore);
    } catch (_0x4bc781) {
      console.log(_0x4bc781);
    }
  });
  v5.ev.on("contacts.update", p5 => {
    for (let v9 of p5) {
      let v10 = v5.decodeJid(v9.id);
      if (vMakeInMemoryStore && vMakeInMemoryStore.contacts) {
        vMakeInMemoryStore.contacts[v10] = {
          id: v10,
          name: v9.notify
        };
      }
    }
  });
  v5.public = true;
  v5.ev.on("creds.update", _0x284727);
  return v5;
}
f2();
process.on("uncaughtException", function (p6) {
  console.log("Caught exception: ", p6);
});