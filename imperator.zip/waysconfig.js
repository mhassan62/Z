const fs = require('fs')

global.connect = true
global.publik = true 
global.packname = "IMPERATOR - CURSED"
global.author = "t.me/xwyways"
global.owner = ['628568773831']
global.developer = "WaysModzz - Cursed"
global.prefa = ['','!','.',',','/','^','#']
global.react = ["🔥","🦄"]
global.linkSaluran = "https://whatsapp.com/channel/0029Vb4HejG3bbV3f1A62g3n"
global.idSaluran = "120363391918001591@newsletter"
global.namaSaluran = "Imperator - Info"

// THUMBNAIL
global.pictures = ["https://files.catbox.moe/wa574j.jpg", "https://files.catbox.moe/x0k9sm.jpg", "https://files.catbox.moe/ef2uwx.jpg"]
global.vid = ["https://files.catbox.moe/r18i2g.mp4","https://files.catbox.moe/ibk7dx.mp4","https://files.catbox.moe/a3a9yi.mp4"]
global.audio = ["https://files.catbox.moe/t2x35e.mp3","https://files.catbox.moe/qdih5b.mp3","https://files.catbox.moe/tnctvh.mp3"]
global.menuMode = global.menuMode || 'nobutton';

/*
SCRIPT BY ? © WAYSMODZZ 🦠
소셜 미디어 ?
Telegram : @XwyWays
Youtube : WaysModzz Official
Solo Mase .................
*/

let file = require.resolve(__filename)
require('fs').watchFile(file, () => {
  require('fs').unwatchFile(file)
  console.log('\x1b[0;32m'+__filename+' \x1b[1;32mupdated!\x1b[0m')
  delete require.cache[file]
  require(file)
})