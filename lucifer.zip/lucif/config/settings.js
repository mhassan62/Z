const fs = require('fs')
const chalk = require("chalk");

global.urlch = ""
global.status = true
global.owner = "6287878064688"


let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update ${__filename}`))
	delete require.cache[file]
	require(file)
})
