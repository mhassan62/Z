# My-Base-Bot
Hai, ini adalah base script bot javascript buatan ku, kamu bisa pakai tapi tolong jangan hapus credit ya!! 

Hi, this is the base script for my javascript bot, you can use it but please don't delete the credit!! 
