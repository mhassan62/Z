const fs = require('fs')
const chalk = require('chalk')

global.ytname = "https://youtube.com/AszxyOffv"
global.location = "Indonesia"
global.ownername = " AsOffc"
global.ownernumber = '6285191351933'  //creator number
global.botname = 'PenBot' //name of the bot
global.idSaluran = "12036328751355887@newsletter"
global.packname = 'Sticker By'
global.author = 'Aszxy Pemula'
global.themeemoji = '🪀'
global.wm = "Mark Zuckerberg"
global.link = 'https://whatsapp.com/channel/0029VacUGcxDJuiseBDW0h'
global.prefa = ['!','.','#','💐']

//Manage Vercel
global.vercelToken = "-" //Your Vercel Token

//Manage GitHub
global.githubToken = "-" //Your GitHub Token
global.githubUsername = "-" //Your GitHub Username

//Bot Media
global.imgthumb = "https://img1.pixhost.to/images/5183/590304755_imgtmp.jpg"
global.vidthumb = "https://files.catbox.moe/ysvq2o.mp4"

let file = require.resolve(__filename)
fs.watchFile(file, () => {
    fs.unwatchFile(file)
    console.log(chalk.redBright(`Update'${__filename}'`))
    delete require.cache[file]
    require(file)
})