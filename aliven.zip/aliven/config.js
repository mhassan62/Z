module.exports = {
  BOT_TOKEN: "8138152795:AAF7yL1zgOKSj4zs6UMA44dGvtvJGFPaFiY",
};
//=================
//Σ ▾ 𝘼͜𝙇͢𝙄͜𝙑͢͡𝙀͡𝘼͢𝙉͜𝙂͡𝙀𝙇͢𝙀͜𝙑͢𝙀͜𝙍͢𝘿͢͡𝙄͡𝙀͢⟅ ༑ ▾ 
//╔═══════════════════════╗  
//║   Pemberitahuan Resmi   ║  
//╚═══════════════════════╝  

//[!] Informasi Script Resmi ALIVEANGEL Telah Dirilis  
//[+] Pemilik: @Sanzxdxixi  
//[+] Kode: ALIVEANGEL EVERDIE 

//⟦⚠️⟧ ALIVEANGEL EVERDIE AKTIF ⟦⚠️⟧  
//SANZ Mengambil Alih Sistem...

//>>> Integrasi STRIKE
//>>> Loading... ███████▒▒▒▒▒▒▒ 70%  
//>>> Aliveangel Everdie Aktif...  

//#Aliveangel #Aliveangeleverdie #Ownersanz  
