require("./database/module")

//================OWNER'S NAME AND PHONE NUMBER=============\
global.owner = "923255156992" //replace with your actual phone number
global.botName = "𝙆𝘼𝙎𝙃𝙈𝙄𝙍𝙄" //name of the bot
global.botname = "𝙆𝘼𝙎𝙃𝙈𝙄𝙍𝙄" //Bot Second Name 
global.creatorName = "𝙆𝘼𝙎𝙃𝙈𝙄𝙍𝙄" //name of the creator
global.ownertele = "t.me/@KASHMIRI_X1" //Telegram Location of Creator 
global.ownernumber = '254###'  //creator number
global.location = "Kashmir, Bagh"
//=================[GREEN LANTERN]====================\\
global.autoJoin = false //DO NOT CHANGE
global.antiLink = false //DO NOT CHANGE
global.version = '1.0.2' //DO NOT CHANGE
global.inviteCode = "CswK4kvQD1u7SfSmsYfMHZ"
//================LINKS AND IMAGES=============\
global.imageUrl = 'https://files.catbox.moe/gi349b.jpg' //replace with your image link
global.idsaluran = "120363312991035785@newsletter"
global.imageUrl2 = 'https://files.catbox.moe/afevob.jpg' //replace with your image link
global.link = 'https://whatsapp.com/channel/0029VaieFO2HFxOtUtwLvQ0b' //any link you want
global.thumb = fs.readFileSync("./Max/thumb.png") //DO NOT CHANGE
global.author = "𝙆𝘼𝙎𝙃𝙈𝙄𝙍𝙄" //CHANGE TO YOUR NAME
// DELAY JPM
global.delayjpm = 5500
//=================[GREEN LANTERN]====================\\
//false=disable and true=enable
global.autoReact = false //auto Reaction 
global.autoRecording = false //auto recording
global.autoTyping = false //auto typing
global.autorecordtype = false //auto typing + recording
global.autoread = false //auto read messages
global.autobio = true //auto update bio
global.anti92 = true //auto block +92 
global.autoswview = false //auto view status/story


//GLOBAL THUMB

global.codeInvite = ""
global.imageurl = 'https://files.catbox.moe/xdvhtw.jpeg'
global.isLink = 'https://whatsapp.com/channel/0029VaieFO2HFxOtUtwLvQ0b'
global.packname = "Green Lantern"
global.author = "By 𝙆𝘼𝙎𝙃𝙈𝙄𝙍𝙄"
global.jumlah = "5"
 

let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update ${__filename}`))
	delete require.cache[file]
	require(file)
})