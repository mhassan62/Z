const fs = require('fs')
const chalk = require("chalk");

global.urlch = "https://whatsapp.com/channel/0029VbAZ3wZFsn0l6eJANo0u"
global.status = true
global.onwer = "6285247588501"

let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update ${__filename}`))
	delete require.cache[file]
	require(file)
})
