//================================//
// Main
//================================//
global.prefa = ['','!','.',',','🐤','🗿']
global.owner = ['62']
global.apido = "-"
//================================//
// Panel
//================================//
global.egg = "15"
global.nestid = "5"
global.loc = "1"
global.domain = "_"
global.apikey = "_"
global.capikey = "_"
//================================//
// Sticker
//================================//
global.packname = "Sticker By RizxVelz"
global.author = "RizxvelzOfficial"
//================================//
// Global Mess
//================================//
global.menuMode = global.menuMode || {};
global.mess = {
 owner: '*You are not the owner*',
 premium: '*You are not premium*',
 group: '*This feature is for groups only*'
}