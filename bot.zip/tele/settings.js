/*
• Base Ori GhostXmods X WannOFFC
Penting ‼️

Hapus Bagian/Teks Ini? Masuk Neraka Paling Bawah

Script Ini Murni Bikinan Sendiri, Saya Hanya Sekedar Kroco Penghuni Inti Bumi.

Thanks To :                                
- Allah Swt 
- Nabi Muhammad Saw         
- My Parents       
- Ghost [ Develover Sc ]  
- WannOFFC [ Support ]
- Dii Offc [ Record ]
- Pengguna Bot Yang Selalu Support
*/

const settings = {
  token: '7350404861:AAEiyjn7yLId8CcandnMjnboKgC78tD5hFk', // Token Bot
  adminId: '7452374150',
  urladmin: 'https://t.me/userkyou',
  domain: 'https://ptadminown.rizxvelz.online', // Isi dengan domain yang digunakan
  plta: 'ptla_MHhk27HldbON6LFnzIADcAVykdXiQn7DhkRfu7xdWoU', // Isi dengan nilai plta yang sesuai
  pltc: 'ptlc_M5AiLas0qcJa44dFVGu8BzEHE8lvbOuSjtuuNCRo7br', // Isi dengan nilai pltc yang sesuai
  pp: 'https://telegra.ph/file/08465ffe76171707dc06c.jpg',
  loc: '1', // Isi dengan lokasi yang diinginkan
  eggs: '15'
};

module.exports = settings;