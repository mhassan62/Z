require("./database/module")

//GLOBAL PAYMENT
global.storename = ""
global.dana = "0831"
global.qris = "-"


// GLOBAL SETTING
global.owner = "6283863863140"
global.namabot = "💧⃟𝐑𝐚𝐧𝐳𝟒𝐲𝐨𝐮 𝐂𝐫𝐚𝐬𝐡╳‍🔥"
global.nomorbot = "6283863863140"
global.namaCreator = "💧⃟𒆜𝐑𝐚𝐧𝐳𝟒𝐲𝐨𝐮⃟╳‍🔥"
global.linkyt = ""
global.autoJoin = false
global.antilink = false
global.versisc = '3.0'

// DELAY JPM
global.delayjpm = 5500



//GLOBAL THUMB

global.codeInvite = ""
global.imageurl = 'https://d.top4top.io/p_3261nct4w1.jpg'
global.thumb = 'https://d.top4top.io/p_3261nct4w1.jpg'
global.isLink = "https://whatsapp.com/channel/0029VagBmlhADTO8EPUnon0g"
global.packname = "Bugs"
global.author = "𝐑𝐚𝐧𝐳𝟒𝐲𝐨𝐮𝐂𝐫𝐚𝐬𝐡"
global.jumlah = "5"


let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update ${__filename}`))
	delete require.cache[file]
	require(file)
})