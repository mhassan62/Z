module.exports = {
  BOT_TOKEN: "7791207400:AAENetXdcTJugy7WX50HBSxoq_qkFlpDGwM",
    allowedDevelopers: ['7192039266'], // ID
};