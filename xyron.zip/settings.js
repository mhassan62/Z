const fs = require('fs')

//BOT SETTING AND OWNER
global.owner = "6285123965478"
global.namaowner = "RaflieeeModsss"
global.namabot = "XyronCrasherPro"

//---------------( Simple Banget 🥱🗿 ) 

let file = require.resolve(__filename)
fs.watchFile(file, () => {
fs.unwatchFile(file)
console.log(chalk.redBright(`Update'${__filename}'`))
delete require.cache[file]
require(file)
})
