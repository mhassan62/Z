const fs = require('fs')

global.owner = "923107612528" 
global.status = true
global.welcome = true

global.prefa = ['','!','.',',','🐤','🗿']

global.packname = '𝙈𝙧ܓ𝙃𝙖𝙨𝙨𝙖𝙣?'
global.author = '𝙈𝙧ܓ𝙃𝙖𝙨𝙨𝙖𝙣'

global.mess = {
ingroup: "*Only For Groups*",
admin: "*Only For Admin*",
owner: "*Only For Hassan*",
premium: "*Only For PREMIUM*",
seller: "*You are not seller*",
wait: "*Wait*"
}

let file = require.resolve(__filename)
require('fs').watchFile(file, () => {
  require('fs').unwatchFile(file)
  console.log('\x1b[0;32m'+__filename+' \x1b[1;32mupdated!\x1b[0m')
  delete require.cache[file]
  require(file)
})
