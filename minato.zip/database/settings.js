// Module
const fs = require('fs')

//Bot Settings
global.connect = true // True For Pairing // False For Qr
global.publicX = true // True For Public // False For Self
global.owner = ['6285126195265'] //Own Number
global.developer = "Cello Sigma" //Dev Name
global.botname = "Menato - Crasher" //Bot Name
global.version = "2.0" //Version Bot

//Sticker Setiings
global.packname = "Sticker By" //Pack Name 
global.author = "Cello Sigma" // Author

//Social Media Settings
global.ytube = "https://youtube.com/@CelloOffcial"
global.ttok = ""
global.igram = "https://instagram.com/@CelloOfficial"
global.chtele = ""
global.tgram = "https://t.me/CelloOffical2"
global.limitCount = 1,


//System Bot Settings
global.prefa = ['','!','.',',','🐤','🗿'] // Prefix // Not Change

let file = require.resolve(__filename)
require('fs').watchFile(file, () => {
  require('fs').unwatchFile(file)
  console.log('\x1b[0;32m'+__filename+' \x1b[1;32mupdated!\x1b[0m')
  delete require.cache[file]
  require(file)
})