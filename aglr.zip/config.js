const chalk = require("chalk")
const fs = require("fs")

global.ownerNumber = ["6289524210253@s.whatsapp.net"]
global.nomerOwner = "6289524210253"
global.nomorOwner = ['6289524210253']
global.namaDeveloper = "𝐀𝐧𝐝𝐫𝐚𝐙𝐲𝐲" //jangn diubh bng
global.namaOwner = "𝐀𝐧𝐝𝐫𝐚𝐙𝐲𝐲"
global.namaBot = "𝐀𝐠𝐥𝐞𝐫 𝐅𝐨𝐫𝐠𝐞𝐫"
global.versionBot = "𝟏𝟐.𝟎.𝟎"
global.packname = "𝐀𝐧𝐝𝐫𝐚𝐙𝐲𝐲"
global.author = "𝐀𝐧𝐝𝐫𝐚𝐙𝐲𝐲"
global.thumb = fs.readFileSync("./AndraZyy.png")
global.ThM = 'https://j.top4top.io/p_32794kvhw1.jpg'

let file = require.resolve(__filename) 
fs.watchFile(file, () => {
fs.unwatchFile(file)
console.log(chalk.redBright(`Update ${__filename}`))
delete require.cache[file]
require(file)
})