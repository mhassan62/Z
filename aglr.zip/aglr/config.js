const chalk = require("chalk")
const fs = require("fs")

global.ownerNumber = ["923359721431@s.whatsapp.net"]
global.nomerOwner = "923359721431"
global.nomorOwner = ['923359721431']
global.namaDeveloper = "●⃝ 𝗗𝗔𝗥𝗞✦𝗟𝗘𝗚𝗘𝗡𝗗 ×͜× 🌸" //jangn diubh bng
global.namaOwner = "●⃝ 𝗗𝗔𝗥𝗞✦𝗟𝗘𝗚𝗘𝗡𝗗 ×͜× 🌸"
global.namaBot = "●⃝ 𝗗𝗔𝗥𝗞✦𝗟𝗘𝗚𝗘𝗡𝗗 ×͜× 🌸"
global.versionBot = "𝟏𝟐.𝟎.𝟎"
global.packname = "●⃝ 𝗗𝗔𝗥𝗞✦𝗟𝗘𝗚𝗘𝗡𝗗 ×͜× 🌸"
global.author = "●⃝ 𝗗𝗔𝗥𝗞✦𝗟𝗘𝗚𝗘𝗡𝗗 ×͜× 🌸"
global.thumb = fs.readFileSync("./AndraZyy.png")
global.ThM = 'https://files.catbox.moe/xrvjhl.jpg'

let file = require.resolve(__filename) 
fs.watchFile(file, () => {
fs.unwatchFile(file)
console.log(chalk.redBright(`Update ${__filename}`))
delete require.cache[file]
require(file)
})