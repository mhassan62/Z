/*
Terimakasih Telah Menggunakan Script ini
Base By : Lezz DcodeR
Optimalization By : ErizaOffc

Dukung Kami dengan membiarkan credit ini tetap ada!
*/

const fs = require('fs')
const chalk = require('chalk')

//Settings
global.owner = "6285659202292";
global.ownername = 'Kino';
global.namabot = 'BOT JAGA GRUP';
global.botversion = "V1"
global.linkgc = "https://chat.whatsapp.com/IZ4dN1Oa5fsLL50qYGcfYD"
global.idGc = "120363308440213757@g.us"
global.linkSaluran = "https://whatsapp.com/channel/0029VacUGcxDJ6GuiseBDW0h"
global.idSaluran = "120363287513558870@newsletter"
global.namaSaluran = global.ownername + " | Saluran WhatsApp"
global.simbol = "⭔"

//Thumbnail
global.imgthumb = "https://img1.pixhost.to/images/5367/593310627_imgtmp.jpg"

let file = require.resolve(__filename)
fs.watchFile(file, () => {
fs.unwatchFile(file)
console.log(chalk.redBright(`Update ${__filename}`))
delete require.cache[file]
require(file)
})