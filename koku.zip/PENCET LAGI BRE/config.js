module.exports = {
  BOT_TOKEN: "7765698835:AAH37c2Jryc6eFoElT0aknXAUaUGK27vG_c",
  OWNER_ID: ["8394932546"],
};

// - thanks To Buy Script KOKUSHIBO 
// - And Thanks To My Friend
// - ARGA OFFC
// - EVIL CYT
// - ZENITH
// - XMODS
// - SANZY
