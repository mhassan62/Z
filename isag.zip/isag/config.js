module.exports = {
  BOT_TOKEN: "8138152795:AAF7yL1zgOKSj4zs6UMA44dGvtvJGFPaFiY",
};