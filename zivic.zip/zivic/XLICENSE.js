require('./setting')
const {attack} = require('./lib/key/1124')
kode = '11246867678989'
rorbejir = ''
// == GAUSAH DI UTAK UTIK //