global.prefa = ['','!','.',',','🐤','🗿'] 
// Setting Contact
global.ownername = 'Vidz'
global.namabot = 'Peter'
global.owner = ['923127842436']
global.wm = 'Bang Amba'
global.url = ''
global.chjid = ''
global.urlc1 = ''
global.urlc2 = ''
global.gris = '`'
global.thumb = "https://pomf2.lain.la/f/vlmkwsc0.jpg"
global.thumb2 = "https://pomf2.lain.la/f/uch562ym.jpg"
global.tipemenu = "v1"
global.delayjpm = 5500
// Batas Setting
let fs = require('fs')
let file = require.resolve(__filename)
fs.watchFile(file, () => {
fs.unwatchFile(file)
console.log(`Update ${__filename}`)
delete require.cache[file]
require(file)
})