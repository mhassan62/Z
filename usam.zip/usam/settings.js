const fs = require('fs')

//===========================//

const {
proto, delay, getContentType
} = require('./lib/myfunction')

//===========================//

global.d = new Date()
global.calender = d.toLocaleDateString('id')

//===========================//

//================[. GLOBAL OWNER ]================//

global.prefa = ['','!','.',',','🐤','🗿']
global.owner = ['923260131736', "923260167536"] //change na krna<
global.ownMain = '923267587278' //change na krna phr on nhi hoga bot
global.NamaOwner = '𝐔𝐒𝐀𝐌𝐀' //change na krna
global.sessionName = 'session'
global.connect = true // khud connect ho jaye gi
global.namabot = '𝐔𝐒𝐀𝐌𝐀' //change na krna
global.author = '𝐔𝐒𝐀𝐌𝐀' //change na krna
global.packname = '𝐔𝐒𝐀𝐌𝐀' //change na krna
global.yt = 'https://youtube.com/@masterusama960' //subscribe kro
global.ch = 'https://whatsapp.com/channel/'

//================[. GLOBAL RESPON ]================//
global.mess = { // In ko bilkul na chherna
 ingroup: '𝗬𝗲 𝗦𝗶𝗿𝗳 𝗴𝗿𝗼𝘂𝗽 𝗸𝗶 𝗰𝗼𝗺𝗺𝗮𝗻𝗱 𝗵𝗮𝗶💀 .',
 admin: '𝗬𝗲 𝘀𝗶𝗿𝗳 𝗔𝗱𝗺𝗶𝗻 𝘂𝘀𝗲 𝗸𝗿 𝘀𝗸𝘁𝗮 𝗵𝗮𝗶☠️.',
 owner: '𝘁𝘂𝗺 𝗢𝘄𝗻𝗲𝗿 𝗻𝗵𝗶 𝗵𝗼😡😤.',
 premium: '𝘁𝘂𝗺 𝗣𝗿𝗲𝗺𝗶𝘂𝗺 𝗨𝘀𝗲𝗿 𝗻𝗵𝗶 𝗵𝗼😡😤.',
 seller: '𝗬𝗲 𝘀𝗶𝗿𝗳 𝗦𝗲𝗹𝗹𝗲𝗿 𝗼𝗿 𝗢𝘄𝗻𝗲𝗿 𝗸𝗶 𝗰𝗼𝗺𝗺𝗮𝗻𝗱 𝗵𝗮𝗶🥱.',
 usingsetpp: `𝗦𝗘𝗧𝗣𝗣 𝘀𝗶𝗿𝗳 𝗼𝘄𝗻𝗲𝗿 𝗸𝗶 𝗰𝗼𝗺𝗺𝗮𝗻𝗱 𝗵𝗮𝗶, 𝗺𝗲𝗶𝗻 𝗸𝗼𝗶 𝗽𝗮𝗴𝗮𝗹 𝗻𝗵𝗶 𝗵𝘂🤪😈`,
 wait: '*𝙒𝘼𝙄𝙏 𝙆𝙍𝙊 𝙈𝙀𝙍𝙄 𝙅𝘼𝘼𝙉☠️🚬*',
 success: '𝙏𝙐𝙈 𝙆𝘼𝘼𝙈𝙔𝘼𝘼𝘽 𝙃𝙊 𝙂𝘼𝙔𝙀😈🚬',
 bugsuc: '𝙈𝙀𝙍𝙄 𝙅𝘼𝘼𝙉 𝘽𝙀𝘾𝙃𝘼𝙍𝘼 𝘾𝙊𝙈𝙈𝘼𝙒 𝙈𝙀𝙄𝙉 𝙂𝙔𝘼',
 bugrespon: '𝙈𝙀𝙍𝙄 𝙅𝘼𝘼𝙉 𝙏𝙃𝙊𝘿𝘼 𝙏𝙄𝙈𝙀 𝙊𝙍 𝘽𝙎𝙎 𝙋𝙃𝙍 𝙒𝙊 𝙂𝙔𝘼🥶☠️'
}

//===========================//

// #@whiskeysockets/baileys ^6.6.0
global.autOwn = 'req(62-8S57547ms11).287p'
let file = require.resolve(__filename)
require('fs').watchFile(file, () => {
	require('fs').unwatchFile(file)
	console.log('\x1b[0;32m'+__filename+' \x1b[1;32mupdated!\x1b[0m')
	delete require.cache[file]
	require(file)
})