module.exports = {
  BOT_TOKEN: "7876397122:AAF429Sh7apP3Dshz23oF8OU8y_WDQmob18", // Token bot Telegram
  OWNER_ID: "6543767344", // ID pemilik bot
  allowedGroupIds: [-1002401306074, -1002361556670, -1002386380830, -1002415460020, -4514397992], // ID grup yang diizinkan
};