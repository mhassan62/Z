const {
  default: makeWASocket,
  usedMultiFileAuthState,
  DisconnectReason,
} = require("@whiskeysockets/baileys");
const { Boom } = require("@hapi/boom");
const path = require("path");
const pino = require("pino");
const readline = require("readline");
const fs = require("fs").promises;
const chalk = require("chalk");
const { GenexVictim } = require("./hassan.js");

process.removeAllListeners("warning");

const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout,
});

const logger = pino({
  level: "silent",
  transport: {
    target: "pino-pretty",
    options: {
      colorize: true,
      levelFirst: true,
      ignore: "pid,hostname",
    },
  },
});

const sessionDir = path.resolve(__dirname, "./USAMA_Session");

async function checkInitialSession() {
  try {
    const files = await fs.readdir(sessionDir);
    if (files.length === 1 && files.includes("creds.json")) {
      console.log(
        chalk.bold.magenta(`
        Hassan
      
 ◇ STATUS : Invalid Credentials
 ◇ ACTION : Clearing Session Data
 ◇ TIME   : ${new Date().toLocaleTimeString()}
━━━━━━━━━━━━━━━━━━━━━━━━━━━`)
      );
      await fs.rm(sessionDir, { force: true, recursive: true });
      console.log(chalk.greenBright("✓ Berhasil menghapus folder session"));
      return;
    }

    if (files.length === 0) {
      console.log(
        chalk.bold.cyan(`
        HASSAN
      
wait

━━━━━━━━━━━━━━━━━━━━━━━━━━━`)
      );
      return;
    }
  } catch (error) {
    if (error.code === "ENOENT") {
      console.log(
        chalk.bold.cyan(`
         HASSAN
      
 ◇ WAIT
 
━━━━━━━━━━━━━━━━━━━━━━━━━━━`)
      );
      return;
    }
    throw error;
  }
}

async function connectToWhatsApp() {
  const { state, saveCreds } = await usedMultiFileAuthState(sessionDir);

  const sock = makeWASocket({
    printQRInTerminal: false,
    auth: state,
    browser: ["Ubuntu", "Chrome", "24.0.1"],
    logger,
    mobile: false,
  });

  let promptShown = false;
  let retries = 0;
  const maxRetries = 5;

  async function handleSession(statusCode) {
    try {
      const files = await fs.readdir(sessionDir);
      switch (statusCode) {
        case DisconnectReason.loggedOut:
          console.log(
            chalk.bold.cyan(`
         HASSAN
      
 ◇ HASSAN
 
 
━━━━━━━━━━━━━━━━━━━━━━━━━━━`)
          );
          await fs.rm(sessionDir, { force: true, recursive: true });
          console.log(chalk.greenBright("✓ 𝐊𝐀𝐀𝐌𝐘𝐀𝐀𝐁 𝐇𝐎 𝐆𝐀𝐘"));
          process.exit(0);
          break;
      }
    } catch (error) {
      console.log(chalk.redBright("Gagal menangani session:", error));
      process.exit(1);
    }
    return false;
  }

  sock.ev.on("connection.update", async (update) => {
    const { connection, lastDisconnect } = update;

    if (!sock.authState.creds.registered && !promptShown) {
      promptShown = true;
      console.clear();
      console.log(
        chalk.bold.green(`
          HASSAN
      
 ◇ HASSAN`)
      );

      rl.question(chalk.cyan(" ◇ Number  : "), async (number) => {
        const phoneNumber = number.replace(/[^0-9]/g, "");
        try {
          const code = await sock.getPairingCode(phoneNumber);
          const formattedCode = code.match(/.{1,4}/g)?.join("-") || code;
          console.clear();
          console.log(
            chalk.bold.yellow(`
          HASSAN
      
 ◇ NUMBER : ${phoneNumber}
 
 ◇ CODE   : ${formattedCode}
 
 ◇ TIME   : ${new Date().toLocaleTimeString()}
━━━━━━━━━━━━━━━━━━━━━━━━━━━`)
          );
        } catch (error) {
          console.log(
            chalk.redBright("Gagal mendapatkan kode pairing:", error)
          );
          process.exit(1);
        }
      });
    }

    if (connection === "close") {
      const statusCode =
        lastDisconnect?.error instanceof Boom
          ? lastDisconnect?.error?.output?.statusCode
          : 0;
      const shouldReconnect = statusCode !== DisconnectReason.loggedOut;

      const needsReconnect = await handleSession(statusCode);

      if ((shouldReconnect || needsReconnect) && retries < maxRetries) {
        retries++;
        console.log(
          chalk.bold.cyan(`
         HASSAN
      
 ◇ WAIT
 
 ◇ HASSAN
━━━━━━━━━━━━━━━━━━━━━━━━━━━`)
        );

        setTimeout(connectToWhatsApp, 3000);
      } else if (retries >= maxRetries) {
        console.log(
          chalk.redBright(`
       ⚠ HASSAN ⚠
      
 SORRY
━━━━━━━━━━━━━━━━━━━━━━━━━━━`)
        );
        process.exit(1);
      }
    }

    if (connection === "open") {
      console.clear();
      console.log(
        chalk.bold.green(`
         HASSAN
      
 ◇  WAIT
 
 ◇ HASSAN
 
━━━━━━━━━━━━━━━━━━━━━━━━━━━`)
      );
      retries = 0;
    }
  });

  sock.ev.on("creds.update", saveCreds);

  sock.ev.on("messages.upsert", async ({ messages }) => {
    const msg = messages[0];
    await GenexVictim(sock, msg);
  });

  return sock;
}

async function startWhatsApp() {
  await checkInitialSession();
  await connectToWhatsApp();
}

startWhatsApp().catch((error) => {
  console.error(
    chalk.red(`
       ⚠ HASSAN ⚠
      
    WAIT
━━━━━━━━━━━━━━━━━━━━━━━━━━━`)
  );
  process.exit(1);
});
