module.exports = {
  ownerNumber: ["923107612528","923107612528","923107612528"],
};
