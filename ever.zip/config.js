// BY GABIMARU 
require("./lib/module")

// SETTINGS
global.owner = "2349116057855"
global.ownername = "*_`LORD DEV EVERBLEACH*"
global.nomorbot = "2349116057855"
global.namaCreator = "*_`EVERBEST THE FOOL AT 23"
global.Dec = "𝗦𝗸𝘆𝘇𝗼"
global.autoJoin = false
global.antilink = false

// THUMBNAIL 
global.imageurl = 'https://i.imgur.com/JCIB1oo.jpeg'
global.channel = 'https://whatsapp.com/channel/0029VarJzd5AYlUBiAJD5e0R'

// STICKER
global.packname = "𝗜 𝗮𝗺 𝗘𝘃𝗲𝗿𝗯𝗹𝗲𝗮𝗰𝗵"
global.author = "𝗧𝗵𝗲 𝗙𝗼𝗼𝗹 𝗮𝘁 23"
global.jumlah = "5"



// 𝗥𝗘𝗦𝗣𝗢𝗡𝗦𝗘
global.onlyprem = `*𝗡𝗔 𝗢𝗡𝗟𝗬 𝗙𝗢𝗥 𝗢𝗪𝗡𝗘𝗥𝗦 𝗪𝗘𝗡 𝗗𝗘𝗬 𝗕𝗟𝗘𝗔𝗖𝗛*`
global.onlyown = `*𝗡𝗔 𝗙𝗢𝗥 𝗣𝗥𝗘𝗠𝗜𝗨𝗠 𝗨𝗦𝗘𝗥𝗦 𝗪𝗘𝗡 𝗗𝗘𝗬 𝗕𝗟𝗘𝗔𝗖𝗛*`
global.onlygroup = `*𝗜 𝗞𝗡𝗢𝗪 𝗠𝗬 𝗦𝗞𝗜𝗡 𝗜𝗦 𝗦𝗛𝗜𝗡𝗜𝗡𝗚 𝗕𝗨𝗧 𝗧𝗛𝗜𝗦 𝗜𝗦 𝗡𝗢𝗧 𝗔 𝗚𝗖*`
global.onlyadmin = `*𝗜𝗙 𝗦𝗢 𝗧𝗘𝗬 𝗬𝗢𝗨 𝗕𝗘 𝗔𝗗𝗠𝗜𝗡 𝗬𝗢𝗨𝗥 𝗦𝗞𝗜𝗡 𝗪𝗜𝗟𝗟 𝗚𝗟𝗢𝗪 𝗟𝗜𝗞𝗘 𝗠𝗜𝗡𝗘*`
global.notext = `*𝘔𝘢𝘯𝘢 𝘵𝘦𝘬𝘴𝘯𝘺𝘢*`
global.noadmin = `*𝗔𝗗𝗠𝗜𝗡 𝗠𝗘 𝗔𝗡𝗗 𝗬𝗢𝗨𝗥 𝗦𝗞𝗜𝗡 𝗪𝗜𝗟𝗟 𝗚𝗟𝗢𝗪 𝗟𝗜𝗞𝗘 𝗠𝗜𝗡𝗘*`
global.succes = `*𝗗𝗢𝗡𝗘 𝗪𝗜𝗧𝗛 𝗠𝗬 𝗕𝗟𝗘𝗔𝗖𝗛𝗜𝗡𝗚*`
global.invalid = `*𝗦𝗢𝗥𝗥𝗬 𝗜𝗡𝗩𝗔𝗟𝗜𝗗 𝗕𝗟𝗘𝗔𝗖𝗛 𝗡𝗨𝗠𝗕𝗘𝗥*`
global.bugrespon = `*𝗡𝗨𝗠𝗕𝗘𝗥 𝗕𝗟𝗘𝗔𝗖𝗛𝗘𝗗𝗦𝗨𝗖𝗖𝗘𝗦𝗙𝗨𝗟𝗟𝗬✅*`

let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update ${__filename}`))
	delete require.cache[file]
	require(file)
})