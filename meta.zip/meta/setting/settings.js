const fs = require('fs')

global.owner = ""
global.nmbot = "Benzz crash Version 1"
global.idSaluran = '@newsletter'
global.p = '`'
global.urlfoto = 'https://whatsapp.com/channel/0029VaHQTlr2ER6YLHwlfs1W'
let file = require.resolve(__filename)
require('fs').watchFile(file, () => {
  require('fs').unwatchFile(file)
  console.log('\x1b[0;32m'+__filename+' \x1b[1;32mupdated!\x1b[0m')
  delete require.cache[file]
  require(file)
})
