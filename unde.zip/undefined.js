const global = {
    superUser: [6555756895, 5126860596], // id mu, bisa lebih dari 1 id
    usernameOwner: "@devbeal",
    botName: "Undercrasher_bot",
    botToken: "7690163438:AAG1_PyKLDLUGwLmcH3AdO2TnIsqSmEWAtQ", // token bot mu
    channelLink: "https://t.me/NullxTeam",
    preview: 'https://j.top4top.io/m_32448eu0w1.mp4'
}

module.exports = global;